"""FreeRoot-style proot sandboxes: work on real hosts and inside proot/containers.

POST /API/freeroot creates a filesystem-isolated environment (proot), installs
sshx if needed, and returns the SSHx link. Network and processes are shared
with the host (honest isolation label). Specs (CPU/RAM) are the host's.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULT_TTL = 3600
MIN_TTL = 300
MAX_TTL = 86400
MAX_PER_KEY = 5
MAX_TOTAL = 30
OUT_DIR = "/run/prime-out"
SSHX_LINK = re.compile(r"^https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}$")
_LINK_IN_LOG = re.compile(r"https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}")
_LOCK = threading.RLock()
_ANSI = re.compile(r"\x1b\[[0-9;]*m")

UBUNTU_BASE = {
    "x86_64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-amd64.tar.gz",
    "amd64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-amd64.tar.gz",
    "aarch64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-arm64.tar.gz",
    "arm64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-arm64.tar.gz",
}
PROOT_URL = {
    "x86_64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-x86_64",
    "amd64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-x86_64",
    "aarch64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-aarch64",
    "arm64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-aarch64",
}

GUEST_SCRIPT = r"""
set -e
OUT=/run/prime-out
mkdir -p "$OUT" /root
echo starting > "$OUT/status"
export PATH="/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin"
export TAR_OPTIONS=--no-same-owner
export HOME=/root
export TERM=xterm-256color
export LANG=C.UTF-8
printf 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n' > /etc/resolv.conf 2>/dev/null || true

if ! command -v sshx >/dev/null 2>&1; then
  if command -v curl >/dev/null 2>&1; then
    curl -sSf https://sshx.io/get 2>>"$OUT/install.log" | sh >>"$OUT/install.log" 2>&1 || {
      echo install-failed > "$OUT/status"; exit 1; }
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- https://sshx.io/get 2>>"$OUT/install.log" | sh >>"$OUT/install.log" 2>&1 || {
      echo install-failed > "$OUT/status"; exit 1; }
  else
    echo "no curl/wget" >>"$OUT/install.log"
    echo install-failed > "$OUT/status"; exit 1
  fi
fi

nohup sshx >"$OUT/sshx.log" 2>&1 &
i=0
while [ $i -lt 120 ]; do
  link=$(grep -oE 'https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}' "$OUT/sshx.log" 2>/dev/null | head -n 1)
  if [ -n "$link" ]; then
    printf '%s\n' "$link" > "$OUT/sshx.txt"
    echo ready > "$OUT/status"
    break
  fi
  i=$((i + 1))
  sleep 1
done
[ -f "$OUT/sshx.txt" ] || { echo no-link > "$OUT/status"; exit 1; }
wait
""".strip()


class FreeRootError(ValueError):
    pass


def owner_ref(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


def _arch() -> str:
    m = platform.machine().lower()
    if m in ("x86_64", "amd64"):
        return "x86_64"
    if m in ("aarch64", "arm64"):
        return "aarch64"
    raise FreeRootError(f"Unsupported architecture: {m}")


def _download(url: str, dest: Path, timeout: int = 600) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "PrimeTerminal-FreeRoot/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(tmp, "wb") as out:
        shutil.copyfileobj(resp, out)
    tmp.replace(dest)


def _alive(pid: Optional[int]) -> bool:
    if not pid or pid <= 1:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as fh:
            parts = fh.read().split()
            if len(parts) > 2 and parts[2] == "Z":
                return False
    except OSError:
        return False
    return True


class FreeRootManager:
    def __init__(self, data_dir: str) -> None:
        self.root = Path(data_dir) / "freeroot"
        self.template = self.root / "template"
        self.instances = self.root / "instances"
        self.registry = self.root / "registry.json"
        self.proot_bin = self.root / "bin" / "proot"
        self.root.mkdir(parents=True, exist_ok=True)
        self.instances.mkdir(parents=True, exist_ok=True)
        self._procs: Dict[str, subprocess.Popen] = {}
        if not self.registry.exists():
            self._save({"sandboxes": []})

    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.registry.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"sandboxes": []}

    def _save(self, data: Dict[str, Any]) -> None:
        tmp = self.registry.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.registry)

    def template_ready(self) -> bool:
        t = self.template
        has_sh = (t / "bin" / "sh").exists() or (t / "usr" / "bin" / "sh").exists()
        has_root = (t / "root").is_dir()
        return has_sh and has_root and self.proot_bin.is_file()

    def ensure_template(self) -> None:
        """Download Ubuntu base + static proot once (shared by all freeroot sandboxes)."""
        with _LOCK:
            if self.template_ready():
                return
            arch = _arch()
            base_url = UBUNTU_BASE.get(arch)
            proot_url = PROOT_URL.get(arch)
            if not base_url or not proot_url:
                raise FreeRootError(f"No FreeRoot packages for arch {arch}")

            new = self.root / "template.new"
            if new.exists():
                shutil.rmtree(new, ignore_errors=True)
            new.mkdir(parents=True)

            tar_path = self.root / "ubuntu-base.tar.gz"
            if not tar_path.exists() or tar_path.stat().st_size < 1_000_000:
                _download(base_url, tar_path)
            subprocess.run(
                ["tar", "-xzf", str(tar_path), "-C", str(new)],
                check=True, timeout=600,
            )
            (new / "root").mkdir(exist_ok=True)
            (new / "run" / "prime-out").mkdir(parents=True, exist_ok=True)
            (new / "tmp").mkdir(exist_ok=True)
            (new / "proc").mkdir(exist_ok=True)
            (new / "dev").mkdir(exist_ok=True)
            (new / "etc").mkdir(exist_ok=True)
            (new / "etc" / "resolv.conf").write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")

            # static proot into panel data (host-side binary)
            self.proot_bin.parent.mkdir(parents=True, exist_ok=True)
            if not self.proot_bin.exists() or self.proot_bin.stat().st_size < 1000:
                _download(proot_url, self.proot_bin)
                os.chmod(self.proot_bin, 0o755)

            # preinstall host sshx into template when available
            host_sshx = shutil.which("sshx") or ("/usr/local/bin/sshx" if os.path.isfile("/usr/local/bin/sshx") else None)
            if host_sshx:
                dest = new / "usr" / "local" / "bin"
                dest.mkdir(parents=True, exist_ok=True)
                shutil.copy2(host_sshx, dest / "sshx")
                os.chmod(dest / "sshx", 0o755)

            if self.template.exists():
                shutil.rmtree(self.template, ignore_errors=True)
            os.replace(new, self.template)

            if not self.template_ready():
                raise FreeRootError("FreeRoot template incomplete after download")

    def isolation(self) -> str:
        return ("filesystem only (proot/FreeRoot): processes and network shared with host; "
                "CPU/RAM are the host's")

    def create(self, token: str, ttl: int = DEFAULT_TTL, name: Optional[str] = None) -> Dict[str, Any]:
        if not MIN_TTL <= int(ttl) <= MAX_TTL:
            raise FreeRootError(f"ttl must be {MIN_TTL}-{MAX_TTL}")
        self.ensure_template()
        owner = owner_ref(token)
        now = time.time()
        sid = "fr-" + secrets.token_hex(6)
        base = self.instances / sid
        record = {
            "id": sid, "owner": owner, "name": name or sid,
            "backend": "proot-freeroot", "network": "shared-host",
            "created_at": now, "expires_at": now + int(ttl),
            "pid": None, "dir": str(base),
        }
        with _LOCK:
            data = self._load()
            mine = [r for r in data["sandboxes"] if hmac.compare_digest(r["owner"], owner)]
            if len(mine) >= MAX_PER_KEY:
                raise FreeRootError(f"Each key may have up to {MAX_PER_KEY} active FreeRoot sandboxes")
            if len(data["sandboxes"]) >= MAX_TOTAL:
                raise FreeRootError("Host has no free FreeRoot slots")
            data["sandboxes"].append(record)
            self._save(data)

        try:
            pid = self._launch(record)
        except Exception:
            with _LOCK:
                data = self._load()
                data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != sid]
                self._save(data)
            shutil.rmtree(base, ignore_errors=True)
            raise

        with _LOCK:
            data = self._load()
            for item in data["sandboxes"]:
                if item["id"] == sid:
                    item["pid"] = pid
            self._save(data)
        return self._public(dict(record, pid=pid))

    def _launch(self, record: Dict[str, Any]) -> int:
        base = Path(record["dir"])
        root = base / "rootfs"
        out = base / "out"
        out.mkdir(parents=True, exist_ok=True)
        # private copy of template (filesystem isolation between sandboxes)
        if root.exists():
            shutil.rmtree(root)
        subprocess.run(
            ["cp", "-a", str(self.template), str(root)],
            check=True, timeout=600,
        )
        (root / "run" / "prime-out").mkdir(parents=True, exist_ok=True)
        (root / "root").mkdir(exist_ok=True)
        script = base / "guest.sh"
        script.write_text(GUEST_SCRIPT + "\n", encoding="utf-8")
        os.chmod(script, 0o755)

        proot = str(self.proot_bin)
        # bind host out dir into guest /run/prime-out
        argv = [
            proot, "--rootfs=" + str(root),
            "-0", "-w", "/root",
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", str(out) + ":" + OUT_DIR,
            "-b", str(script) + ":/tmp/guest.sh",
            "--kill-on-exit",
            "/bin/sh", "/tmp/guest.sh",
        ]
        # fallback if /bin/sh missing (usrmerge)
        if not (root / "bin" / "sh").exists() and (root / "usr" / "bin" / "sh").exists():
            argv[-2] = "/usr/bin/sh"

        log = open(base / "console.log", "ab")
        try:
            proc = subprocess.Popen(
                argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                start_new_session=True, close_fds=True,
            )
        finally:
            log.close()
        self._procs[record["id"]] = proc
        return proc.pid

    def _owned(self, token: str, sid: str) -> Dict[str, Any]:
        owner = owner_ref(token)
        for record in self._load()["sandboxes"]:
            if record["id"] == sid and hmac.compare_digest(record["owner"], owner):
                return record
        raise LookupError(sid)

    def _read(self, record: Dict[str, Any], name: str) -> str:
        try:
            return (Path(record["dir"]) / "out" / name).read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            return ""

    def _link(self, record: Dict[str, Any]) -> Optional[str]:
        raw = self._read(record, "sshx.txt")
        if not raw:
            raw = next(iter(_LINK_IN_LOG.findall(self._read(record, "sshx.log"))), "")
        raw = _ANSI.sub("", raw or "").strip()
        return raw if raw and SSHX_LINK.fullmatch(raw) else None

    def _state(self, record: Dict[str, Any]) -> Dict[str, Any]:
        link = self._link(record)
        if link:
            return {"status": "ready", "sshx": link}
        phase = self._read(record, "status")
        if phase in ("install-failed", "no-link"):
            return {"status": "failed", "sshx": None}
        if _alive(record.get("pid")):
            return {"status": "starting", "sshx": None}
        return {"status": "failed" if phase else "stopped", "sshx": None}

    def _public(self, record: Dict[str, Any]) -> Dict[str, Any]:
        st = self._state(record)
        return {
            "id": record["id"], "name": record["name"],
            "status": st["status"], "running": _alive(record.get("pid")),
            "sshx": st["sshx"], "backend": "proot-freeroot",
            "network": "shared-host",
            "isolation": self.isolation(),
            "expires_at": int(record["expires_at"]),
            "status_url": "/API/freeroot/" + record["id"],
        }

    def status(self, token: str, sid: str, wait: int = 0) -> Dict[str, Any]:
        deadline = time.time() + max(0, min(int(wait), 900))
        while True:
            record = self._owned(token, sid)
            st = self._state(record)
            if st["status"] != "starting" or time.time() >= deadline:
                return self._public(record)
            time.sleep(2)

    def delete(self, token: str, sid: str) -> Dict[str, Any]:
        record = self._owned(token, sid)
        self._stop(record)
        with _LOCK:
            data = self._load()
            data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != sid]
            self._save(data)
        shutil.rmtree(record["dir"], ignore_errors=True)
        return {"ok": True, "id": sid}

    def _stop(self, record: Dict[str, Any]) -> None:
        proc = self._procs.pop(record["id"], None)
        pid = record.get("pid")
        if proc is not None:
            proc.poll()
        if not pid or pid <= 1 or not _alive(pid):
            return
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                pass
        for _ in range(30):
            if not _alive(pid):
                break
            time.sleep(0.1)
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass

    def expire_due(self) -> int:
        now = time.time()
        with _LOCK:
            due = [r for r in self._load()["sandboxes"] if r["expires_at"] <= now]
        for record in due:
            self._stop(record)
            with _LOCK:
                data = self._load()
                data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != record["id"]]
                self._save(data)
            shutil.rmtree(record["dir"], ignore_errors=True)
        return len(due)
