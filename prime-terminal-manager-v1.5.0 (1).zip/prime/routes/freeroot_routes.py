"""HTTP routes for FreeRoot proot sandboxes (POST /API/freeroot).

Works on real VPS and proot/container hosts. Bearer provisioning key auth
(same keys as /API/sandbox and /API/vm).
"""
import asyncio
from functools import partial
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt
from ..freeroot import DEFAULT_TTL, MAX_TTL, MIN_TTL, FreeRootError, FreeRootManager
from .vm_api_routes import _key

router = APIRouter(tags=["freeroot-api"])


class CreateFreeRoot(BaseModel):
    name: Optional[str] = Field(default=None, max_length=40)
    ttl: int = Field(default=DEFAULT_TTL, ge=MIN_TTL, le=MAX_TTL)


def _api(request: Request) -> FreeRootManager:
    return FreeRootManager(get_rt(request).cfg.data_dir)


async def _run(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    except FreeRootError as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, "FreeRoot sandbox not found") from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post("/API/freeroot")
async def create_freeroot(request: Request, payload: CreateFreeRoot, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    api = _api(request)
    # ensure template may download — allow longer executor time via wait loop after
    result = await _run(api.create, token, payload.ttl, payload.name)
    get_rt(request).auth.audit("freeroot.create", result["id"], True, "provisioning-api", client_ip(request))
    wants_json = "application/json" in request.headers.get("accept", "")
    if not wants_json and not wait:
        wait = 600
    if wait:
        result = await _run(api.status, token, result["id"], wait)
    ready = result["status"] == "ready"
    if not wants_json:
        lines = []
        if ready:
            lines.append("SSHx:  " + result["sshx"])
        else:
            lines.append(
                "FreeRoot " + result["id"] + " is " + result["status"] + "; check "
                + result["status_url"] + "?wait=600 with the same key."
            )
        lines.append("isolation: " + result["isolation"])
        return PlainTextResponse(
            "\n".join(lines) + "\n",
            status_code=200 if ready else 202,
            headers={"Cache-Control": "no-store"},
        )
    return JSONResponse(
        result,
        status_code=200 if ready else 202,
        headers={"Cache-Control": "no-store"},
    )


@router.get("/API/freeroot/{sandbox_id}")
async def freeroot_status(request: Request, sandbox_id: str, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    result = await _run(_api(request).status, token, sandbox_id, wait)
    return JSONResponse(result, headers={"Cache-Control": "no-store"})


@router.delete("/API/freeroot/{sandbox_id}")
async def freeroot_delete(request: Request, sandbox_id: str):
    token = _key(request)
    result = await _run(_api(request).delete, token, sandbox_id)
    get_rt(request).auth.audit("freeroot.delete", sandbox_id, True, "provisioning-api", client_ip(request))
    return result
