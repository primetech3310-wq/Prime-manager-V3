<!-- coderabbit-ai-generated:v1 -->

# Release scope and verification

## Included

- Original responsive glass/liquid panel design, dashboard and terminal/file/process tools.
- Mobile file-row actions fit the viewport; loading and stale-navigation handling.
- Terminal fullscreen uses the existing toolbar control without a second floating exit button. Browser fullscreen control.
- 23 appearance/browser settings, including theme, primary/secondary accents, glass blur/saturation, corner scale, animation/motion/performance, background opacity/speed/size, three orb switches, sidebar/topbar/mobilebar sizes, font size, button radius, browser homepage/enabled and custom CSS. Preview, server persistence and reset; downloadable CSS.md guide.
- Real QEMU raw/QCOW2 VM creation, Debian image download/cache with SHA-512 manifest check, cloud-init non-root guest login, start/stop/delete, <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:2d97886a6c0dfc0124c6cbe101ccbcfe302d61386bdcf6b2eacd05761f82ca21 -->

real serial boot log and loopback SSH forwarding. Authenticated noVNC graphical console, offline disk backups with checksum-verified restoration, internal snapshots and persistent schedules with retention/status controls.

<!-- /coderabbit-ai-generated:v1 -->
- Explicit TCG software mode and automatic retry using TCG when KVM is inaccessible. No KVM required.
- Validated ZIP update with startup check, application backup, loading state, restart, failed-start rollback and preserved data.
- SSHx, private full panel and ttyd provisioning APIs with private links, hashed/revocable API keys, configurable panel endpoint name, configurable TTL/capacity and container isolation/network filtering.
- Explicit Limited and Shared resource modes with capability checks; expiry and deletion clean up tenant runtime resources. Current Chromium embedded panel sessions use partitioned cookies and a separate origin.

## Boundaries

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:581360b9630a11eb60c51f19a8b90a93470c3723c79b5bc7f0942ceed18a9424 -->

This release includes tenant invitations, explicit VM view/power/console delegation, a separate tenant workspace page, authenticator two-factor login with single-use recovery codes, and a billing ledger for plans, invoices and coupons. Existing accounts remain host administrators. See ACCOUNTS.md for permission and billing semantics.

Full vPanel Pro parity is still incomplete: distributed node/agent orchestration, SMTP email verification/password recovery, MongoDB studio, Discord/Telegram/webhook plugins, storage pools/ISO administration, advanced VM guest-agent/SSH file workflows, firewall management and some vPanel-specific appearance/automation tools have not been ported. The billing ledger does not process external payments. This build must not be described as 100% parity.

<!-- /coderabbit-ai-generated:v1 -->

Only x86_64 Docker workspace images are bundled. QEMU was tested with software emulation and Debian 12; KVM, other guest operating systems, other host distributions and arbitrary restricted kernels were not validated. Limited mode was blocked by this sandbox's cgroup delegation; Shared mode was explicitly tested and does not offer resource exhaustion protection. External terminal/tunnel providers can fail or interrupt sessions. These limits are visible rather than simulated.

See DEPLOYMENT.md, VMS.md, WORKSPACES.md and UPDATES.md for operation and validation. The original project README and archive remain intact in the source repository.
