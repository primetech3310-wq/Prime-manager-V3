"""One workspace: unprivileged panel or terminal and its outbound connection."""
import json
import os
import signal
import subprocess
import time
import urllib.request
from pathlib import Path

os.umask(0o077)
root = Path('/workspace/.prime')
root.mkdir(mode=0o700, exist_ok=True)
kind = os.environ['PRIME_WORKSPACE_KIND']
access = os.environ['PRIME_WORKSPACE_ACCESS']
processes = []
log = (root / 'provider.log').open('ab', buffering=0)
(root / 'host-specs.json').write_text(os.environ.get('PRIME_HOST_SPECS', '{}'))


def start(args):
    process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, cwd='/workspace')
    processes.append(process)
    return process


def stop(_sig=None, _frame=None):
    for process in reversed(processes):
        if process.poll() is None:
            process.terminate()
    for process in processes:
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
    raise SystemExit(0)


signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
if kind == 'panel':
    config = {'data_dir': str(root), 'allowed_roots': ['/workspace'], 'extra_log_dirs': [str(root)],
              'db_path': str(root / 'panel.db'), 'log_path': str(root / 'panel.log'), 'secure_cookies': True,
              'shell': '/bin/bash', 'term_max_sessions': 8}
    (root / 'config.json').write_text(json.dumps(config))
    os.environ['PRIME_CONFIG'] = str(root / 'config.json')
    # Only this container knows this account; the link exchanges its fragment
    # for a normal HttpOnly session, with all APIs scoped to the container.
    import sys
    sys.path.insert(0, '/opt/prime')
    from prime.auth import AuthStore
    from prime.config import Config
    auth = AuthStore(Config.load())
    if auth.user_count() == 0:
        auth.create_user('workspace', access)
    start(['python', '/opt/prime/run.py'])
    for _ in range(100):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8080/api/health', timeout=1) as response:
                if json.load(response).get('ok'):
                    break
        except (OSError, ValueError):
            time.sleep(.2)
    else:
        stop()
    start(['cloudflared', 'tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', 'http://127.0.0.1:8080'])
elif kind == 'ttyd':
    start(['ttyd', '--writable', '--interface', '127.0.0.1', '--port', '7681', '--base-path', '/' + access, 'bash', '-l'])
    time.sleep(.5)
    start(['cloudflared', 'tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', 'http://127.0.0.1:7681'])
elif kind == 'sshx':
    start(['sshx'])
else:
    raise SystemExit('Unknown workspace type')

expires = float(os.environ['PRIME_WORKSPACE_EXPIRES'])
while time.time() < expires and all(process.poll() is None for process in processes):
    time.sleep(1)
stop()
