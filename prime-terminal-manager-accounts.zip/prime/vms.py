"""Local QEMU virtual machines for the panel administrator.

These VMs are administered by the panel account; this module does not provide
multi-tenant isolation or expose guest ports outside the local machine.
"""
from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import signal
import socket
import subprocess
import threading
import time
import uuid
import urllib.request
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List

from .vmmaintenance import MaintenanceMixin

_NAME = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9 _.-]{0,63}$')
_ID = re.compile(r'^[0-9a-f]{32}$')
_USERNAME = re.compile(r'^[a-z_][a-z0-9_-]{0,30}$')
_LOCK = threading.RLock()
_DOWNLOAD_LOCK = threading.Lock()
DEBIAN_IMAGE = 'https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-genericcloud-amd64.qcow2'
MAX_IMAGE_SIZE = 2 * 1024 * 1024 * 1024


class VMError(ValueError):
    pass


def capabilities() -> Dict[str, Any]:
    qemu = shutil.which('qemu-system-x86_64')
    img = shutil.which('qemu-img')
    kvm = os.access('/dev/kvm', os.R_OK | os.W_OK)
    return {'available': bool(qemu and img), 'qemu': bool(qemu), 'qemu_img': bool(img),
            'cloud_init': bool(shutil.which('cloud-localds') and shutil.which('openssl')),
            'acceleration': 'kvm' if kvm else 'tcg', 'kvm': kvm}


class VMStore(MaintenanceMixin):
    _lock = _LOCK
    def __init__(self, data_dir: str):
        self.root = Path(data_dir).resolve() / 'vms'
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)

    def _dir(self, vm_id: str) -> Path:
        if not _ID.fullmatch(vm_id):
            raise VMError('Invalid VM ID')
        return self.root / vm_id

    def _read(self, vm_id: str) -> Dict[str, Any]:
        try:
            data = json.loads((self._dir(vm_id) / 'vm.json').read_text())
            if data.get('id') != vm_id:
                raise VMError('Invalid VM record')
            return data
        except (OSError, ValueError, TypeError) as exc:
            raise VMError('VM not found or record is invalid') from exc

    def _write(self, vm: Dict[str, Any]) -> None:
        path = self._dir(vm['id']) / 'vm.json'
        tmp = path.with_suffix('.tmp')
        with tmp.open('w') as f:
            json.dump(vm, f)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)

    def _running(self, vm_id: str) -> int:
        try:
            pid = int((self._dir(vm_id) / 'qemu.pid').read_text().strip())
            if pid <= 1:
                return 0
            args = Path('/proc') / str(pid) / 'cmdline'
            command = args.read_bytes().split(b'\0')
            if b'-name' in command and ('prime-vm-' + vm_id).encode() in command:
                return pid
        except (OSError, ValueError):
            pass
        return 0

    def list(self) -> List[Dict[str, Any]]:
        result = []
        for path in sorted(self.root.iterdir()):
            if not path.is_dir() or not _ID.fullmatch(path.name):
                continue
            try:
                vm = self._read(path.name)
                vm['running'] = bool(self._running(path.name))
                result.append(vm)
            except VMError:
                continue
        return result

    def download_debian(self) -> Dict[str, Any]:
        """Cache the official cloud image after verifying the release checksum."""
        images = self.root.parent / 'vm-images'
        images.mkdir(mode=0o700, parents=True, exist_ok=True)
        image = images / 'debian-12-genericcloud-amd64.qcow2'
        checksum_file = images / 'debian-12.sha512'
        with _DOWNLOAD_LOCK:
            if image.is_file() and checksum_file.is_file():
                digest = hashlib.sha512()
                with image.open('rb') as source:
                    for block in iter(lambda: source.read(1024 * 1024), b''):
                        digest.update(block)
                if digest.hexdigest() == checksum_file.read_text().strip():
                    return {'path': str(image), 'cached': True}
            tmp = images / ('download-' + uuid.uuid4().hex + '.tmp')
            try:
                with urllib.request.urlopen(DEBIAN_IMAGE, timeout=30) as response:
                    final_url = urllib.parse.urlsplit(response.geturl())
                    if final_url.scheme != 'https' or not final_url.hostname:
                        raise VMError('Image download was redirected to an insecure URL')
                    length = response.headers.get('Content-Length')
                    if length and int(length) > MAX_IMAGE_SIZE:
                        raise VMError('Cloud image exceeds the size limit')
                    sums_url = urllib.parse.urljoin(response.geturl(), 'SHA512SUMS')
                    with urllib.request.urlopen(sums_url, timeout=30) as checksums:
                        if urllib.parse.urlsplit(checksums.geturl()).scheme != 'https':
                            raise VMError('Checksum download was redirected to an insecure URL')
                        lines = checksums.read(512 * 1024).decode('ascii').splitlines()
                    expected = None
                    for line in lines:
                        parts = line.split()
                        if len(parts) == 2 and parts[1].lstrip('*') == image.name and re.fullmatch(r'[0-9a-fA-F]{128}', parts[0]):
                            expected = parts[0].lower()
                            break
                    if not expected:
                        raise VMError('Cloud image checksum was not found')
                    digest = hashlib.sha512()
                    size = 0
                    with tmp.open('xb') as output:
                        os.chmod(tmp, 0o600)
                        while True:
                            block = response.read(1024 * 1024)
                            if not block:
                                break
                            size += len(block)
                            if size > MAX_IMAGE_SIZE:
                                raise VMError('Cloud image exceeds the size limit')
                            digest.update(block)
                            output.write(block)
                    if digest.hexdigest() != expected:
                        raise VMError('Cloud image checksum verification failed')
                    os.replace(tmp, image)
                    checksum_file.write_text(expected + '\n')
                    os.chmod(checksum_file, 0o600)
                    return {'path': str(image), 'cached': False}
            except (OSError, ValueError) as exc:
                if isinstance(exc, VMError):
                    raise
                raise VMError('Cloud image download failed') from exc
            finally:
                tmp.unlink(missing_ok=True)

    def create(self, name: str, image: str, memory: int, cpus: int,
               username: str = '', password: str = '', acceleration: str = 'auto') -> Dict[str, Any]:
        if not capabilities()['available']:
            raise VMError('qemu-system-x86_64 and qemu-img are required')
        if not isinstance(name, str) or not _NAME.fullmatch(name):
            raise VMError('Use a name of 1–64 letters, digits, spaces, dots, dashes or underscores')
        if isinstance(memory, bool) or not isinstance(memory, int) or not 128 <= memory <= 65536:
            raise VMError('Memory must be between 128 and 65536 MiB')
        if isinstance(cpus, bool) or not isinstance(cpus, int) or not 1 <= cpus <= 64:
            raise VMError('CPU count must be between 1 and 64')
        if acceleration not in ('auto', 'tcg', 'kvm'):
            raise VMError('Acceleration must be auto, tcg or kvm')
        if username or password:
            if not username or not _USERNAME.fullmatch(username) or username == 'root':
                raise VMError('Guest username must be a lowercase, non-root Linux username')
            if not isinstance(password, str) or not 10 <= len(password) <= 256 or any(c in password for c in '\r\n\x00'):
                raise VMError('Guest password must be 10–256 characters without line breaks')
            if not capabilities()['cloud_init']:
                raise VMError('Guest provisioning requires cloud-localds and openssl')
        source = Path(image).expanduser().resolve()
        if not source.is_file():
            raise VMError('Source disk image must be an existing local file')
        if ',' in str(self.root):
            raise VMError('VM data directory cannot contain a comma')
        vm_id = uuid.uuid4().hex
        directory = self._dir(vm_id)
        with _LOCK:
            directory.mkdir(mode=0o700)
            try:
                info = subprocess.run(['qemu-img', 'info', '--output=json', str(source)],
                                      capture_output=True, text=True, timeout=20, check=True)
                image_info = json.loads(info.stdout)
                fmt = image_info.get('format')
                if fmt not in ('raw', 'qcow2'):
                    raise VMError('Only raw and qcow2 source images are supported')
                # Convert to a self-contained disk so changes to the source cannot affect the VM.
                subprocess.run(['qemu-img', 'convert', '-f', fmt, '-O', 'qcow2',
                                str(source), str(directory / 'disk.qcow2')],
                               capture_output=True, text=True, timeout=1800, check=True)
                if username:
                    hashed = subprocess.run(['openssl', 'passwd', '-6', '-stdin'], input=password + '\n',
                                            capture_output=True, text=True, timeout=10, check=True).stdout.strip()
                    config = {'hostname': 'prime-' + vm_id[:12], 'ssh_pwauth': True, 'disable_root': True,
                              'users': ['default', {'name': username, 'lock_passwd': False,
                                                    'passwd': hashed, 'sudo': 'ALL=(ALL) NOPASSWD:ALL',
                                                    'shell': '/bin/bash'}],
                              'chpasswd': {'expire': False}}
                    user_data = directory / 'user-data'
                    meta_data = directory / 'meta-data'
                    try:
                        user_data.write_text('#cloud-config\n' + json.dumps(config))
                        meta_data.write_text(json.dumps({'instance-id': 'prime-' + vm_id}))
                        os.chmod(user_data, 0o600)
                        os.chmod(meta_data, 0o600)
                        subprocess.run(['cloud-localds', str(directory / 'seed.iso'), str(user_data), str(meta_data)],
                                       capture_output=True, text=True, timeout=30, check=True)
                        os.chmod(directory / 'seed.iso', 0o600)
                    finally:
                        user_data.unlink(missing_ok=True)
                        meta_data.unlink(missing_ok=True)
                vm = {'id': vm_id, 'name': name, 'memory': memory, 'cpus': cpus,
                      'created_at': time.time(), 'image_format': fmt, 'guest_username': username,
                      'acceleration': acceleration}
                self._write(vm)
                return {**vm, 'running': False}
            except (OSError, subprocess.SubprocessError, ValueError) as exc:
                shutil.rmtree(directory, ignore_errors=True)
                if isinstance(exc, VMError):
                    raise
                raise VMError('Could not prepare the disk image') from exc

    def start(self, vm_id: str) -> Dict[str, Any]:
        with _LOCK:
            vm = self._read(vm_id)
            if self._running(vm_id):
                raise VMError('VM is already running')
            cap = capabilities()
            if not cap['available']:
                raise VMError('QEMU is unavailable')
            directory = self._dir(vm_id)
            pidfile = directory / 'qemu.pid'
            pidfile.unlink(missing_ok=True)
            vnc_socket = self.vnc_socket(vm_id)
            vnc_socket.unlink(missing_ok=True)
            # Bind only on loopback; a public link or forwarded port must be
            # explicitly configured by the administrator.
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as port_probe:
                port_probe.bind(('127.0.0.1', 0))
                ssh_port = port_probe.getsockname()[1]
            mode = vm.get('acceleration', 'auto')
            if mode == 'kvm' and not cap['kvm']:
                raise VMError('KVM is unavailable. Choose software emulation (TCG) or automatic mode.')
            selected = 'kvm' if mode != 'tcg' and cap['kvm'] else 'tcg'
            args = ['qemu-system-x86_64', '-name', 'prime-vm-' + vm_id,
                    '-machine', 'type=pc,accel=' + selected,
                    '-cpu', 'host' if selected == 'kvm' else 'qemu64', '-m', str(vm['memory']),
                    '-smp', str(vm['cpus']), '-drive', 'file=' + str(directory / 'disk.qcow2') + ',format=qcow2,if=virtio',
                    '-netdev', 'user,id=n0,hostfwd=tcp:127.0.0.1:' + str(ssh_port) + '-:22',
                    '-device', 'virtio-net-pci,netdev=n0',
                    '-display', 'none', '-vnc', 'unix:' + str(vnc_socket),
                    '-serial', 'file:' + str(directory / 'console.log'),
                    '-pidfile', str(pidfile), '-daemonize']
            if (directory / 'seed.iso').is_file():
                args.extend(['-drive', 'file=' + str(directory / 'seed.iso') + ',format=raw,if=virtio'])
            try:
                result = subprocess.run(args, capture_output=True, text=True, timeout=30)
                # A visible /dev/kvm may still be unusable in nested or restricted
                # containers. Automatic mode retries using software emulation.
                if result.returncode and mode == 'auto' and selected == 'kvm' and not self._running(vm_id):
                    selected = 'tcg'
                    args[args.index('-machine') + 1] = 'type=pc,accel=tcg'
                    args[args.index('-cpu') + 1] = 'qemu64'
                    pidfile.unlink(missing_ok=True)
                    result = subprocess.run(args, capture_output=True, text=True, timeout=30)
                if result.returncode:
                    raise VMError('QEMU could not start the VM: ' + result.stderr.strip()[-500:])
            except (OSError, subprocess.SubprocessError) as exc:
                raise VMError('QEMU could not start the VM') from exc
            if not self._running(vm_id):
                raise VMError('QEMU exited before the VM started')
            vm['ssh_port'] = ssh_port
            vm['active_acceleration'] = selected
            self._write(vm)
            return {'ok': True, 'running': True, 'acceleration': selected, 'ssh_port': ssh_port}

    def console(self, vm_id: str) -> str:
        self._read(vm_id)
        try:
            with (self._dir(vm_id) / 'console.log').open('rb') as log:
                log.seek(0, os.SEEK_END)
                log.seek(max(0, log.tell() - 65536))
                return log.read().decode('utf-8', errors='replace')
        except FileNotFoundError:
            return ''

    def stop(self, vm_id: str) -> Dict[str, Any]:
        with _LOCK:
            self._read(vm_id)
            pid = self._running(vm_id)
            if not pid:
                raise VMError('VM is not running')
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            for _ in range(50):
                if not self._running(vm_id):
                    return {'ok': True, 'running': False}
                time.sleep(0.1)
            raise VMError('VM did not stop; check its QEMU process')

    def delete(self, vm_id: str) -> Dict[str, bool]:
        with _LOCK:
            self._read(vm_id)
            if self._running(vm_id):
                raise VMError('Stop the VM before deleting it')
            self.vnc_socket(vm_id).unlink(missing_ok=True)
            shutil.rmtree(self._dir(vm_id))
            return {'ok': True}
