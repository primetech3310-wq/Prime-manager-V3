"""FastAPI application factory, middleware and static file serving."""
from __future__ import annotations
from typing import Optional

import asyncio
import logging
import os
import time
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from . import APP_NAME, __version__, sysinfo
from .config import Config
from .deps import Runtime
from .routes import management_routes, factor_routes
from .routes import (auth_routes, browser_routes, file_routes, ops_routes, public_routes,
                     system_routes, terminal_routes, toolkit_routes, ui_routes, vm_routes, update_routes, workspace_routes)

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
log = logging.getLogger("prime")


def setup_logging(cfg: Config) -> None:
    level = getattr(logging, str(cfg.log_level).upper(), logging.INFO)
    root = logging.getLogger("prime")
    root.setLevel(level)
    if root.handlers:
        return
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    try:
        os.makedirs(os.path.dirname(cfg.log_path), exist_ok=True)
        fh = RotatingFileHandler(cfg.log_path, maxBytes=2 * 1024 * 1024, backupCount=3)
        fh.setFormatter(fmt)
        root.addHandler(fh)
    except OSError:
        pass
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)
    root.propagate = False


async def _sampler(rt: Runtime) -> None:
    """Keep the CPU / net / process counters fresh so deltas are meaningful."""
    loop = asyncio.get_running_loop()
    while True:
        try:
            await loop.run_in_executor(None, sysinfo.CPU.sample)
            await loop.run_in_executor(None, sysinfo.NET.sample)
            await loop.run_in_executor(None, lambda: sysinfo.list_processes(limit=40))
            await rt.terms.reap_idle()
            rt.tunnels.sweep()
            rt.auth.sweep()
            rt.limiter.sweep()
            if os.environ.get('PRIME_WORKSPACE') != '1' and int(time.time()) % 30 < 2:
                from .workspaces import WorkspaceStore
                store = WorkspaceStore(rt.cfg.data_dir)
                if store.list():
                    await loop.run_in_executor(None, store.sweep)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — never let the sampler die
            log.exception("sampler iteration failed")
        await asyncio.sleep(2.0)


async def _vm_scheduler(rt: Runtime) -> None:
    from .vms import VMStore
    store = VMStore(rt.cfg.data_dir)
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, store.recover_schedules)
    while True:
        try:
            await loop.run_in_executor(None, store.run_due)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('VM scheduler iteration failed')
        await asyncio.sleep(5)


def create_app(cfg: Optional[Config] = None) -> FastAPI:
    cfg = cfg or Config.load()
    setup_logging(cfg)
    rt = Runtime(cfg)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        loop = asyncio.get_running_loop()
        log.info("%s %s starting on %s:%s (data dir %s, euid %s)", APP_NAME, rt.version,
                 cfg.host, cfg.port, cfg.data_dir, os.geteuid())
        task = asyncio.create_task(_sampler(rt))
        scheduler = (asyncio.create_task(_vm_scheduler(rt))
                     if os.environ.get('PRIME_WORKSPACE') != '1' else None)
        try:
            yield
        finally:
            task.cancel()
            if scheduler:
                scheduler.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
            if scheduler:
                await asyncio.gather(scheduler, return_exceptions=True)
            await loop.run_in_executor(None, rt.tunnels.shutdown)
            await rt.terms.close_all()
            log.info("shutdown complete")

    app = FastAPI(title=APP_NAME, version=__version__, docs_url=None, redoc_url=None,
                  openapi_url=None, lifespan=lifespan)
    app.state.rt = rt
    app.state.cfg = cfg

    # ----------------------------------------------------------- middleware
    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        workspace = os.environ.get('PRIME_WORKSPACE') == '1'
        if workspace and request.url.path.startswith(('/api/workspaces', '/API/', '/api/vms', '/api/updates', '/api/management', '/api/tenant', '/api/auth/accept-invitation')):
            return JSONResponse({'detail': 'Managed by the host administrator'}, status_code=403)
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("origin")
            if origin:
                from urllib.parse import urlsplit
                try:
                    if urlsplit(origin).netloc != request.headers.get("host", ""):
                        return JSONResponse({"detail": "cross-origin request blocked"},
                                            status_code=403)
                except ValueError:
                    return JSONResponse({"detail": "bad origin"}, status_code=403)
        started = time.time()
        try:
            response = await call_next(request)
        except HTTPException:
            raise
        except Exception:  # noqa: BLE001
            log.exception("unhandled error for %s %s", request.method, request.url.path)
            return JSONResponse({"detail": "internal server error"}, status_code=500)
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        if request.url.path.startswith("/static/"):
            response.headers["Cache-Control"] = "no-cache"
        # setdefault: a route that needs different headers (the sandboxed browser
        # proxy) sets its own before this middleware runs, and keeps them.
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        response.headers.setdefault("Content-Security-Policy", (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' ws: wss:; "
            "frame-src 'self' https://*.trycloudflare.com; "
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'"))
        if workspace:
            from urllib.parse import urlsplit
            parent = os.environ.get('PRIME_WORKSPACE_PARENT', '')
            parsed = urlsplit(parent)
            if parsed.scheme in ('http', 'https') and parsed.netloc and parent == parsed.scheme + '://' + parsed.netloc:
                if 'x-frame-options' in response.headers:
                    del response.headers['x-frame-options']
                response.headers['Content-Security-Policy'] = response.headers['Content-Security-Policy'].replace(
                    "frame-ancestors 'none'", 'frame-ancestors ' + parent)
        if cfg.secure_cookies:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["X-Response-Time"] = f"{(time.time() - started) * 1000:.1f}ms"
        return response

    # --------------------------------------------------------------- routes
    app.include_router(auth_routes.router)
    app.include_router(management_routes.router)
    app.include_router(factor_routes.router)
    app.include_router(system_routes.router)
    app.include_router(terminal_routes.router)
    app.include_router(file_routes.router)
    app.include_router(ops_routes.router)
    app.include_router(toolkit_routes.router)
    app.include_router(public_routes.router)
    app.include_router(ui_routes.router)
    app.include_router(vm_routes.router)
    app.include_router(update_routes.router)
    app.include_router(browser_routes.router)

    @app.get("/api/health")
    async def health():
        return {"ok": True, "name": APP_NAME, "version": rt.version,
                "uptime": round(time.time() - rt.started, 1)}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/")
    async def index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"),
                            headers={"Cache-Control": "no-store", "Clear-Site-Data": '"cache"'})

    @app.get("/favicon.svg")
    async def favicon():
        return FileResponse(os.path.join(STATIC_DIR, "favicon.svg"),
                            media_type="image/svg+xml")

    @app.get("/manifest.webmanifest")
    async def manifest():
        return FileResponse(os.path.join(STATIC_DIR, "manifest.webmanifest"),
                            media_type="application/manifest+json")

    @app.get("/robots.txt")
    async def robots():
        return Response("User-agent: *\nDisallow: /\n", media_type="text/plain")

    app.include_router(workspace_routes.router)
    return app


def run() -> None:
    import uvicorn
    cfg = Config.load()
    app = create_app(cfg)
    kwargs = {}
    if cfg.behind_proxy:
        kwargs["proxy_headers"] = True
        kwargs["forwarded_allow_ips"] = ",".join(cfg.trusted_proxies)
    uvicorn.run(app, host=cfg.host, port=cfg.port, log_level=cfg.log_level.lower(),
                access_log=False, timeout_keep_alive=30, **kwargs)
