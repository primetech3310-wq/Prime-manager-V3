/** Local QEMU VM management for the authenticated panel administrator. */
import { api } from '../api.js';
import { icon } from '../icons.js';
import * as ui from '../ui.js';
import { esc } from '../ui.js';
import { showRecovery } from './vm-recovery.js';
import { showConsole } from './vm-console.js';

let activeSheet;

function markup(data) {
  const cap = data.capabilities;
  const cards = data.items.map(vm => `<div class="list-row" style="cursor:default;flex-wrap:wrap">
    <div class="grow"><div class="title">${esc(vm.name)}</div>
      <div class="faint">${vm.cpus} CPU · ${vm.memory} MiB · ${vm.running ? 'Running' : 'Stopped'}${vm.running && vm.ssh_port ? ` · SSH 127.0.0.1:${vm.ssh_port}` : ''}</div></div>
    <div class="row wrap">
      <button class="btn btn-sm" data-vm="${vm.id}" data-action="${vm.running ? 'stop' : 'start'}">${vm.running ? 'Stop' : 'Start'}</button>
      <button class="btn btn-sm" data-vm="${vm.id}" data-action="console">Boot log</button>
      <button class="btn btn-sm" data-vm="${vm.id}" data-action="vnc" ${vm.running ? '' : 'disabled'}>Graphical console</button>
      <button class="btn btn-sm" data-vm="${vm.id}" data-action="recovery">Recovery & schedules</button>
      <button class="btn btn-sm" data-vm="${vm.id}" data-action="restart" ${vm.running ? '' : 'disabled'}>Restart</button>
      <button class="btn btn-sm btn-danger" data-vm="${vm.id}" data-action="delete" ${vm.running ? 'disabled' : ''}>Delete</button>
    </div></div>`).join('');
  return `<div class="stack"><div class="card"><div class="card-head"><div class="card-title-icon">${icon('layers')}</div>
    <div><h3>Virtual machines</h3><div class="sub">Local QEMU guests managed by the panel</div></div></div>
    <div class="notice ${cap.available ? 'info' : 'warn'}">${icon('info')}<div>${cap.available
      ? `QEMU available · ${cap.kvm ? 'KVM acceleration' : 'software emulation (TCG)'}`
      : 'Install qemu-system-x86_64 and qemu-img to create VMs.'}</div></div>
    <p class="faint">Use a bootable raw or QCOW2 image on this host. For a cloud-init image, optionally set a guest login below; otherwise use credentials already in the image. VM SSH is forwarded to loopback only. These are administrator VMs, not private tenant workspaces.</p>
    <form id="vm-create" class="stack">
      <label class="field">Name <input class="input" name="name" required maxlength="64" placeholder="My VM"></label>
      <label class="field">Local image path <input class="input mono" name="image" required placeholder="/path/to/image.qcow2"></label>
      <button type="button" class="btn btn-sm" id="vm-image-download">${icon('download')}Download Debian 12 cloud image</button>
      <div class="faint" id="vm-image-status">Downloads and verifies the official image; later uses reuse the cached copy.</div>
      <div class="row wrap"><label class="field grow">Memory (MiB) <input class="input" name="memory" type="number" value="1024" min="128" max="65536" required></label>
      <label class="field grow">CPUs <input class="input" name="cpus" type="number" value="1" min="1" max="64" required></label></div>
      <label class="field">Acceleration<select class="input" name="acceleration"><option value="auto">Automatic (falls back to software)</option><option value="tcg">Software emulation — works without KVM</option><option value="kvm">Require KVM</option></select></label>
      <label class="field">Guest username (optional, cloud-init images) <input class="input" name="username" maxlength="31" autocomplete="off" ${cap.cloud_init ? '' : 'disabled'}></label>
      <label class="field">Guest password <input class="input" name="password" type="password" maxlength="256" autocomplete="new-password" ${cap.cloud_init ? '' : 'disabled'}></label>
      ${cap.cloud_init ? '' : '<p class="faint">Install cloud-localds and openssl to configure guest credentials.</p>'}
      <button type="submit" class="btn btn-primary" ${cap.available ? '' : 'disabled'}>${icon('plus')}Create VM</button>
    </form></div><div class="card"><div class="card-head"><div><h3>VMs</h3><div class="sub">Disk copies remain in the panel data directory</div></div></div>
    <div class="list">${cards || ui.emptyState('No VMs yet', 'layers')}</div></div></div>`;
}

export default {
  title: 'Virtual machines', crumb: 'local QEMU guests',
  async mount(container) {
    const refresh = async () => {
      const data = await api.get('/api/vms');
      if (container.isConnected) container.innerHTML = markup(data);
    };
    container.innerHTML = ui.skeletonRows(2, 120);
    try { await refresh(); } catch (err) { container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), 'alert')}</div>`; return; }
    container.addEventListener('submit', async event => {
      if (event.target.id !== 'vm-create') return;
      event.preventDefault();
      const form = event.target, button = form.querySelector('button[type=submit]');
      const fields = new FormData(form);
      button.disabled = true;
      button.textContent = 'Preparing disk…';
      try {
        await api.post('/api/vms', {name: fields.get('name'), image: fields.get('image'),
          memory: Number(fields.get('memory')), cpus: Number(fields.get('cpus')),
          username: fields.get('username') || '', password: fields.get('password') || '', acceleration: fields.get('acceleration')});
        ui.notifyOk('VM created', 'Start it when ready.');
        await refresh();
      } catch (err) { ui.showError(err, 'Could not create VM'); button.disabled = false; button.textContent = 'Create VM'; }
    });
    container.addEventListener('click', async event => {
      const download = event.target.closest('#vm-image-download');
      if (download) {
        download.disabled = true;
        const status = container.querySelector('#vm-image-status');
        status.textContent = 'Downloading and verifying the image; this can take several minutes…';
        try {
          const result = await api.post('/api/vms/images/debian');
          if (container.isConnected) {
            container.querySelector('input[name=image]').value = result.path;
            status.textContent = result.cached ? 'Verified cached image ready.' : 'Downloaded and verified image ready.';
          }
        } catch (err) {
          if (status.isConnected) status.textContent = ui.errorText(err);
          ui.showError(err, 'Could not download the image');
        } finally { if (download.isConnected) download.disabled = false; }
        return;
      }
      const button = event.target.closest('[data-vm]');
      if (!button) return;
      const { vm, action } = button.dataset;
      if (action === 'delete') {
        const ok = await ui.confirmDialog({title:'Delete VM?', message:'Its disk, boot log, backups, snapshots and schedules will be permanently removed.', confirmLabel:'Delete', danger:true});
        if (!ok) return;
      }
      button.disabled = true;
      try {
        if (action === 'recovery' || action === 'vnc') {
          activeSheet = await (action === 'recovery' ? showRecovery(vm) : showConsole(vm));
          if (!container.isConnected) ui.closeSheet(activeSheet);
        } else if (action === 'console') {
          const result = await api.get(`/api/vms/${vm}/console`);
          ui.sheet({title:'VM boot log', content:`<pre class="code-out">${esc(result.content || 'No boot output yet.')}</pre>`});
        } else {
          await api.post(`/api/vms/${vm}/${action}`);
          ui.notifyOk('VM ' + action, 'Action completed.');
          await refresh();
        }
      } catch (err) { ui.showError(err, 'VM action failed'); }
      finally { if (button.isConnected) button.disabled = false; }
    });
  },
  unmount() { if (activeSheet) ui.closeSheet(activeSheet); activeSheet = null; },
};
