<!-- coderabbit-ai-generated:v1 -->

# Start here

This ZIP contains the updated Prime Terminal Manager source, installer, tests and guides. It runs QEMU VMs without KVM and adds the private workspace APIs and ZIP update workflow. Original source code came from your repository's v1.2.0 archive; the interface design is retained.

1. Extract the ZIP on your Linux server.
2. Run `bash panel.sh` to install/start the panel. Configure a strong admin password when prompted or through the existing installer options.
3. Run `bash panel.sh vm-deps` for QEMU/cloud-init tools. In Virtual machines, download Debian, set guest credentials, choose Software emulation, create and start.
4. Run `bash panel.sh workspace-deps` for local Docker/firewall checks. In Private workspaces, build the runtime, choose resource settings, then create a workspace or a provisioning API key. KVM is not used by this backend.
5. Set `public_url` in your panel config to the real external HTTPS URL before distributing workspace links.

Read [deployment instructions](docs/DEPLOYMENT.md), [workspace/API instructions](docs/WORKSPACES.md), [VM instructions](docs/VMS.md), [update instructions](docs/UPDATES.md) and the [feature scope](docs/FEATURES.md). Download the custom CSS guide inside Settings → Appearance.

## Tested

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:926e052af4ba4683bdfec5817881889689ba25642e9c003128afc2416f40830e -->

- Real Debian VM boot and SSH under QEMU TCG without /dev/kvm.
- Real disk backup/snapshot restore, schedule persistence/retention and authenticated VNC protocol connection with logout revocation.

<!-- /coderabbit-ai-generated:v1 -->
- Successful ZIP update/restart and automatic recovery after a deliberately failed release; test account/data preserved.
- Real SSHx, full panel and ttyd workspaces, plus bearer-key authentication/revocation and CSRF rejection.
- Mobile cloud Chromium: real panel/ttyd commands, SSHx command execution, fullscreen controls and responsive layouts.
- Host/peer port blocking, private filesystems, host PID signal rejection, and stopping a container after a required isolation rule was removed.

## Remaining limits

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:b6b09d32588b2c56bb474461258a1250cbecdc96ede7ae84d35292e9f80f8447 -->

This build adds tenant invitations, VM permissions, two-factor authentication and a billing ledger; read docs/ACCOUNTS.md. Full vPanel parity is still incomplete. See docs/FEATURES.md for the explicit remaining feature list.

<!-- /coderabbit-ai-generated:v1 -->

Workspaces require Linux x86_64, a local rootful Docker daemon and host firewall access. Limited resource mode needs CPU/memory/PID cgroups and could not run in this sandbox. Shared resource mode was explicitly tested; it omits per-workspace quotas and cannot prevent resource exhaustion. No software can supply unavailable kernel permissions on every restricted host. External session providers and host uptime also affect availability.
