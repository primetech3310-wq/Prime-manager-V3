"""Tests for local QEMU lifecycle and VM path validation."""
import shutil
import json
import hashlib
import io
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from prime.vms import VMError, VMStore, capabilities


class VMTests(unittest.TestCase):
    def test_cloud_download_verifies_checksum_and_cache(self):
        data = b'synthetic cloud image'
        digest = hashlib.sha512(data).hexdigest()

        class Response(io.BytesIO):
            def __init__(self, content, url):
                super().__init__(content)
                self.url = url
                self.headers = {'Content-Length': str(len(content))}

            def geturl(self):
                return self.url

        def open_url(url, timeout):
            if url.endswith('SHA512SUMS'):
                manifest = f'{digest}  debian-12-genericcloud-amd64.qcow2\n'.encode()
                return Response(manifest, url)
            return Response(data, 'https://mirror.example/debian-12-genericcloud-amd64.qcow2')

        with tempfile.TemporaryDirectory() as directory, patch('prime.vms.urllib.request.urlopen', side_effect=open_url):
            store = VMStore(directory)
            first = store.download_debian()
            self.assertFalse(first['cached'])
            self.assertEqual(Path(first['path']).read_bytes(), data)
            self.assertTrue(store.download_debian()['cached'])
            Path(first['path']).write_bytes(b'tampered')
            self.assertFalse(store.download_debian()['cached'])
            self.assertEqual(Path(first['path']).read_bytes(), data)

    def test_cloud_download_rejects_bad_checksum(self):
        class Response(io.BytesIO):
            headers = {}
            def geturl(self):
                return 'https://mirror.example/debian-12-genericcloud-amd64.qcow2'

        def open_url(url, timeout):
            if url.endswith('SHA512SUMS'):
                return Response((('0' * 128) + '  debian-12-genericcloud-amd64.qcow2\n').encode())
            return Response(b'not the expected image')

        with tempfile.TemporaryDirectory() as directory, patch('prime.vms.urllib.request.urlopen', side_effect=open_url):
            store = VMStore(directory)
            with self.assertRaises(VMError):
                store.download_debian()
            self.assertFalse((Path(directory) / 'vm-images' / 'debian-12-genericcloud-amd64.qcow2').exists())

    def test_rejects_invalid_ids_and_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            store = VMStore(directory)
            for bad in ('../other', '', '0' * 31, 'g' * 32):
                with self.subTest(bad=bad), self.assertRaises(VMError):
                    store.stop(bad)
            if capabilities()['available']:
                with self.assertRaises(VMError):
                    store.create('bad/name', '/missing', 512, 1)
                with self.assertRaises(VMError):
                    store.create('vm', '/missing', 512, 1)
                with self.assertRaises(VMError):
                    store.create('vm', '/missing', 512, 1, 'root', 'password123')
                with self.assertRaises(VMError):
                    store.create('vm', '/missing', 512, 1, 'testuser', 'short')

    @unittest.skipUnless(shutil.which('qemu-img') and shutil.which('qemu-system-x86_64'), 'QEMU unavailable')
    def test_auto_retries_tcg_when_visible_kvm_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            image = Path(directory) / 'disk.raw'
            image.write_bytes(bytes(1024 * 1024))
            store = VMStore(directory)
            vm = store.create('fallback', str(image), 128, 1)
            original = subprocess.run
            attempts = []
            def run(args, **kwargs):
                if args[0] == 'qemu-system-x86_64':
                    attempts.append(args[args.index('-machine') + 1])
                    if 'accel=kvm' in args[args.index('-machine') + 1]:
                        return subprocess.CompletedProcess(args, 1, '', 'KVM not permitted')
                return original(args, **kwargs)
            fake_cap = dict(capabilities(), kvm=True, acceleration='kvm')
            try:
                with patch('prime.vms.capabilities', return_value=fake_cap), patch('prime.vms.subprocess.run', side_effect=run):
                    result = store.start(vm['id'])
                self.assertEqual(result['acceleration'], 'tcg')
                self.assertEqual(attempts, ['type=pc,accel=kvm', 'type=pc,accel=tcg'])
            finally:
                if store._running(vm['id']):
                    store.stop(vm['id'])

    @unittest.skipUnless(all(shutil.which(c) for c in ('qemu-img', 'qemu-system-x86_64', 'cloud-localds', 'openssl', 'isoinfo')), 'cloud-init tools unavailable')
    def test_cloud_seed_contains_hash_and_no_plaintext(self):
        with tempfile.TemporaryDirectory() as directory:
            image = Path(directory) / 'disk.raw'
            with image.open('wb') as f:
                f.truncate(1024 * 1024)
            store = VMStore(directory)
            secret = 'TestPassword123!'
            vm = store.create('cloud', str(image), 128, 1, 'testuser', secret)
            base = store.root / vm['id']
            seed = base / 'seed.iso'
            self.assertNotIn(secret.encode(), seed.read_bytes())
            self.assertNotIn(secret, (base / 'vm.json').read_text())
            self.assertFalse((base / 'user-data').exists())
            self.assertEqual(seed.stat().st_mode & 0o777, 0o600)
            raw = subprocess.run(['isoinfo', '-i', str(seed), '-x', '/USER_DAT.;1'],
                                 capture_output=True, check=True).stdout
            self.assertTrue(raw.startswith(b'#cloud-config\n'))
            config = json.loads(raw.split(b'\n', 1)[1])
            self.assertTrue(config['disable_root'])
            self.assertEqual(config['users'][1]['name'], 'testuser')
            self.assertTrue(config['users'][1]['passwd'].startswith('$6$'))
            try:
                self.assertTrue(store.start(vm['id'])['running'])
                self.assertFalse(store.stop(vm['id'])['running'])
            finally:
                if store._running(vm['id']):
                    store.stop(vm['id'])

    @unittest.skipUnless(shutil.which('qemu-img') and shutil.which('qemu-system-x86_64'), 'QEMU unavailable')
    def test_real_qemu_create_start_stop_delete(self):
        with tempfile.TemporaryDirectory() as directory:
            image = Path(directory) / 'empty.raw'
            with image.open('wb') as f:
                # Tiny x86 boot sector emits a marker to COM1, then halts.
                code = bytearray(b'\xba\xf8\x03')
                for byte in b'VM_BOOT_OK':
                    code.extend((0xb0, byte, 0xee))
                code.extend(b'\xf4\xeb\xfd')
                f.write(code.ljust(510, b'\0') + b'\x55\xaa')
                f.truncate(1024 * 1024)
            store = VMStore(directory)
            vm = store.create('test vm', str(image), 128, 1)
            ident = vm['id']
            self.assertEqual(len(store.list()), 1)
            try:
                self.assertTrue(store.start(ident)['running'])
                self.assertTrue(store.list()[0]['running'])
                for _ in range(50):
                    if 'VM_BOOT_OK' in store.console(ident):
                        break
                    time.sleep(0.1)
                self.assertIn('VM_BOOT_OK', store.console(ident))
                with self.assertRaises(VMError):
                    store.delete(ident)
                self.assertFalse(store.stop(ident)['running'])
            finally:
                if store._running(ident):
                    store.stop(ident)
            self.assertTrue(store.delete(ident)['ok'])
            self.assertEqual(store.list(), [])


if __name__ == '__main__':
    unittest.main()
