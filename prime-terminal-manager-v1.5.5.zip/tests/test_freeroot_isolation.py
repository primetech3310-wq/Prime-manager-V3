"""Isolation rules for proot workspaces (prime/freeroot_isolation.py).

Pure tests: they check the decision and the command lines. Nothing here starts
bubblewrap. The live check that connects to a host service on port 5555 and
tries to see host processes is scripts/isolation_check.sh, run on the host.
"""
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from prime import freeroot, freeroot_isolation as iso
from prime.freeroot import FreeRootError, FreeRootManager, panel_owner


BWRAP_SLIRP = {"bwrap": "/usr/bin/bwrap", "bwrap_works": True, "pasta_works": False,
               "slirp4netns": "/usr/bin/slirp4netns", "slirp_works": True}
BWRAP_PASTA = {"bwrap": "/usr/bin/bwrap", "bwrap_works": True, "pasta": "/usr/bin/pasta",
               "pasta_works": True, "slirp_works": False}
NOTHING = {"bwrap_works": False, "pasta_works": False, "slirp_works": False}


class PlanTests(unittest.TestCase):
    def test_pasta_preferred_when_it_works(self):
        self.assertEqual(iso.plan(BWRAP_PASTA, env={}), {"mode": "bwrap", "net": "pasta"})

    def test_slirp_used_when_pasta_missing(self):
        self.assertEqual(iso.plan(BWRAP_SLIRP, env={}), {"mode": "bwrap", "net": "slirp4netns"})

    def test_refused_without_namespaces_by_default(self):
        with self.assertRaises(iso.IsolationError) as ctx:
            iso.plan(NOTHING, env={})
        self.assertIn("PRIME_FREEROOT_ALLOW_WEAK=1", str(ctx.exception))

    def test_weak_mode_only_when_admin_opts_in(self):
        self.assertEqual(iso.plan(NOTHING, env={iso.WEAK_ENV: "1"}),
                         {"mode": "proot-only", "net": "shared-host"})
        with self.assertRaises(iso.IsolationError):
            iso.plan(NOTHING, env={iso.WEAK_ENV: "yes"})

    def test_bwrap_without_any_network_helper_is_refused(self):
        with self.assertRaises(iso.IsolationError):
            iso.plan({"bwrap_works": True, "pasta_works": False, "slirp_works": False}, env={})

    def test_none_backends_is_refused(self):
        with self.assertRaises(iso.IsolationError):
            iso.plan(None, env={})


class NamespaceArgvTests(unittest.TestCase):
    def _prefix(self, net, pasta=None):
        return iso.bwrap_prefix(bwrap="/usr/bin/bwrap", instance=Path("/data/freeroot/instances/fr-1"),
                                proot_bin=Path("/data/freeroot/bin/proot"), hostname="pw-1",
                                net=net, pasta=pasta)

    def test_private_pid_ipc_uts_and_no_host_root(self):
        argv = self._prefix("slirp4netns")
        for flag in ("--unshare-pid", "--unshare-ipc", "--unshare-uts", "--cap-drop", "--clearenv",
                     "--die-with-parent", "--new-session"):
            self.assertIn(flag, argv)
        binds = [argv[i + 1] for i, a in enumerate(argv) if a in ("--bind", "--ro-bind")]
        # Only the workspace's own directory and the proot binary are mapped in.
        self.assertIn("/data/freeroot/instances/fr-1", binds)
        self.assertIn("/data/freeroot/bin/proot", binds)
        self.assertNotIn("/", binds)
        self.assertNotIn("/data", binds)
        self.assertNotIn("/root", binds)

    def test_slirp_gets_a_private_network_namespace(self):
        argv = self._prefix("slirp4netns")
        self.assertIn("--unshare-net", argv)
        self.assertNotIn("pasta", argv[0])

    def test_pasta_wraps_and_owns_the_namespace(self):
        argv = self._prefix("pasta", pasta="/usr/bin/pasta")
        self.assertEqual(argv[0], "/usr/bin/pasta")
        self.assertIn("--config-net", argv)
        self.assertNotIn("--unshare-net", argv)
        self.assertEqual(argv[argv.index("-t") + 1], "none")
        self.assertEqual(argv[argv.index("-u") + 1], "none")

    def test_pasta_without_binary_is_refused(self):
        with self.assertRaises(iso.IsolationError):
            self._prefix("pasta", pasta=None)

    def test_host_runtime_only_read_only(self):
        for i, a in enumerate(self._prefix("slirp4netns")):
            if a == "--bind":
                self.assertIn(self._prefix("slirp4netns")[i + 1], ("/data/freeroot/instances/fr-1",))

    def test_slirp_disables_host_loopback(self):
        argv = iso.slirp_argv("/usr/bin/slirp4netns", 4242)
        self.assertIn("--disable-host-loopback", argv)
        self.assertIn("4242", argv)

    def test_proot_without_sys_inside_namespaces(self):
        inside = freeroot.proot_argv("/p/proot", Path("/r"), [], ["/bin/sh"], sys_bind=False)
        outside = freeroot.proot_argv("/p/proot", Path("/r"), [], ["/bin/sh"], sys_bind=True)
        self.assertNotIn("/sys", inside)
        self.assertIn("/sys", outside)

    def test_probe_script_targets_host_port_and_pid(self):
        script = iso.probe_script(4242, 5555)
        self.assertIn("127.0.0.1:5555", script)
        self.assertIn("10.0.2.2:5555", script)
        self.assertIn("kill -0 4242", script)


class WorkspaceDecisionTests(unittest.TestCase):
    def test_refused_on_hosts_without_namespaces(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = FreeRootManager(tmp, backends=NOTHING)
            mgr.template.mkdir(parents=True)
            (mgr.template / "bin").mkdir()
            (mgr.template / "bin" / "sh").write_text("")
            (mgr.template / "usr" / "bin").mkdir(parents=True)
            (mgr.template / "usr" / "bin" / "curl").write_text("")
            (mgr.template / "root").mkdir()
            mgr.proot_bin.parent.mkdir(parents=True)
            mgr.proot_bin.write_bytes(b"x" * 1100)
            with mock.patch.object(FreeRootManager, "_start_worker", lambda self, sid: None):
                record = mgr.create_for(panel_owner("zed"), 3600)
            self.assertEqual(record["status"], "preparing")  # the request itself succeeded
            mgr._prepare_and_launch(record["id"])  # the background step decides and refuses
            shown = mgr.status_for(panel_owner("zed"), record["id"])
            self.assertEqual(shown["status"], "failed")
            self.assertIn("PRIME_FREEROOT_ALLOW_WEAK=1", shown["error"])


class BackgroundBuildTests(unittest.TestCase):
    """Creating a workspace must return at once, even when the base image is still being built."""

    def _mgr(self, tmp):
        mgr = FreeRootManager(tmp, backends={"bwrap_works": True, "slirp_works": True,
                                             "bwrap": "/usr/bin/bwrap", "slirp4netns": "/usr/bin/slirp4netns"})
        return mgr

    def test_create_returns_preparing_without_building_inline(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = self._mgr(tmp)
            calls = []
            with mock.patch.object(FreeRootManager, "_start_worker", lambda self, sid: calls.append(sid)), \
                    mock.patch.object(FreeRootManager, "ensure_template",
                                      lambda self: calls.append("BUILD-INLINE")):
                result = mgr.create_for(panel_owner("ann"), 3600)
            self.assertEqual(result["status"], "preparing")
            self.assertEqual(calls, [result["id"]])  # the build was not run in the request

    def test_failed_base_build_is_reported_on_the_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = self._mgr(tmp)
            with mock.patch.object(FreeRootManager, "_start_worker", lambda self, sid: None):
                record = mgr.create_for(panel_owner("ben"), 3600)
            with mock.patch.object(FreeRootManager, "ensure_template",
                                   side_effect=FreeRootError("download failed: no route to host")):
                mgr._prepare_and_launch(record["id"])
            shown = mgr.status_for(panel_owner("ben"), record["id"])
            self.assertEqual(shown["status"], "failed")
            self.assertIn("no route to host", shown["error"])


if __name__ == "__main__":
    unittest.main()
