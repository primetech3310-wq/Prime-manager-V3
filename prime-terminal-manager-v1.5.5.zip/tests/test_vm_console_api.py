"""Real HTTP, authentication and binary VNC WebSocket integration."""
import asyncio
import http.cookiejar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

import websockets
from websockets.exceptions import ConnectionClosed, InvalidStatus


@unittest.skipUnless(shutil.which('qemu-img') and shutil.which('qemu-system-x86_64'), 'QEMU unavailable')
class ConsoleAPITests(unittest.TestCase):
    def test_workspace_websocket_cannot_reach_host_vm_console(self):
        from prime.routes.vm_routes import vm_vnc
        class Socket:
            code = None
            async def close(self, code):
                self.code = code
        ws = Socket()
        with patch.dict(os.environ, {'PRIME_WORKSPACE': '1'}):
            asyncio.run(vm_vnc(ws, '0' * 32))
        self.assertEqual(ws.code, 4403)

    def test_auth_recovery_schedule_and_real_rfb_bridge(self):
        source = Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            image = root / 'image.raw'
            image.write_bytes(bytes(1048576))
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', 0))
                port = probe.getsockname()[1]
            base = f'http://127.0.0.1:{port}'
            ws_base = f'ws://127.0.0.1:{port}'
            env = dict(os.environ, PRIME_HOST='127.0.0.1', PRIME_PORT=str(port),
                       PRIME_DATA_DIR=str(root / 'data'), PRIME_CONFIG=str(root / 'config.json'))
            (root / 'config.json').write_text('{}')
            jar = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), urllib.request.ProxyHandler({}))
            csrf = ''

            def call(path, body=None, with_csrf=True):
                headers = {'Content-Type': 'application/json'}
                if with_csrf:
                    headers['X-PRIME-CSRF'] = csrf
                request = urllib.request.Request(base + path, headers=headers,
                                                 data=json.dumps(body).encode() if body is not None else None)
                with opener.open(request, timeout=20) as response:
                    return json.load(response)

            process = subprocess.Popen([sys.executable, 'run.py'], cwd=source, env=env,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vm_id = None
            try:
                for _ in range(100):
                    try:
                        if call('/api/health')['ok']:
                            break
                    except OSError:
                        time.sleep(.05)
                else:
                    self.fail('Test panel did not start')
                with self.assertRaises(urllib.error.HTTPError) as caught:
                    call('/api/vms')
                self.assertEqual(caught.exception.code, 401)
                caught.exception.close()
                csrf = call('/api/auth/setup', {'username':'admin', 'password':'SyntheticTestPass_123!'})['csrf']
                vm_id = call('/api/vms', {'name':'Console test', 'image':str(image), 'memory':128, 'cpus':1, 'acceleration':'tcg'})['id']
                prefix = f'/api/vms/{vm_id}'
                with self.assertRaises(urllib.error.HTTPError) as caught:
                    call(prefix + '/backups', {'label':'Blocked'}, with_csrf=False)
                self.assertEqual(caught.exception.code, 403)
                caught.exception.close()
                for kind in ('backups', 'snapshots'):
                    item = call(prefix + '/' + kind, {'label':'API recovery'})
                    self.assertEqual(call(prefix + '/recovery')[kind][0]['id'], item['id'])
                    self.assertTrue(call(prefix + '/' + kind + '/' + item['id'] + '/restore', {})['ok'])
                # The actual lifespan scheduler must execute this one-time job.
                schedule = call(prefix + '/schedules', {'label':'Test scheduler', 'action':'stop', 'run_at':time.time()+.5})
                for _ in range(140):
                    item = call(prefix + '/recovery')['schedules'][0]
                    if item['state'] == 'complete':
                        break
                    time.sleep(.05)
                self.assertEqual(item['id'], schedule['id'])
                self.assertEqual(item['state'], 'complete')
                self.assertFalse(item['enabled'])
                call(prefix + '/start', {})
                cookie = '; '.join(f'{c.name}={c.value}' for c in jar)

                async def exercise_bridge():
                    url = ws_base + prefix + '/vnc'
                    async def denied(target, headers=None):
                        with self.assertRaises(InvalidStatus) as error:
                            async with websockets.connect(target, additional_headers=headers, proxy=None):
                                self.fail('Unauthorized VNC connection accepted')
                        self.assertEqual(error.exception.response.status_code, 403)

                    await denied(url)
                    await denied(url, {'Cookie':cookie})
                    ticket = call('/api/auth/ws-ticket', {})['ticket']
                    await denied(url + '?ticket=' + ticket, {'Cookie':cookie, 'Origin':'http://elsewhere.invalid'})
                    # A rejected origin must not consume a valid ticket.
                    async with websockets.connect(url + '?ticket=' + ticket,
                                                  additional_headers={'Cookie':cookie, 'Origin':base},
                                                  subprotocols=['binary'], proxy=None) as connection:
                        greeting = await asyncio.wait_for(connection.recv(), 3)
                        self.assertEqual(greeting, b'RFB 003.008\n')
                        self.assertEqual(connection.subprotocol, 'binary')
                        await denied(url + '?ticket=' + ticket, {'Cookie':cookie})
                        call('/api/auth/logout', {})
                        with self.assertRaises(ConnectionClosed):
                            await asyncio.wait_for(connection.recv(), 18)

                asyncio.run(exercise_bridge())
                # Reauthenticate only to clean up the disposable guest.
                csrf = call('/api/auth/login', {'username':'admin', 'password':'SyntheticTestPass_123!'})['csrf']
                call(prefix + '/stop', {})
                call(prefix + '/delete', {})
                vm_id = None
            finally:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                if vm_id:
                    from prime.vms import VMStore
                    store = VMStore(str(root / 'data'))
                    if store._running(vm_id):
                        store.stop(vm_id)
