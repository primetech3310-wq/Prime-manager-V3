import hashlib
import json
import tempfile
import unittest
from unittest.mock import patch

from prime.workspaces import WorkspaceError, WorkspaceStore


class WorkspaceTests(unittest.TestCase):
    def test_provisioning_keys_are_hashed_and_revocable(self):
        with tempfile.TemporaryDirectory() as directory:
            store = WorkspaceStore(directory)
            key = store.create_key('automation')
            self.assertTrue(store.authenticate_key(key['key']))
            self.assertFalse(store.authenticate_key('wrong'))
            raw = store.settings_path.read_text()
            self.assertNotIn(key['key'], raw)
            self.assertNotIn('hash', json.dumps(store.public_settings()))
            store.revoke_key(key['id'])
            self.assertFalse(store.authenticate_key(key['key']))

    def test_settings_and_identifiers_are_validated(self):
        with tempfile.TemporaryDirectory() as directory:
            store = WorkspaceStore(directory)
            for ident in ('../../etc/passwd', '', 'g' * 32):
                with self.assertRaises(WorkspaceError):
                    store.read(ident)
            for values in ({'alias': '../bad'}, {'alias': 'sshx'}, {'cpus': 0}, {'ttl': 86401}, {'memory_mb': True}):
                with self.assertRaises(WorkspaceError):
                    store.save_settings(values)
            settings = store.save_settings({'alias': 'myterminal', 'ttl': 7200})
            self.assertEqual(settings['alias'], 'myterminal')
            self.assertEqual(WorkspaceStore(directory).settings()['ttl'], 7200)

    def test_private_link_checks_secret_expiry_and_container_state(self):
        with tempfile.TemporaryDirectory() as directory:
            store = WorkspaceStore(directory)
            record = {'id': 'a' * 32, 'access_hash': hashlib.sha256(b'secret').hexdigest(),
                      'expires_at': 10**12, 'state': 'running', 'kind': 'panel', 'provider_url': 'https://synthetic.trycloudflare.com'}
            store._path(record['id']).write_text(json.dumps(record))
            with self.assertRaises(WorkspaceError):
                store.open(record['id'], 'wrong')
            with patch.object(store, '_container', return_value={'State': {'Running': True}}), patch.object(store, 'verify_policy'):
                self.assertEqual(store.open(record['id'], 'secret')['url'], record['provider_url'] + '/#secret')
            record['expires_at'] = 1
            store._path(record['id']).write_text(json.dumps(record))
            with self.assertRaises(WorkspaceError):
                store.open(record['id'], 'secret')


if __name__ == '__main__':
    unittest.main()
