"""Regression checks for persistent appearance settings."""
import tempfile
import unittest

from prime.config import Config
from prime.uisettings import DEFAULTS, UISettingsError, UISettingsStore, validate


class AppearanceSettingsTests(unittest.TestCase):
    def test_old_settings_gain_defaults_and_new_values_survive_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            store = UISettingsStore(Config(data_dir=directory))
            store.update({"accent": "#ff453a"})
            store.update({"custom_css": ".card { color: red; }", "orb_two": False,
                          "ambient_speed": 150, "secondary_accent": "#112233"})
            settings = UISettingsStore(Config(data_dir=directory)).get()
            self.assertEqual(settings["accent"], "#ff453a")
            self.assertEqual(settings["custom_css"], ".card { color: red; }")
            self.assertFalse(settings["orb_two"])
            self.assertEqual(settings["ambient_speed"], 150)
            self.assertEqual(settings["secondary_accent"], "#112233")
            self.assertEqual(settings["glass_blur"], DEFAULTS["glass_blur"])
            self.assertEqual(store.reset(), DEFAULTS)

    def test_invalid_values_are_rejected(self):
        for payload in ({"ambient_speed": 0}, {"orb_one": 1},
                        {"secondary_accent": "red"}, {"custom_css": "x" * 65537},
                        {"custom_css": "a\x00b"}, {"unknown": True}):
            with self.subTest(payload=next(iter(payload))), self.assertRaises(UISettingsError):
                validate(payload)


if __name__ == "__main__":
    unittest.main()
