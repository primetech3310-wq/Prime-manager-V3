"""Unit tests for per-account port and process visibility (prime/port_scope.py)."""
import tempfile
import unittest

from prime.port_scope import ALL, PortScope, PortScopeError


PORTS = [
    {"port": 22, "user": "root", "pid": 1},
    {"port": 8080, "user": "alice", "pid": 200},
    {"port": 9090, "user": "bob", "pid": 300},
    {"port": 5353, "user": None, "pid": None},
]


class PortScopeTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.scope = PortScope(self._tmp.name, primary="owner")

    def tearDown(self):
        self._tmp.cleanup()

    def test_primary_account_sees_everything_by_default(self):
        self.assertEqual(self.scope.os_user_for("owner"), ALL)
        self.assertEqual(len(self.scope.filter_items("owner", PORTS)), len(PORTS))

    def test_unmapped_account_sees_nothing(self):
        self.assertIsNone(self.scope.os_user_for("carol"))
        self.assertEqual(self.scope.filter_items("carol", PORTS), [])

    def test_mapped_account_sees_only_its_os_user(self):
        self.scope.set_mapping("alice", "root")
        visible = self.scope.filter_items("alice", PORTS)
        self.assertEqual([p["port"] for p in visible], [22])

    def test_two_accounts_cannot_see_each_other(self):
        self.scope.set_mapping("alice", "root")
        self.scope.set_mapping("bob", "nobody")
        self.assertEqual([p["port"] for p in self.scope.filter_items("bob", PORTS)], [])
        self.assertEqual([p["port"] for p in self.scope.filter_items("alice", PORTS)], [22])

    def test_socket_without_owner_is_hidden_from_mapped_accounts(self):
        self.scope.set_mapping("alice", "root")
        self.assertFalse(self.scope.visible("alice", None))
        self.assertFalse(self.scope.visible("alice", ""))

    def test_explicit_all_mapping_for_another_account(self):
        self.scope.set_mapping("dave", ALL)
        self.assertEqual(len(self.scope.filter_items("dave", PORTS)), len(PORTS))

    def test_unknown_os_user_is_refused(self):
        with self.assertRaises(PortScopeError):
            self.scope.set_mapping("alice", "no_such_user_zz9")

    def test_empty_account_is_refused(self):
        with self.assertRaises(PortScopeError):
            self.scope.set_mapping("", "root")

    def test_mapping_persists_and_can_be_removed(self):
        self.scope.set_mapping("alice", "root")
        again = PortScope(self._tmp.name, primary="owner")
        self.assertEqual(again.os_user_for("alice"), "root")
        again.remove_mapping("alice")
        self.assertIsNone(PortScope(self._tmp.name, primary="owner").os_user_for("alice"))

    def test_removing_missing_mapping_is_a_lookup_error(self):
        with self.assertRaises(LookupError):
            self.scope.remove_mapping("nobody_mapped")

    def test_mappings_listing_includes_primary(self):
        self.scope.set_mapping("alice", "root")
        listing = self.scope.mappings()
        self.assertEqual(listing["owner"], ALL)
        self.assertEqual(listing["alice"], "root")

    def test_corrupt_store_fails_closed(self):
        (self.scope.path).write_text("not json")
        self.assertIsNone(self.scope.os_user_for("alice"))
        self.assertEqual(self.scope.filter_items("alice", PORTS), [])


if __name__ == "__main__":
    unittest.main()
