"""Exercise recovery against real QCOW2 disks, rather than mocked commands."""
import json
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path

from prime.vms import VMError, VMStore


@unittest.skipUnless(all(shutil.which(c) for c in ('qemu-img', 'qemu-io', 'qemu-system-x86_64')), 'QEMU tools unavailable')
class MaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        raw = self.root / 'source.raw'
        raw.write_bytes(b'A' * 1048576)
        self.store = VMStore(str(self.root))
        self.vm_id = self.store.create('recovery test', str(raw), 128, 1, acceleration='tcg')['id']
        self.disk = self.store._dir(self.vm_id) / 'disk.qcow2'

    def write_disk(self, pattern):
        subprocess.run(['qemu-io', '-f', 'qcow2', '-c', f'write -P {pattern} 0 512', str(self.disk)],
                       check=True, capture_output=True)

    def read_disk(self):
        raw = self.root / 'read.raw'
        subprocess.run(['qemu-img', 'convert', '-f', 'qcow2', '-O', 'raw', str(self.disk), str(raw)],
                       check=True, capture_output=True)
        return raw.read_bytes()[:512]

    def test_backup_and_snapshot_restore_real_disk_changes(self):
        snap = self.store.snapshot(self.vm_id, 'Before changes')
        self.write_disk(66)
        self.assertEqual(self.read_disk(), b'B' * 512)
        self.store.snapshot_action(self.vm_id, snap['id'], 'restore')
        self.assertEqual(self.read_disk(), b'A' * 512)
        backup = self.store.backup(self.vm_id, 'Independent copy')
        self.assertEqual(len(backup['sha256']), 64)
        self.write_disk(67)
        self.store.backup_action(self.vm_id, backup['id'], 'restore')
        self.assertEqual(self.read_disk(), b'A' * 512)
        self.assertEqual(self.store.recovery(self.vm_id)['snapshots'], [])
        self.assertEqual(json.loads(subprocess.check_output(['qemu-img', 'info', '--output=json', str(self.disk)])).get('snapshots', []), [])
        self.store.backup_action(self.vm_id, backup['id'], 'delete')
        self.assertFalse((self.disk.parent / 'backups' / (backup['id'] + '.qcow2')).exists())

    def test_corrupted_backup_does_not_replace_active_disk(self):
        backup = self.store.backup(self.vm_id)
        self.write_disk(68)
        (self.disk.parent / 'backups' / (backup['id'] + '.qcow2')).write_bytes(b'corrupted')
        with self.assertRaisesRegex(VMError, 'checksum'):
            self.store.backup_action(self.vm_id, backup['id'], 'restore')
        self.assertEqual(self.read_disk(), b'D' * 512)
        with self.assertRaises(VMError):
            self.store.backup_action(self.vm_id, '../elsewhere', 'restore')

    def test_running_vm_cannot_be_backed_up_or_snapshotted(self):
        self.store.start(self.vm_id)
        try:
            with self.assertRaisesRegex(VMError, 'Stop the VM'):
                self.store.backup(self.vm_id)
            with self.assertRaisesRegex(VMError, 'Stop the VM'):
                self.store.snapshot(self.vm_id)
            self.assertTrue(self.store.vnc_socket(self.vm_id).is_socket())
        finally:
            self.store.stop(self.vm_id)

    def test_snapshot_delete_and_invalid_schedule_inputs(self):
        snap = self.store.snapshot(self.vm_id)
        self.store.snapshot_action(self.vm_id, snap['id'], 'delete')
        self.assertEqual(self.store.recovery(self.vm_id)['snapshots'], [])
        for values in [('shell', time.time() + 60, 0), ('start', float('nan'), 0),
                       ('start', time.time() - 60, 0), ('stop', time.time() + 60, 1)]:
            with self.subTest(values=values), self.assertRaises(VMError):
                self.store.add_schedule(self.vm_id, 'Test', *values)

    def test_schedule_persists_coalesces_and_prunes_only_its_backups(self):
        manual = self.store.backup(self.vm_id, 'Manual backup')
        first_run = time.time() + 120
        item = self.store.add_schedule(self.vm_id, 'Hourly copy', 'backup', first_run, 3600, 1)
        # A newly constructed store represents a process restart.
        store = VMStore(str(self.root))
        store.run_due(first_run - 1)
        self.assertEqual(len(store.recovery(self.vm_id)['backups']), 1)
        store.run_due(first_run)
        store.run_due(first_run + 5 * 3600 + 10)
        recovery = store.recovery(self.vm_id)
        self.assertEqual(len(recovery['backups']), 2)
        self.assertIn(manual['id'], [b['id'] for b in recovery['backups']])
        scheduled = [b for b in recovery['backups'] if b.get('schedule_id') == item['id']]
        self.assertEqual(len(scheduled), 1)
        state = recovery['schedules'][0]
        self.assertEqual(state['state'], 'complete')
        self.assertEqual(state['next_run'], first_run + 6 * 3600)
        store.run_due(first_run + 5 * 3600 + 20)
        self.assertEqual([b['id'] for b in store.recovery(self.vm_id)['backups']], [b['id'] for b in recovery['backups']])
        store.schedule_action(self.vm_id, item['id'], 'disable')
        store.run_due(first_run + 10 * 3600)
        self.assertFalse(store.recovery(self.vm_id)['schedules'][0]['enabled'])

    def test_one_time_failure_is_visible_and_interrupted_claim_is_not_replayed(self):
        first_run = time.time() + 120
        schedule = self.store.add_schedule(self.vm_id, 'Offline copy', 'backup', first_run)
        self.store.start(self.vm_id)
        try:
            self.store.run_due(first_run)
            state = self.store.recovery(self.vm_id)['schedules'][0]
            self.assertEqual(state['state'], 'failed')
            self.assertIn('Stop the VM', state['last_error'])
            self.assertFalse(state['enabled'])
        finally:
            self.store.stop(self.vm_id)
        record = self.store._read(self.vm_id)
        record['schedules'][schedule['id']]['state'] = 'running'
        self.store._write(record)
        self.store.recover_schedules()
        self.store.run_due(first_run + 500)
        self.assertEqual(self.store.recovery(self.vm_id)['schedules'][0]['state'], 'interrupted')
        self.assertEqual(self.store.recovery(self.vm_id)['backups'], [])
