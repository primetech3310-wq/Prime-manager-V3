"""Unit tests for firewall, storage, MongoDB studio, nodes and the VM API helpers.

These run without FastAPI, QEMU, nftables or a MongoDB server: system commands are
replaced with recording fakes where a test needs them.
"""
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from prime import firewall, mongo_studio, nodes, storage, vm_api, node_agent


class FirewallRuleTests(unittest.TestCase):
    def test_valid_rule_is_normalised(self):
        rule = firewall.validate_rule({'action': 'ACCEPT', 'protocol': 'TCP', 'port': '8000-8100',
                                       'source': '203.0.113.7', 'comment': 'web app'})
        self.assertEqual(rule['action'], 'accept')
        self.assertEqual(rule['protocol'], 'tcp')
        self.assertEqual(rule['source'], '203.0.113.7/32')
        self.assertTrue(rule['id'])

    def test_rejects_bad_input(self):
        bad = [
            {'action': 'allow'},
            {'protocol': 'icmp', 'port': '1'},
            {'protocol': 'tcp', 'port': ''},
            {'protocol': 'tcp', 'port': '70000'},
            {'protocol': 'tcp', 'port': '9000-8000'},
            {'protocol': 'any', 'port': '22'},
            {'protocol': 'tcp', 'port': '22', 'source': 'not-an-ip'},
            {'protocol': 'tcp', 'port': '22', 'source': '2001:db8::/32'},
            {'protocol': 'tcp', 'port': '22', 'comment': 'x"; drop'},
        ]
        for data in bad:
            with self.subTest(data=data):
                with self.assertRaises(firewall.FirewallError):
                    firewall.validate_rule(data)

    def test_any_protocol_has_no_port(self):
        rule = firewall.validate_rule({'action': 'drop', 'protocol': 'any', 'source': '10.0.0.0/8'})
        self.assertEqual(rule['port'], '')
        self.assertIn('ip saddr 10.0.0.0/8 drop', firewall._nft_rule(rule))

    def test_renderers_use_correct_syntax(self):
        rule = firewall.validate_rule({'action': 'accept', 'protocol': 'tcp', 'port': '8000-8100',
                                       'source': '10.0.0.0/8', 'comment': 'ok'})
        self.assertEqual(firewall._nft_rule(rule),
                         'ip saddr 10.0.0.0/8 tcp dport 8000-8100 accept comment "ok"')
        self.assertEqual(firewall._ipt_args(rule),
                         ['-s', '10.0.0.0/8', '-p', 'tcp', '--dport', '8000:8100', '-j', 'ACCEPT',
                          '-m', 'comment', '--comment', 'ok'])


class FirewallStageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.applied = []
        self.fw = firewall.FirewallManager(self.tmp.name, panel_port=8080, ssh_ports=(22,))
        patches = [
            mock.patch.object(firewall.FirewallManager, 'can_apply', return_value=True),
            mock.patch.object(firewall.FirewallManager, '_apply_state', side_effect=lambda s: self.applied.append(s)),
            mock.patch.object(firewall.FirewallManager, '_schedule', return_value=None),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def test_stage_then_confirm_commits(self):
        result = self.fw.stage([{'action': 'accept', 'protocol': 'tcp', 'port': '443'}], 'drop')
        self.assertIn('token', result)
        self.assertEqual(self.applied[-1]['policy'], 'drop')
        self.assertIsNotNone(self.fw.pending())
        self.fw.confirm(result['token'])
        self.assertIsNone(self.fw.pending())
        self.assertEqual(self.fw.committed()['policy'], 'drop')

    def test_cancel_restores_previous_state(self):
        result = self.fw.stage([{'action': 'drop', 'protocol': 'tcp', 'port': '25'}], 'accept')
        self.fw.cancel(result['token'])
        self.assertIsNone(self.fw.pending())
        self.assertEqual(self.applied[-1], {'policy': 'accept', 'rules': []})
        self.assertEqual(self.fw.committed()['rules'], [])

    def test_expired_pending_rolls_back_on_recovery(self):
        result = self.fw.stage([{'action': 'drop', 'protocol': 'tcp', 'port': '25'}], 'drop')
        pending = json.loads(self.fw.pending_path.read_text())
        pending['deadline'] = time.time() - 1
        self.fw.pending_path.write_text(json.dumps(pending))
        self.fw.recover()
        self.assertIsNone(self.fw.pending())
        self.assertEqual(self.applied[-1], {'policy': 'accept', 'rules': []})
        with self.assertRaises(firewall.FirewallError):
            self.fw.confirm(result['token'])

    def test_second_stage_refused_while_pending(self):
        self.fw.stage([], 'accept')
        with self.assertRaises(firewall.FirewallError):
            self.fw.stage([], 'accept')

    def test_refuses_without_root(self):
        with mock.patch.object(firewall.FirewallManager, 'can_apply', return_value=False):
            with self.assertRaises(firewall.FirewallError):
                self.fw.stage([], 'accept')

    def test_baseline_always_keeps_panel_and_ssh(self):
        names = [r['port'] for r in self.fw._baseline()]
        self.assertIn('8080', names)
        self.assertIn('22', names)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.mgr = storage.StorageManager(self.tmp.name)

    def test_default_pool_exists_and_cannot_be_removed(self):
        ids = [p['id'] for p in self.mgr.pools()]
        self.assertIn('default', ids)
        with self.assertRaises(storage.StorageError):
            self.mgr.remove_pool('default')

    def test_pool_path_rules(self):
        for bad in ('relative/path', '/', '/etc', '/proc', 'x\x00y'):
            with self.subTest(path=bad):
                with self.assertRaises(storage.StorageError):
                    self.mgr.add_pool('Pool', bad)
        with self.assertRaises(storage.StorageError):
            self.mgr.add_pool('bad/name', os.path.join(self.tmp.name, 'p'))

    def test_add_and_list_pool(self):
        target = os.path.join(self.tmp.name, 'extra-pool')
        pool = self.mgr.add_pool('Extra', target)
        self.assertTrue(Path(target).is_dir())
        self.assertIn(pool['id'], [p['id'] for p in self.mgr.pools()])
        with self.assertRaises(storage.StorageError):
            self.mgr.add_pool('Again', target)

    def test_iso_names_are_strict(self):
        for bad in ('../x.iso', 'x.img', 'a b.iso', '.hidden.iso', 'x.iso/..'):
            with self.subTest(name=bad):
                with self.assertRaises(storage.StorageError):
                    self.mgr.begin_upload('default', bad, 10)

    def test_upload_requires_iso9660_signature(self):
        info = self.mgr.begin_upload('default', 'good.iso', None)
        data = bytearray(40000)
        data[32769:32774] = b'CD001'
        Path(info['temp']).write_bytes(bytes(data))
        result = self.mgr.finish_upload(info['temp'], info['final'], len(data))
        self.assertEqual(result['name'], 'good.iso')
        self.assertEqual([i['name'] for i in self.mgr.list_isos('default')], ['good.iso'])
        self.assertEqual(len(self.mgr.checksum('default', 'good.iso')['sha256']), 64)

        info = self.mgr.begin_upload('default', 'fake.iso', None)
        Path(info['temp']).write_bytes(b'not an iso' * 100)
        with self.assertRaises(storage.StorageError):
            self.mgr.finish_upload(info['temp'], info['final'], 1000)
        self.assertFalse(Path(info['temp']).exists())
        self.assertFalse(Path(info['final']).exists())

    def test_delete_iso_stays_inside_pool(self):
        with self.assertRaises(storage.StorageError):
            self.mgr.delete_iso('default', '../../etc.iso')


class MongoTests(unittest.TestCase):
    def test_scheme_is_enforced_before_driver_import(self):
        studio = mongo_studio.MongoStudio()
        for uri in ('http://example.com', 'postgres://x', ''):
            with self.subTest(uri=uri):
                with self.assertRaises(mongo_studio.MongoError):
                    studio.connect(uri)

    def test_names_are_validated(self):
        for name in ('', '$where', 'a/b', 'a.b', 'x' * 130):
            with self.subTest(name=name):
                with self.assertRaises(mongo_studio.MongoError):
                    mongo_studio._name_ok(name, 'Collection')

    def test_redact_hides_credentials(self):
        redacted = mongo_studio._redact('mongodb://admin:s3cret@db.internal:27017/app?authSource=admin')
        self.assertNotIn('s3cret', redacted)
        self.assertNotIn('admin:', redacted)
        self.assertEqual(redacted, 'mongodb://db.internal:27017/app')

    def test_unknown_session_is_rejected(self):
        with self.assertRaises(mongo_studio.MongoError):
            mongo_studio.MongoStudio().find('nope', 'db', 'coll')


class NodeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.reg = nodes.NodeRegistry(self.tmp.name)

    def test_enrollment_token_is_single_use(self):
        token = self.reg.create_enrollment('admin')['token']
        result = self.reg.enroll(token, {'name': 'web-1'})
        self.assertTrue(result['secret'].startswith('pns_'))
        with self.assertRaises(nodes.NodeError):
            self.reg.enroll(token, {'name': 'web-2'})

    def test_expired_enrollment_refused(self):
        token = self.reg.create_enrollment('admin')['token']
        data = json.loads(self.reg.path.read_text())
        data['enrollments'][0]['expires_at'] = time.time() - 1
        self.reg.path.write_text(json.dumps(data))
        with self.assertRaises(nodes.NodeError):
            self.reg.enroll(token, {'name': 'late'})

    def test_heartbeat_requires_node_secret_and_delivers_commands(self):
        token = self.reg.create_enrollment('admin')['token']
        node = self.reg.enroll(token, {'name': 'db-1'})
        with self.assertRaises(nodes.NodeError):
            self.reg.heartbeat(node['node_id'], 'wrong', {})
        self.reg.queue(node['node_id'], 'refresh')
        result = self.reg.heartbeat(node['node_id'], node['secret'], {'cpu_count': 4, 'load1': 0.5})
        self.assertEqual(result['commands'], ['refresh'])
        self.assertEqual(self.reg.heartbeat(node['node_id'], node['secret'], {})['commands'], [])
        listed = self.reg.list()[0]
        self.assertTrue(listed['online'])
        self.assertEqual(listed['metrics']['cpu_count'], 4)

    def test_only_allow_listed_commands(self):
        token = self.reg.create_enrollment('admin')['token']
        node = self.reg.enroll(token, {'name': 'x'})
        for action in ('rm -rf /', 'shell', ''):
            with self.subTest(action=action):
                with self.assertRaises(nodes.NodeError):
                    self.reg.queue(node['node_id'], action)

    def test_metrics_are_clamped(self):
        clean = nodes.sanitise_metrics({'cpu_count': 10 ** 9, 'load1': -5, 'hostname': 'h' * 500})
        self.assertLessEqual(clean['cpu_count'], 4096)
        self.assertEqual(clean['load1'], 0)
        self.assertEqual(len(clean['hostname']), 120)

    def test_install_command_contains_panel_and_token(self):
        command = nodes.install_command('https://panel.example/', 'pne_abc')
        self.assertIn('https://panel.example/api/nodes/agent.py', command)
        self.assertIn('--token pne_abc', command)


class VmApiHelperTests(unittest.TestCase):
    def test_bootstrap_quotes_values_and_posts_to_callback(self):
        script = vm_api.bootstrap_script('http://10.0.2.2:8080/API/vm-callback/tok123', 'pa$$word')
        self.assertIn("CB=http://10.0.2.2:8080/API/vm-callback/tok123", script)
        self.assertIn("TTYD_PASS='pa$$word'", script)
        self.assertIn('ttyd -p 7681', script)
        self.assertIn('cloudflared tunnel', script)
        self.assertIn('sshx', script)

    def test_cloud_config_writes_and_runs_script(self):
        cfg = vm_api.cloud_config('http://10.0.2.2:8080/API/vm-callback/t', 'pw')
        self.assertEqual(cfg['write_files'][0]['permissions'], '0700')
        self.assertEqual(cfg['runcmd'], [['/usr/local/sbin/prime-bootstrap.sh']])

    def test_key_reference_is_stable_and_not_the_key(self):
        ref = vm_api.key_reference('prime_secretkey')
        self.assertEqual(ref, vm_api.key_reference('prime_secretkey'))
        self.assertNotIn('secretkey', ref)
        self.assertEqual(len(ref), 24)

    def test_callback_validation_rejects_foreign_links(self):
        api = vm_api.VMApi(tempfile.mkdtemp(), 8080)
        api._api_records = lambda: [{'id': 'a' * 32, 'api': {'callback_hash': vm_api._hash('goodtoken12345678'),
                                                              'ttyd_password': 'pw'}}]
        with self.assertRaises(LookupError):
            api.record_callback('wrongtoken12345678', {})
        with mock.patch.object(api.store, '_read', return_value={'id': 'a' * 32, 'api': {'ttyd_password': 'pw'}}):
            with self.assertRaises(ValueError):
                api.record_callback('goodtoken12345678', {'ttyd': 'https://evil.example.com', 'sshx': ''})
            with self.assertRaises(ValueError):
                api.record_callback('goodtoken12345678', {'sshx': 'https://example.com/x'})

    def test_callback_accepts_real_link_shapes(self):
        self.assertTrue(vm_api._TRY_URL.fullmatch('https://frequency-hobbies-commentary.trycloudflare.com'))
        self.assertTrue(vm_api._SSHX_URL.fullmatch('https://sshx.io/s/abc123#key456'))
        self.assertFalse(vm_api._TRY_URL.fullmatch('http://x.trycloudflare.com'))


class NodeAgentTests(unittest.TestCase):
    def test_metrics_shape(self):
        m = node_agent.metrics()
        for key in ('hostname', 'arch', 'cpu_count', 'mem_total', 'disk_total', 'uptime', 'agent_version'):
            self.assertIn(key, m)

    def test_agent_refuses_plain_http_without_flag(self):
        with self.assertRaises(SystemExit):
            node_agent.main(['enroll', '--panel', 'http://panel.example', '--token', 'pne_x'])


class VmCredentialTests(unittest.TestCase):
    def test_seed_build_fails_clearly_without_any_tool(self):
        from prime import vms
        with mock.patch.object(vms.shutil, 'which', return_value=None):
            with self.assertRaises(vms.VMError) as ctx:
                vms.build_seed(Path('/tmp/none.iso'), Path('/tmp/u'), Path('/tmp/m'))
        self.assertIn('genisoimage', str(ctx.exception))

    def test_seed_tool_prefers_cloud_localds(self):
        from prime import vms
        with mock.patch.object(vms.shutil, 'which', side_effect=lambda n: '/usr/bin/' + n if n in ('genisoimage', 'xorriso') else None):
            self.assertEqual(vms.seed_tool(), 'genisoimage')

    def test_api_vms_use_root_and_requested_password(self):
        self.assertEqual(vm_api.GUEST_USER, 'root')
        self.assertEqual(vm_api.GUEST_PASSWORD, '$PrimeTerminal@user#')
        self.assertGreaterEqual(len(vm_api.GUEST_PASSWORD), 10)

    def test_cloud_config_keeps_both_write_files(self):
        from prime import vms
        extra = vm_api.cloud_config('http://10.0.2.2:8080/API/vm-callback/t', 'pw')
        config = {'write_files': [{'path': '/etc/x'}], 'runcmd': [['sh']]}
        for key, value in extra.items():
            if isinstance(value, list) and isinstance(config.get(key), list):
                config[key] = config[key] + value
            else:
                config[key] = value
        self.assertEqual(len(config['write_files']), 2)
        self.assertEqual(len(config['runcmd']), 2)


if __name__ == '__main__':
    unittest.main()
