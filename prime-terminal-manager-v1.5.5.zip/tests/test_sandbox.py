"""Unit tests for the sandbox backend (prime/sandbox.py).

Nothing here starts bubblewrap, pasta or proot. Commands are checked as argument
lists, and the manager's process launch is replaced with a stub.
"""
import tempfile
import time
import unittest
from pathlib import Path

from prime import sandbox
from prime.sandbox import SandboxError, SandboxManager, sandbox_argv, proot_argv


TOKEN = 'pk_test_owner_one'
OTHER = 'pk_test_owner_two'
GOOD_LINK = 'https://sshx.io/s/abc123XYZ#key-part'


def _argv(network='internet', pasta='/usr/bin/pasta'):
    return sandbox_argv(bwrap='/usr/bin/bwrap', lower=Path('/data/template'),
                        upper=Path('/data/inst/upper'), work=Path('/data/inst/work'),
                        out_dir=Path('/data/inst/out'), hostname='sbx-test',
                        network=network, pasta=pasta, overlay=True)


class StubManager(SandboxManager):
    """Creates records without launching anything."""

    def _launch(self, record):
        return None


class ArgvTests(unittest.TestCase):
    def test_bwrap_isolation_flags_present(self):
        argv = _argv(network='none', pasta=None)
        for flag in ('--die-with-parent', '--new-session', '--unshare-pid', '--unshare-ipc',
                     '--unshare-uts', '--clearenv', '--unshare-net'):
            self.assertIn(flag, argv)
        # --disable-userns is omitted when running as root (uid_map not writable)
        import os
        if os.geteuid() != 0:
            self.assertIn('--disable-userns', argv)
        i = argv.index('--cap-drop')
        self.assertEqual(argv[i + 1], 'ALL')

    def test_root_is_overlay_of_template_not_host(self):
        argv = _argv(network='none', pasta=None)
        i = argv.index('--overlay-src')
        self.assertEqual(argv[i + 1], '/data/template')
        j = argv.index('--overlay')
        self.assertEqual(argv[j + 1:j + 4], ['/data/inst/upper', '/data/inst/work', '/'])

    def test_no_host_paths_are_bound(self):
        argv = _argv(network='none', pasta=None)
        binds = [argv[i + 1] for i, a in enumerate(argv) if a in ('--bind', '--ro-bind')]
        self.assertEqual(binds, ['/data/inst/out'])  # only the output channel is shared
        self.assertNotIn('/home', ' '.join(argv))
        self.assertNotIn('/etc', ' '.join(argv))

    def test_internet_uses_pasta_and_shares_its_namespace(self):
        argv = _argv(network='internet')
        self.assertEqual(argv[0], '/usr/bin/pasta')
        self.assertIn('--config-net', argv)
        self.assertIn('--', argv)
        self.assertNotIn('--unshare-net', argv)  # pasta owns the namespace; unsharing would cut the net
        self.assertEqual(argv[argv.index('-t') + 1], 'none')  # no inbound TCP
        self.assertEqual(argv[argv.index('-u') + 1], 'none')  # no inbound UDP

    def test_internet_without_pasta_uses_slirp_unshare(self):
        # Without pasta, argv uses --unshare-net so slirp4netns can attach.
        argv = sandbox_argv(bwrap='/usr/bin/bwrap', lower=Path('/data/template'),
                            upper=Path('/data/inst/upper'), work=Path('/data/inst/work'),
                            out_dir=Path('/data/inst/out'), hostname='sbx-test',
                            network='internet', pasta=None, overlay=True, use_slirp=True)
        self.assertEqual(argv[0], '/usr/bin/bwrap')
        self.assertIn('--unshare-net', argv)

    def test_guest_script_reports_through_output_dir(self):
        argv = _argv(network='none', pasta=None)
        self.assertEqual(argv[-4:-1], ['--', '/bin/sh', '-c'])
        self.assertIn(sandbox.GUEST_SCRIPT, argv)
        self.assertIn('sshx.io/get', sandbox.GUEST_SCRIPT)
        self.assertIn('sshx.txt', sandbox.GUEST_SCRIPT)

    def test_fallback_copy_mode_binds_private_copy(self):
        argv = sandbox_argv(bwrap='/usr/bin/bwrap', lower=Path('/t'), upper=Path('/u'), work=Path('/w'),
                            out_dir=Path('/o'), hostname='h', network='none', pasta=None, overlay=False)
        self.assertNotIn('--overlay-src', argv)
        i = argv.index('--bind')
        self.assertEqual(argv[i + 1:i + 3], ['/u', '/'])

    def test_proot_argv_clears_environment_and_is_fake_root(self):
        argv = proot_argv(proot='/usr/bin/proot', root=Path('/copy'), out_dir=Path('/o'))
        self.assertEqual(argv[0], 'env')
        self.assertIn('-i', argv)
        self.assertIn('-0', argv)
        self.assertEqual(argv[argv.index('-r') + 1], '/copy')
        self.assertIn('/o:/run/prime-out', argv)

    def test_bad_network_value_rejected(self):
        with self.assertRaises(SandboxError):
            _argv(network='host')


class BackendChoiceTests(unittest.TestCase):
    def _mgr(self, backends):
        self._tmp = tempfile.TemporaryDirectory()
        return StubManager(self._tmp.name, backends=backends)

    def tearDown(self):
        if hasattr(self, '_tmp'):
            self._tmp.cleanup()

    FULL = {'bwrap': '/usr/bin/bwrap', 'bwrap_works': True, 'bwrap_overlay': True,
            'pasta': '/usr/bin/pasta', 'pasta_works': True, 'slirp4netns': '/usr/bin/slirp4netns', 'slirp_works': True, 'proot': '/usr/bin/proot'}

    def test_auto_prefers_bwrap(self):
        self.assertEqual(self._mgr(self.FULL).choose_backend('auto', 'internet'), 'bwrap')

    def test_auto_falls_back_to_proot_when_namespaces_blocked(self):
        b = dict(self.FULL, bwrap_works=False)
        self.assertEqual(self._mgr(b).choose_backend('auto', 'internet'), 'proot')

    def test_auto_refuses_network_none_without_bwrap(self):
        b = dict(self.FULL, bwrap_works=False)
        with self.assertRaises(SandboxError):
            self._mgr(b).choose_backend('auto', 'none')

    def test_bwrap_without_pasta_uses_slirp_for_internet(self):
        b = dict(self.FULL, pasta=None, pasta_works=False, slirp4netns='/usr/bin/slirp4netns',
                 slirp_works=True)
        m = self._mgr(b)
        self.assertEqual(m.choose_backend('bwrap', 'none'), 'bwrap')
        self.assertEqual(m.choose_backend('bwrap', 'internet'), 'bwrap')
        self.assertIn('slirp4netns', m.isolation('bwrap', 'internet', 'slirp4netns'))

    def test_no_backend_at_all(self):
        m = self._mgr({'bwrap': None, 'bwrap_works': False, 'pasta': None, 'proot': None})
        with self.assertRaises(SandboxError):
            m.choose_backend('auto', 'internet')

    def test_isolation_label_is_honest_about_proot(self):
        m = self._mgr(self.FULL)
        self.assertIn('shared with the host', m.isolation('proot', 'internet'))
        self.assertIn('pasta', m.isolation('bwrap', 'internet'))


class ValidationAndOwnershipTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.template = Path(self._tmp.name) / 'template'
        (self.template / 'bin').mkdir(parents=True)
        self.mgr = StubManager(self._tmp.name, backends=dict(
            bwrap='/usr/bin/bwrap', bwrap_works=True, bwrap_overlay=True,
            pasta='/usr/bin/pasta', pasta_works=True,
            slirp4netns='/usr/bin/slirp4netns', slirp_works=True, proot=None))
        self.mgr.template = self.template

    def tearDown(self):
        self._tmp.cleanup()

    def test_create_requires_template(self):
        self.mgr.template = Path(self._tmp.name) / 'missing'
        with self.assertRaises(SandboxError) as ctx:
            self.mgr.create(TOKEN, None, 1024, 3600)
        self.assertIn('build_sandbox_rootfs', str(ctx.exception))

    def test_limits_enforced(self):
        for kwargs in ({'memory_mb': 64, 'ttl': 3600}, {'memory_mb': 9000, 'ttl': 3600},
                       {'memory_mb': 1024, 'ttl': 60}, {'memory_mb': 1024, 'ttl': 999999}):
            with self.assertRaises(SandboxError):
                self.mgr.create(TOKEN, None, kwargs['memory_mb'], kwargs['ttl'])

    def test_bad_name_rejected(self):
        for name in ('../etc', 'a b', '-x', 'x' * 41):
            with self.assertRaises(SandboxError):
                self.mgr.create(TOKEN, name, 1024, 3600)

    def test_only_owner_can_read_or_delete(self):
        rec = self.mgr.create(TOKEN, 'box', 1024, 3600)
        self.assertEqual(self.mgr.status(TOKEN, rec['id'])['id'], rec['id'])
        with self.assertRaises(LookupError):
            self.mgr.status(OTHER, rec['id'])
        with self.assertRaises(LookupError):
            self.mgr.delete(OTHER, rec['id'])
        self.mgr.delete(TOKEN, rec['id'])
        with self.assertRaises(LookupError):
            self.mgr.status(TOKEN, rec['id'])

    def test_stored_owner_is_a_hash_not_the_key(self):
        rec = self.mgr.create(TOKEN, None, 1024, 3600)
        raw = self.mgr.registry.read_text()
        self.assertNotIn(TOKEN, raw)
        self.assertIn(sandbox.owner_ref(TOKEN), raw)
        self.mgr.delete(TOKEN, rec['id'])

    def test_per_key_limit(self):
        ids = [self.mgr.create(TOKEN, None, 1024, 3600)['id'] for _ in range(sandbox.MAX_PER_KEY)]
        with self.assertRaises(SandboxError):
            self.mgr.create(TOKEN, None, 1024, 3600)
        self.mgr.create(OTHER, None, 1024, 3600)  # another key still has room
        for sid in ids:
            self.mgr.delete(TOKEN, sid)

    def test_expired_sandboxes_are_removed(self):
        rec = self.mgr.create(TOKEN, None, 1024, 300)
        data = self.mgr._load()
        data['sandboxes'][0]['expires_at'] = time.time() - 1
        self.mgr._save(data)
        self.assertEqual(self.mgr.expire_due(), 1)
        with self.assertRaises(LookupError):
            self.mgr.status(TOKEN, rec['id'])

    def test_instance_directories_are_private(self):
        rec = self.mgr.create(TOKEN, None, 1024, 3600)
        mode = (self.mgr.root / 'instances' / rec['id'] / 'out').stat().st_mode & 0o777
        self.assertEqual(mode, 0o700)
        self.mgr.delete(TOKEN, rec['id'])


class OutputTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.mgr = StubManager(self._tmp.name, backends=dict(
            bwrap='/usr/bin/bwrap', bwrap_works=True, bwrap_overlay=True, pasta='/x', pasta_works=True,
            slirp4netns='/usr/bin/slirp4netns', slirp_works=True, proot=None))
        self.mgr.template = Path(self._tmp.name) / 'template'
        (self.mgr.template / 'bin').mkdir(parents=True)

    def tearDown(self):
        self._tmp.cleanup()

    def _write(self, rec, name, text):
        (self.mgr.root / 'instances' / rec['id'] / 'out' / name).write_text(text)

    def test_link_read_only_when_valid(self):
        rec = self.mgr.create(TOKEN, None, 1024, 3600)
        self._write(rec, 'sshx.txt', GOOD_LINK + '\n')
        result = self.mgr.status(TOKEN, rec['id'])
        self.assertEqual(result['status'], 'ready')
        self.assertEqual(result['sshx'], GOOD_LINK)
        self.mgr.delete(TOKEN, rec['id'])

    def test_invalid_link_is_never_returned(self):
        rec = self.mgr.create(TOKEN, None, 1024, 3600)
        for bad in ('https://evil.example/s/x', 'https://sshx.io/s/a;rm -rf /', '$(id)'):
            self._write(rec, 'sshx.txt', bad)
            self.assertIsNone(self.mgr.status(TOKEN, rec['id'])['sshx'])
        self.mgr.delete(TOKEN, rec['id'])

    def test_install_failure_reported(self):
        rec = self.mgr.create(TOKEN, None, 1024, 3600)
        self._write(rec, 'status', 'install-failed\n')
        self.assertEqual(self.mgr.status(TOKEN, rec['id'])['status'], 'failed')
        self.mgr.delete(TOKEN, rec['id'])

    def test_limits_hook_builds_without_error(self):
        self.assertTrue(callable(sandbox._limits(1024)))

    def test_version_parsing(self):
        self.assertEqual(sandbox._version('bubblewrap 0.8.0'), (0, 8, 0))
        self.assertEqual(sandbox._version('bubblewrap 0.4'), (0, 4, 0))
        self.assertEqual(sandbox._version('garbage'), (0, 0, 0))


if __name__ == '__main__':
    unittest.main()
