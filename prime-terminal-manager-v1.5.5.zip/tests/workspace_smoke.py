import argparse
import json
import tempfile
import os
import sys
from pathlib import Path
from prime.workspaces import WorkspaceStore, docker

parser = argparse.ArgumentParser(description='Provision real workspaces and check namespace/network boundaries')
parser.add_argument('--shared', action='store_true', help='Explicitly use shared host resources without CPU/memory/PID quotas')
args = parser.parse_args()
scratch = tempfile.TemporaryDirectory(prefix='prime-workspace-test-')
state = Path(scratch.name)
store = WorkspaceStore(str(state))
store.save_settings({'ttl': 3600, 'memory_mb': 512, 'max_workspaces': 5, 'resource_mode': 'shared' if args.shared else 'limited'})
created = []
try:
    for kind in ('primeterminal', 'ttyd', 'sshx'):
        result = store.create(kind, 'http://localhost:8081', 'http://localhost:8081')
        created.append(result)
        print(kind + ': provisioning link issued', flush=True)
    first = created[0]
    second = created[1]
    a = store.read(first['id'])
    b = store.read(second['id'])
    info = store._container(a)
    assert info['Config']['User'] == '1000:1000'
    assert info['HostConfig']['ReadonlyRootfs']
    assert info['HostConfig']['CapDrop'] == ['ALL']
    assert not info['HostConfig']['Privileged']
    assert not info['HostConfig']['PortBindings']
    assert all(m['Type'] == 'volume' for m in info['Mounts'])
    assert info['HostConfig']['Memory'] == (0 if args.shared else 512 * 1024 * 1024)
    assert info['HostConfig']['PidsLimit'] in ((None, 0) if args.shared else (256,))
    script = '''import os,pathlib,socket,sys
assert os.geteuid() == 1000
assert not pathlib.Path('/var/run/docker.sock').exists()
assert not pathlib.Path('/home/vercel-sandbox').exists()
v6=pathlib.Path('/proc/net/if_inet6')
assert not v6.exists() or not v6.read_text().strip()
status=pathlib.Path('/proc/self/status').read_text()
assert 'CapEff:\\t0000000000000000' in status
assert 'NoNewPrivs:\\t1' in status
pathlib.Path('/workspace/tenant-a-only').write_text('private')
s=socket.socket();s.settimeout(1)
try: s.connect((sys.argv[1], int(sys.argv[2])))
except OSError: pass
else: raise AssertionError('peer network is reachable')
print('filesystem, capabilities and peer-network checks passed')
'''
    # A peer listener on its own interface must be unreachable.
    ip = next(iter(store._container(b)['NetworkSettings']['Networks'].values()))['IPAddress']
    docker('exec', '-d', 'prime-ws-' + b['id'], 'python', '-m', 'http.server', '9009', '--bind', '0.0.0.0')
    result = docker('exec', 'prime-ws-' + a['id'], 'python', '-c', script, ip, '9009')
    print(result.stdout.decode().strip(), flush=True)
    result = docker('exec', 'prime-ws-' + b['id'], 'python', '-c', "from pathlib import Path; assert not Path('/workspace/tenant-a-only').exists(); print('peer filesystem hidden')")
    print(result.stdout.decode().strip(), flush=True)
    # Remove a required rule: verification must stop the container.
    from prime.workspaces import iptables, WorkspaceError
    iptables('-D', 'INPUT', '-i', b['bridge'], '-j', 'DROP')
    try: store.verify_policy(b)
    except WorkspaceError: pass
    else: raise AssertionError('missing firewall policy was accepted')
    assert not store._container(b)['State']['Running']
    print('missing-policy fail-closed check passed', flush=True)
    store.delete(b['id'])
    created = [c for c in created if c['id'] != b['id']]
    print('LIVE_WORKSPACE_CHECKS_OK', flush=True)
except Exception:
    # Keep only private diagnostic logs, without printing access URLs.
    for item in created:
        try:
            data = docker('logs', 'prime-ws-' + item['id'], check=False).stdout
            (state / (item['kind'] + '-error.log')).write_bytes(data)
        except Exception:
            pass
    raise

finally:
    for item in store.list():
        store.delete(item['id'])
    scratch.cleanup()
