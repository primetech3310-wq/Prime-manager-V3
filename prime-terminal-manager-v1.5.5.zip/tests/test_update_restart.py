"""Exercise a successful restart and a failed release in disposable installs."""
import http.cookiejar
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
import zipfile
from pathlib import Path


class RestartTests(unittest.TestCase):
    def test_real_update_and_failed_boot_rolls_back(self):
        source = Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            app, data = root / 'app', root / 'data'
            shutil.copytree(source / 'prime', app / 'prime', ignore=shutil.ignore_patterns('__pycache__'))
            shutil.copyfile(source / 'run.py', app / 'run.py')
            data.mkdir()
            (data / 'user-sentinel').write_text('preserved')
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', 0))
                port = probe.getsockname()[1]
            env = dict(os.environ, PRIME_HOST='127.0.0.1', PRIME_PORT=str(port), PRIME_DATA_DIR=str(data),
                       PRIME_CONFIG=str(data / 'config.json'))
            (data / 'config.json').write_text('{}')
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
                                                urllib.request.ProxyHandler({}))
            csrf = ''

            def call(path, body=None, raw=False):
                headers = {'X-PRIME-CSRF': csrf}
                if body is not None:
                    headers['Content-Type'] = 'application/octet-stream' if raw else 'application/json'
                    body = body if raw else json.dumps(body).encode()
                with opener.open(urllib.request.Request('http://127.0.0.1:%d%s' % (port, path), data=body,
                                                        headers=headers), timeout=45) as response:
                    return json.load(response)

            def until(predicate, seconds=45):
                deadline = time.monotonic() + seconds
                while time.monotonic() < deadline:
                    try:
                        result = predicate()
                        if result:
                            return result
                    except (OSError, ValueError, urllib.error.URLError):
                        pass
                    time.sleep(.2)
                self.fail('Timed out waiting for update integration check')

            with (root / 'server.log').open('wb') as log:
                process = subprocess.Popen([sys.executable, 'run.py'], cwd=app, env=env,
                                           stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    until(lambda: call('/api/health'))
                    csrf = call('/api/auth/setup', {'username': 'updatetest', 'password': 'UpdateTestPass123!'})['csrf']
                    self.assertEqual(call('/api/updates')['phase'], 'idle')
                    for fail in (False, True):
                        archive_path = root / 'update.zip'
                        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
                            for file in sorted(app.rglob('*')):
                                if not file.is_file() or '__pycache__' in file.parts:
                                    continue
                                content = file.read_bytes()
                                if fail and file.relative_to(app).as_posix() == 'prime/app.py':
                                    content = content.replace(b'    cfg = cfg or Config.load()',
                                        ('    if os.environ.get("PRIME_PORT") == "%s":\n        raise RuntimeError("intentional live boot failure")\n    cfg = cfg or Config.load()' % port).encode(), 1)
                                archive.writestr(file.relative_to(app).as_posix(), content)
                        result = call('/api/updates/upload', archive_path.read_bytes(), True)
                        self.assertEqual(result['phase'], 'ready')
                        call('/api/updates/apply', {})
                        wanted = 'rolled_back' if fail else 'complete'
                        until(lambda: call('/api/updates').get('phase') == wanted)
                        self.assertEqual((data / 'user-sentinel').read_text(), 'preserved')
                        self.assertTrue(call('/api/auth/status')['authenticated'])
                        self.assertTrue(call('/api/health')['ok'])
                finally:
                    process.terminate()
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)
