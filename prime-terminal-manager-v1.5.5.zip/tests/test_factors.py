import base64
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from prime.auth import AuthStore,AuthError
from prime.config import Config
from prime.factors import Factors,totp

class FactorTests(unittest.TestCase):
 def test_rfc6238_sha1_vector_six_digits(self):
  secret=base64.b32encode(b'12345678901234567890').decode()
  for timestamp,eight_digits in [(59,'94287082'),(1111111109,'07081804'),(1111111111,'14050471'),(1234567890,'89005924'),(2000000000,'69279037'),(20000000000,'65353130')]:
   self.assertEqual(totp(secret,timestamp//30),eight_digits[-6:])
 def test_enrollment_login_replay_recovery_disable(self):
  with tempfile.TemporaryDirectory() as temp:
   auth=AuthStore(Config(data_dir=temp,db_path=str(Path(temp)/'db')))
   self.addCleanup(auth._conn.close)
   auth.create_user('admin','AdminTestPass_123!')
   user=auth.get_user('admin');factors=Factors(auth)
   info=factors.begin(user);step=int(time.time())//30
   codes=factors.confirm(user['id'],totp(info['secret'],step))
   self.assertEqual(len(codes),10)
   self.assertTrue(factors.enabled(user['id']))
   with self.assertRaises(AuthError):auth.authenticate('admin','AdminTestPass_123!','','')
   with self.assertRaises(AuthError):auth.authenticate('admin','AdminTestPass_123!','','',totp(info['secret'],step))
   with patch('prime.factors.time.time',return_value=(step+1)*30+1):
    session=auth.authenticate('admin','AdminTestPass_123!','','',totp(info['secret'],step+1))
    self.assertTrue(session.is_admin)
    with self.assertRaises(AuthError):auth.authenticate('admin','AdminTestPass_123!','','',totp(info['secret'],step+1))
   auth.authenticate('admin','AdminTestPass_123!','','',codes[0])
   with self.assertRaises(AuthError):auth.authenticate('admin','AdminTestPass_123!','','',codes[0])
   saved=auth._conn.execute('SELECT digest FROM recovery_codes').fetchall()
   self.assertNotIn(codes[1],[r['digest'] for r in saved])
   factors.disable(user['id'],codes[1])
   self.assertFalse(factors.enabled(user['id']))
   self.assertTrue(auth.authenticate('admin','AdminTestPass_123!','','').is_admin)
