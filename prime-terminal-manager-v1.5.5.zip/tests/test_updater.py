import io
import shutil
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path

from prime.updater import UpdateError, UpdateStore, validate_zip


def release(extra=()):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name, value in [('prime/app.py', 'def run(): pass\n'), ('prime/__init__.py', ''),
                            ('prime/static/index.html', '<html>update</html>'), ('run.py', 'pass\n'), *extra]:
            archive.writestr(name, value)
    buffer.seek(0)
    return buffer


class UpdateTests(unittest.TestCase):
    def test_rejects_traversal_links_duplicates_and_invalid_python(self):
        bad = [('../escape', 'x'), ('/absolute', 'x'), ('prime/../../escape', 'x'),
               ('prime\\escape', 'x'), ('prime/app.py', 'duplicate'), ('prime/broken.py', 'def !')]
        for item in bad:
            with self.subTest(item=item[0]), tempfile.TemporaryDirectory() as directory:
                with self.assertRaises(UpdateError):
                    validate_zip(release([item]), directory)
        archive = release()
        with zipfile.ZipFile(archive, 'a') as source:
            entry = zipfile.ZipInfo('prime/link')
            entry.create_system = 3
            entry.external_attr = (stat.S_IFLNK | 0o777) << 16
            source.writestr(entry, '/etc/passwd')
        archive.seek(0)
        with tempfile.TemporaryDirectory() as directory, self.assertRaises(UpdateError):
            validate_zip(archive, directory)

    def test_archive_keeps_data_outside_app_and_supports_wrapper(self):
        original = release([('config.json', '{}'), ('panel.db', 'secret'), ('vms/disk', 'disk')])
        wrapped = io.BytesIO()
        with zipfile.ZipFile(original) as source, zipfile.ZipFile(wrapped, 'w') as target:
            for entry in source.infolist():
                target.writestr('release/' + entry.filename, source.read(entry))
        wrapped.seek(0)
        with tempfile.TemporaryDirectory() as directory:
            result = validate_zip(wrapped, directory)
            self.assertEqual(result['files'], 4)
            self.assertFalse((Path(directory) / 'config.json').exists())
            self.assertTrue((Path(directory) / 'prime/app.py').is_file())

    def test_transaction_rollback_restores_old_code_and_preserves_data(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app, data = root / 'app', root / 'data'
            (app / 'prime').mkdir(parents=True)
            (app / 'prime/app.py').write_text('old code')
            app.joinpath('run.py').write_text('old runner')
            data.mkdir()
            (data / 'panel.db').write_text('keep this database')
            store = UpdateStore(data, app)
            ident = 'a' * 32
            stage = store.root / ('stage-' + ident)
            stage.mkdir()
            validate_zip(release(), stage)
            store.install(ident)
            self.assertIn('def run', (app / 'prime/app.py').read_text())
            store.rollback(ident)
            self.assertEqual((app / 'prime/app.py').read_text(), 'old code')
            self.assertEqual((app / 'run.py').read_text(), 'old runner')
            self.assertEqual((data / 'panel.db').read_text(), 'keep this database')

    def test_rejects_data_inside_application_replacement(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(UpdateError):
                UpdateStore(Path(directory) / 'prime/data', directory)


if __name__ == '__main__':
    unittest.main()
