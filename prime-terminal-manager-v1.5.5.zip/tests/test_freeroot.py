"""Unit tests for named proot workspaces (prime/freeroot.py).

Real operations used: file system work, `cp`, `sh -n` on the guest script.
Mocked: downloads, the tar/apt step, and process launch. Live proot runs are
tested separately on a host with internet access (scripts/run_live_tests.sh).
"""
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from prime import freeroot
from prime.freeroot import FreeRootError, FreeRootManager, panel_owner, key_owner, proot_argv


NAMESPACED_HOST = {"bwrap": "/usr/bin/bwrap", "bwrap_works": True, "bwrap_overlay": False,
                   "pasta": None, "pasta_works": False, "slirp4netns": "/usr/bin/slirp4netns",
                   "slirp_works": True, "proot": None}


def _fake_template(path: Path) -> None:
    (path / "bin").mkdir(parents=True)
    (path / "bin" / "sh").write_text("")
    (path / "usr" / "bin").mkdir(parents=True)
    (path / "usr" / "bin" / "curl").write_text("")
    (path / "root").mkdir()
    (path / "run" / "prime-out").mkdir(parents=True)


class _Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.data = Path(self._tmp.name) / "data"
        # A host where bubblewrap and slirp4netns work, so workspaces are namespaced.
        self.mgr = FreeRootManager(str(self.data), backends=NAMESPACED_HOST)
        self.mgr.proot_bin.parent.mkdir(parents=True, exist_ok=True)
        self.mgr.proot_bin.write_bytes(b"#!/bin/sh\nexit 0\n" + b"x" * 1100)
        _fake_template(self.mgr.template)
        # Process launch is replaced: no real proot runs in unit tests.
        self._launch = mock.patch.object(FreeRootManager, "_launch", lambda self, record: None)
        self._launch.start()
        # Background work runs inline in unit tests, so results are ready when the call returns.
        self._worker = mock.patch.object(FreeRootManager, "_start_worker",
                                         lambda self, sid: self._prepare_and_launch(sid))
        self._worker.start()

    def tearDown(self):
        self._worker.stop()
        self._launch.stop()
        self._tmp.cleanup()


class OwnershipAndLimitTests(_Base):
    def test_panel_user_and_api_key_owners_do_not_collide(self):
        self.assertNotEqual(panel_owner("admin"), key_owner("admin"))
        self.assertEqual(panel_owner("admin"), panel_owner("admin"))
        self.assertNotIn("admin", panel_owner("admin"))

    def test_only_owner_sees_or_deletes(self):
        a, b = panel_owner("alice"), panel_owner("bob")
        rec = self.mgr.create_for(a, 3600, "box")
        self.assertEqual([i["id"] for i in self.mgr.list_for(a)], [rec["id"]])
        self.assertEqual(self.mgr.list_for(b), [])
        with self.assertRaises(LookupError):
            self.mgr.status_for(b, rec["id"])
        with self.assertRaises(LookupError):
            self.mgr.delete_for(b, rec["id"])
        self.mgr.delete_for(a, rec["id"])
        self.assertEqual(self.mgr.list_for(a), [])

    def test_api_key_flow_matches_owner_hash(self):
        rec = self.mgr.create("prime_key_one", 3600)
        self.assertEqual(self.mgr.status("prime_key_one", rec["id"])["id"], rec["id"])
        with self.assertRaises(LookupError):
            self.mgr.status("prime_key_two", rec["id"])
        self.mgr.delete("prime_key_one", rec["id"])

    def test_per_owner_limit(self):
        owner = panel_owner("carol")
        ids = [self.mgr.create_for(owner, 3600)["id"] for _ in range(freeroot.MAX_PER_OWNER)]
        with self.assertRaises(FreeRootError):
            self.mgr.create_for(owner, 3600)
        for sid in ids:
            self.mgr.delete_for(owner, sid)

    def test_ttl_and_name_validation(self):
        owner = panel_owner("dan")
        with self.assertRaises(FreeRootError):
            self.mgr.create_for(owner, 60)
        with self.assertRaises(FreeRootError):
            self.mgr.create_for(owner, 3600, "../escape")
        with self.assertRaises(FreeRootError):
            self.mgr.create_for(owner, 3600, "x" * 41)

    def test_registry_stores_hash_not_key(self):
        rec = self.mgr.create("prime_secret_value", 3600)
        raw = self.mgr.registry.read_text()
        self.assertNotIn("prime_secret_value", raw)
        self.mgr.delete("prime_secret_value", rec["id"])

    def test_expired_workspaces_are_removed(self):
        owner = panel_owner("erin")
        rec = self.mgr.create_for(owner, 300)
        data = self.mgr._load()
        data["sandboxes"][0]["expires_at"] = time.time() - 1
        self.mgr._save(data)
        self.assertEqual(self.mgr.expire_due(), 1)
        self.assertEqual(self.mgr.list_for(owner), [])
        self.assertFalse((self.mgr.instances / rec["id"]).exists())


class CommandTests(unittest.TestCase):
    def test_proot_argv_shape(self):
        argv = proot_argv("/usr/bin/proot", Path("/r"), ["-b", "/o:/run/prime-out"], ["/bin/sh", "/tmp/guest.sh"])
        self.assertEqual(argv[0], "/usr/bin/proot")
        self.assertIn("--rootfs=/r", argv)
        self.assertIn("-0", argv)
        self.assertIn("--kill-on-exit", argv)
        self.assertEqual(argv[-2:], ["/bin/sh", "/tmp/guest.sh"])
        self.assertIn("/o:/run/prime-out", argv)

    def test_guest_script_is_valid_sh(self):
        done = subprocess.run(["sh", "-n"], input=freeroot.GUEST_SCRIPT, text=True, capture_output=True)
        self.assertEqual(done.returncode, 0, done.stderr)

    def test_guest_script_installs_and_reports(self):
        self.assertIn("sshx.io/get", freeroot.GUEST_SCRIPT)
        self.assertIn("sshx.txt", freeroot.GUEST_SCRIPT)
        self.assertIn("install-failed", freeroot.GUEST_SCRIPT)

    def test_base_image_gets_curl(self):
        self.assertIn("curl", freeroot.BASE_TOOLS)
        self.assertIn("ca-certificates", freeroot.BASE_TOOLS)

    def test_isolation_label_names_what_is_private(self):
        mgr = FreeRootManager(tempfile.mkdtemp(), backends=NAMESPACED_HOST)
        text = mgr.isolation()
        self.assertIn("host processes and loopback services are not visible", text)


class TemplateTests(_Base):
    def test_template_needs_curl(self):
        self.assertTrue(self.mgr.template_ready())
        (self.mgr.template / "usr" / "bin" / "curl").unlink()
        self.assertFalse(self.mgr.template_ready())

    def test_ready_template_is_not_rebuilt(self):
        with mock.patch.object(freeroot, "_download") as dl, mock.patch.object(subprocess, "run") as run:
            self.mgr.ensure_template()
        dl.assert_not_called()
        run.assert_not_called()

    def test_host_proot_is_preferred(self):
        self.mgr.proot_bin.unlink()
        with mock.patch.object(freeroot.shutil, "which", return_value="/bin/true"), \
                mock.patch.object(freeroot, "_download") as dl:
            self.mgr._ensure_proot()
            info = self.mgr.status_info()
        dl.assert_not_called()
        self.assertTrue(self.mgr.proot_bin.is_file())
        self.assertEqual(info["proot"], "host package")

    def test_setup_failure_is_reported_not_silent(self):
        shutil.rmtree(self.mgr.template)

        def fake_run(argv, **kwargs):
            if argv[0] == "tar":
                return subprocess.CompletedProcess(argv, 0, "", "")
            if "apt-get" in " ".join(argv):
                return subprocess.CompletedProcess(argv, 100, "", "E: Unable to locate package curl")
            return subprocess.CompletedProcess(argv, 0, "", "")

        with mock.patch.object(freeroot, "_download"), \
                mock.patch.object(freeroot, "_arch", return_value="x86_64"), \
                mock.patch.object(subprocess, "run", side_effect=fake_run):
            with self.assertRaises(FreeRootError) as ctx:
                self.mgr.ensure_template()
        self.assertIn("curl", str(ctx.exception))
        self.assertIn("Unable to locate package curl", str(ctx.exception))
        self.assertFalse(self.mgr.template.exists() and (self.mgr.template / "usr" / "bin" / "curl").exists())


class OutputTests(_Base):
    def _write(self, rec, name, text):
        (self.mgr.instances / rec["id"] / "out").mkdir(parents=True, exist_ok=True)
        (self.mgr.instances / rec["id"] / "out" / name).write_text(text)

    def test_link_ready_only_when_valid(self):
        rec = self.mgr.create_for(panel_owner("fay"), 3600)
        self._write(rec, "sshx.txt", "https://sshx.io/s/abc123XYZ#key\n")
        self.assertEqual(self.mgr.status_for(panel_owner("fay"), rec["id"])["status"], "ready")
        self._write(rec, "sshx.txt", "https://evil.example/s/x")
        self.assertIsNone(self.mgr.status_for(panel_owner("fay"), rec["id"])["sshx"])
        self.mgr.delete_for(panel_owner("fay"), rec["id"])

    def test_ansi_codes_are_stripped_from_link(self):
        rec = self.mgr.create_for(panel_owner("gus"), 3600)
        self._write(rec, "sshx.txt", "\x1b[32mhttps://sshx.io/s/abc123XYZ#key\x1b[0m\n")
        self.assertEqual(self.mgr.status_for(panel_owner("gus"), rec["id"])["sshx"], "https://sshx.io/s/abc123XYZ#key")
        self.mgr.delete_for(panel_owner("gus"), rec["id"])

    def test_install_failure_reported(self):
        rec = self.mgr.create_for(panel_owner("hal"), 3600)
        self._write(rec, "status", "install-failed\n")
        self.assertEqual(self.mgr.status_for(panel_owner("hal"), rec["id"])["status"], "failed")
        self.mgr.delete_for(panel_owner("hal"), rec["id"])

    def test_status_info_keys(self):
        info = self.mgr.status_info()
        self.assertTrue(info["template_ready"])
        self.assertIn("isolation", info)
        self.assertIn(info["proot"], ("host package", "downloaded", "not installed"))


if __name__ == "__main__":
    unittest.main()
