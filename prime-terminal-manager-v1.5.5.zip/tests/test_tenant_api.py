"""Exercise tenant authority through real HTTP/WebSocket connections."""
import asyncio
import http.cookiejar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
import websockets
from websockets.exceptions import InvalidStatus, ConnectionClosed

@unittest.skipUnless(shutil.which('qemu-img') and shutil.which('qemu-system-x86_64'),'QEMU unavailable')
class TenantAPITests(unittest.TestCase):
 def test_host_boundaries_invoice_ownership_and_console_revocation(self):
  with tempfile.TemporaryDirectory() as temporary:
   root=Path(temporary);source=Path(__file__).resolve().parent.parent
   with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
   base=f'http://127.0.0.1:{port}'
   config=root/'config.json';config.write_text('{}')
   env=dict(os.environ,PRIME_HOST='127.0.0.1',PRIME_PORT=str(port),PRIME_DATA_DIR=str(root/'data'),PRIME_CONFIG=str(config))
   class Client:
    def __init__(self):
     self.csrf='';self.jar=http.cookiejar.CookieJar();self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(self.jar))
    def call(self,path,body=None,method=None,csrf=True):
     req=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Content-Type':'application/json','X-PRIME-CSRF':self.csrf if csrf else ''})
     with self.opener.open(req,timeout=20) as r:return json.load(r)
    def cookies(self):return '; '.join(f'{c.name}={c.value}' for c in self.jar)
   admin,alice,bob=Client(),Client(),Client()
   process=subprocess.Popen([sys.executable,'run.py'],cwd=source,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   vm_id=None
   def denied(client,path,body=None,method=None,code=403,csrf=True):
    with self.assertRaises(urllib.error.HTTPError) as caught:client.call(path,body,method,csrf)
    self.assertEqual(caught.exception.code,code,path);caught.exception.close()
   try:
    for _ in range(100):
     try:admin.call('/api/health');break
     except OSError:time.sleep(.05)
    admin.csrf=admin.call('/api/auth/setup',{'username':'admin','password':'AdminTestPass_123!'})['csrf']
    for username,client in [('alice',alice),('bob',bob)]:
     invite=admin.call('/api/management/invitations',{'username':username})
     client.call('/api/auth/accept-invitation',{'token':invite['token'],'password':'TenantPass_123!'})
     denied(client,'/api/auth/accept-invitation',{'token':invite['token'],'password':'TenantPass_123!'},code=400)
     client.csrf=client.call('/api/auth/login',{'username':username,'password':'TenantPass_123!'})['csrf']
     self.assertFalse(client.call('/api/auth/me')['user']['is_admin'])
    paths=['/api/vms','/api/management','/api/terminal/sessions','/api/files/list','/api/system/overview','/api/workspaces','/api/updates','/api/auth/audit']
    for path in paths:denied(alice,path)
    denied(alice,'/api/ui/settings',{},method='PUT')
    denied(alice,'/api/terminal/sessions',{})
    image=root/'image.raw';image.write_bytes(bytes(1048576))
    vm_id=admin.call('/api/vms',{'name':'Tenant VM','image':str(image),'memory':128,'cpus':1,'acceleration':'tcg'})['id']
    plan=admin.call('/api/management/plans',{'name':'Private plan','cents':1299})['id']
    admin.call('/api/management/invoices',{'username':'alice','plan_id':plan,'due':time.time()+86400})
    self.assertEqual(len(alice.call('/api/tenant')['invoices']),1)
    self.assertEqual(bob.call('/api/tenant')['invoices'],[])
    denied(alice,'/api/management/plans',{'name':'Unauthorized','cents':0})
    denied(admin,'/api/management/invitations',{'username':'no_csrf'},csrf=False)
    denied(alice,f'/api/tenant/vms/{vm_id}/start',{})
    admin.call('/api/management/grants',{'username':'alice','vm_id':vm_id,'permissions':['power']})
    self.assertEqual(alice.call('/api/tenant')['vms'][0]['id'],vm_id)
    self.assertEqual(bob.call('/api/tenant')['vms'],[])
    denied(bob,f'/api/tenant/vms/{vm_id}/start',{})
    alice.call(f'/api/tenant/vms/{vm_id}/start',{})
    async def vnc():
     target=f'ws://127.0.0.1:{port}/api/vms/{vm_id}/vnc'
     ticket=alice.call('/api/auth/ws-ticket',{})['ticket']
     with self.assertRaises(InvalidStatus):
      async with websockets.connect(target+'?ticket='+ticket,additional_headers={'Cookie':alice.cookies()},proxy=None):pass
     admin.call('/api/management/grants',{'username':'alice','vm_id':vm_id,'permissions':['power','console']})
     ticket=alice.call('/api/auth/ws-ticket',{})['ticket']
     async with websockets.connect(target+'?ticket='+ticket,additional_headers={'Cookie':alice.cookies(),'Origin':base},proxy=None) as ws:
      self.assertEqual(await asyncio.wait_for(ws.recv(),3),b'RFB 003.008\n')
      admin.call('/api/management/grants',{'username':'alice','vm_id':vm_id,'permissions':[]})
      with self.assertRaises(ConnectionClosed):await asyncio.wait_for(ws.recv(),18)
     # Tenant-issued tickets must never authorize a host PTY.
     ticket=alice.call('/api/auth/ws-ticket',{})['ticket']
     with self.assertRaises(InvalidStatus):
      async with websockets.connect(f'ws://127.0.0.1:{port}/api/ws/terminal/nonexistent?ticket='+ticket,additional_headers={'Cookie':alice.cookies()},proxy=None):pass
    asyncio.run(vnc())
    denied(alice,f'/api/tenant/vms/{vm_id}/stop',{})
    admin.call(f'/api/vms/{vm_id}/stop',{});admin.call(f'/api/vms/{vm_id}/delete',{});vm_id=None
    admin.call('/api/management/users/alice',method='DELETE')
    denied(alice,'/api/tenant',code=401)
    self.assertEqual(len(admin.call('/api/management')['invoices']),1)
   finally:
    process.terminate()
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait()
    if vm_id:
     from prime.vms import VMStore
     store=VMStore(str(root/'data'))
     if store._running(vm_id):store.stop(vm_id)
