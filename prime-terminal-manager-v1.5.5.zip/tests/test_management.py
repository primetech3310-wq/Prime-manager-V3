"""Delegation and monetary invariants, including transaction rollback."""
import tempfile
import time
import unittest
from pathlib import Path
from prime.auth import AuthStore
from prime.config import Config
from prime.management import Management
from prime.deps import get_session
from fastapi import HTTPException
from types import SimpleNamespace

class ManagementTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  root=Path(self.tmp.name)
  self.auth=AuthStore(Config(data_dir=str(root),db_path=str(root/'panel.db')))
  self.addCleanup(self.auth._conn.close)
  self.auth.create_user('admin','TestAdminPass_123!')
  self.store=Management(self.auth)
  token=self.store.invite('alice');self.store.accept(token,'TenantPass_123!')
  token=self.store.invite('bob');self.store.accept(token,'TenantPass_123!')
 def test_invitation_single_use_expiry_and_role(self):
  self.assertFalse(self.auth.get_user('alice')['is_admin'])
  self.assertTrue(self.auth.get_user('admin')['is_admin'])
  token=self.store.invite('charlie')
  with self.assertRaises(ValueError):self.store.accept(token,'short')
  self.store.accept(token,'TenantPass_123!')
  with self.assertRaises(ValueError):self.store.accept(token,'TenantPass_123!')
  token=self.store.invite('expired',-1)
  with self.assertRaises(ValueError):self.store.accept(token,'TenantPass_123!')
 def test_admin_default_dependency_and_self_service(self):
  tenant=self.auth.authenticate('alice','TenantPass_123!','','')
  request=SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(rt=SimpleNamespace(auth=self.auth))),cookies={'prime_session':tenant.token})
  with self.assertRaises(HTTPException) as error:get_session(request)
  self.assertEqual(error.exception.status_code,403)
  self.assertEqual(get_session(request,admin=False).username,'alice')
  self.assertFalse(self.auth.lookup(tenant.token).is_admin)
 def test_permissions_and_deletion_revoke_existing_session(self):
  alice=self.auth.authenticate('alice','TenantPass_123!','','')
  bob=self.auth.authenticate('bob','TenantPass_123!','','')
  vm='a'*32
  self.store.grant('alice',vm,['power'])
  self.assertTrue(self.store.allowed(alice,vm,'power'))
  self.assertTrue(self.store.allowed(alice,vm,'view'))
  self.assertFalse(self.store.allowed(alice,vm,'console'))
  self.assertFalse(self.store.allowed(bob,vm,'power'))
  self.store.grant('alice',vm,[])
  self.assertFalse(self.store.allowed(alice,vm,'power'))
  with self.assertRaises(ValueError):self.store.delete_user('admin')
  self.store.delete_user('alice')
  self.assertIsNone(self.auth.lookup(alice.token))
 def test_integer_money_coupon_exhaustion_and_invoice_snapshot(self):
  plan=self.store.plan('Starter',1001,'USD',1,1024,20)
  self.store.coupon('TEN','percentage',10,1,time.time()+100)
  ident=self.store.invoice('alice',plan,time.time()+3600,'TEN')
  inv=self.store.list('invoices','alice')[0]
  self.assertEqual(inv['cents'],901)
  self.assertEqual(self.store.list('invoices','bob'),[])
  with self.assertRaises(ValueError):self.store.invoice('bob',plan,time.time()+3600,'TEN')
  self.assertEqual(self.store.list('coupons')[0]['used'],1)
  self.store.plan('Changed',9999,'EUR',2,2048,40,plan)
  self.assertEqual(self.store.list('invoices','alice')[0]['description'],'Starter')
  self.assertEqual(self.store.list('invoices','alice')[0]['currency'],'USD')
  self.store.status(ident,'paid');self.assertIsNotNone(self.store.list('invoices','alice')[0]['paid'])
  self.store.status(ident,'pending');self.assertIsNone(self.store.list('invoices','alice')[0]['paid'])
  self.store.remove('plans',plan)
  with self.assertRaises(ValueError):self.store.invoice('bob',plan,time.time()+3600)
 def test_coupon_cap_and_rollback(self):
  plan=self.store.plan('Small',99,'USD',1,1024,20)
  self.store.coupon('FREE','fixed',9999,1,time.time()+100)
  self.store.invoice('alice',plan,time.time()+100,'FREE')
  self.assertEqual(self.store.list('invoices','alice')[0]['cents'],0)
  with self.assertRaises(ValueError):self.store.coupon('BAD','percentage',101,1,time.time()+100)
