"""Administrator routes: firewall, storage pools and ISOs, MongoDB studio, and nodes.

Everything here requires an administrator session. Writes also require the CSRF
token. The only public endpoints are the node enrollment, heartbeat (node secret)
and agent download, which carry their own credentials.
"""
import asyncio
import hashlib
import os
import re
from functools import partial
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt, get_session, require_csrf
from ..firewall import FirewallError, FirewallManager, validate_rule
from ..mongo_studio import MongoStudio
from ..nodes import NodeError, NodeRegistry, install_command
from ..storage import StorageError, StorageManager, MAX_ISO_BYTES

router = APIRouter(tags=['admin-advanced'])
_STUDIO = MongoStudio()
_STATIC_AGENT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'node_agent.py')
_SSH_PORT = re.compile(r'^\s*Port\s+(\d{1,5})\s*$', re.M | re.I)


# ----------------------------------------------------------------- helpers
def admin_read(request: Request):
    return get_session(request)


def admin_write(request: Request):
    session = get_session(request)
    require_csrf(request, session)
    return session


async def call(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    except (FirewallError, StorageError, NodeError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, str(exc) or 'Not found') from exc
    except OSError as exc:
        raise HTTPException(500, 'Operation failed: ' + (exc.strerror or exc.__class__.__name__)) from exc


def ssh_ports() -> tuple:
    ports = {22}
    try:
        with open('/etc/ssh/sshd_config', encoding='utf-8', errors='replace') as handle:
            for match in _SSH_PORT.finditer(handle.read()):
                ports.add(int(match.group(1)))
    except OSError:
        pass
    return tuple(sorted(p for p in ports if 1 <= p <= 65535))


def firewall(request: Request) -> FirewallManager:
    return FirewallManager(get_rt(request).cfg.data_dir, get_rt(request).cfg.port, ssh_ports())


def storage(request: Request) -> StorageManager:
    return StorageManager(get_rt(request).cfg.data_dir)


def registry(request: Request) -> NodeRegistry:
    return NodeRegistry(get_rt(request).cfg.data_dir)


# --------------------------------------------------------------- firewall
def _dump(model) -> dict:
    return model.model_dump() if hasattr(model, 'model_dump') else model.dict()


class FirewallRule(BaseModel):
    id: Optional[str] = Field(default=None, max_length=32)
    action: str = Field(default='accept', max_length=8)
    protocol: str = Field(default='tcp', max_length=4)
    port: Optional[str] = Field(default='', max_length=16)
    source: Optional[str] = Field(default='', max_length=64)
    comment: Optional[str] = Field(default='', max_length=64)


class FirewallStage(BaseModel):
    policy: str = Field(default='accept', max_length=8)
    rules: List[FirewallRule] = Field(default_factory=list, max_length=200)


class FirewallToken(BaseModel):
    token: str = Field(min_length=8, max_length=128)


@router.get('/api/firewall')
async def firewall_status(request: Request):
    admin_read(request)
    return await call(firewall(request).status)


@router.get('/api/firewall/live')
async def firewall_live(request: Request):
    admin_read(request)
    return await call(firewall(request).live_rules)


@router.post('/api/firewall/stage')
async def firewall_stage(request: Request, payload: FirewallStage):
    session = admin_write(request)
    rules = [validate_rule(_dump(r)) for r in payload.rules]
    result = await call(firewall(request).stage, rules, payload.policy)
    get_rt(request).auth.audit('firewall.stage', f'{len(rules)} rules, policy {payload.policy}', True,
                               session.username, client_ip(request))
    return result


@router.post('/api/firewall/confirm')
async def firewall_confirm(request: Request, payload: FirewallToken):
    session = admin_write(request)
    result = await call(firewall(request).confirm, payload.token)
    get_rt(request).auth.audit('firewall.confirm', '', True, session.username, client_ip(request))
    return result


@router.post('/api/firewall/cancel')
async def firewall_cancel(request: Request, payload: FirewallToken):
    session = admin_write(request)
    result = await call(firewall(request).cancel, payload.token)
    get_rt(request).auth.audit('firewall.cancel', '', True, session.username, client_ip(request))
    return result


# ---------------------------------------------------------------- storage
class PoolPayload(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    path: str = Field(min_length=1, max_length=1024)


@router.get('/api/storage/pools')
async def list_pools(request: Request):
    admin_read(request)
    return {'items': await call(storage(request).pools), 'max_iso_bytes': MAX_ISO_BYTES}


@router.post('/api/storage/pools')
async def add_pool(request: Request, payload: PoolPayload):
    session = admin_write(request)
    pool = await call(storage(request).add_pool, payload.name, payload.path)
    get_rt(request).auth.audit('storage.pool.add', pool['path'], True, session.username, client_ip(request))
    return pool


@router.delete('/api/storage/pools/{pool_id}')
async def remove_pool(request: Request, pool_id: str):
    session = admin_write(request)
    result = await call(storage(request).remove_pool, pool_id)
    get_rt(request).auth.audit('storage.pool.remove', pool_id, True, session.username, client_ip(request))
    return result


@router.get('/api/storage/pools/{pool_id}/isos')
async def list_isos(request: Request, pool_id: str):
    admin_read(request)
    return {'items': await call(storage(request).list_isos, pool_id)}


@router.get('/api/storage/pools/{pool_id}/isos/{name}/checksum')
async def iso_checksum(request: Request, pool_id: str, name: str):
    admin_read(request)
    return await call(storage(request).checksum, pool_id, name)


@router.post('/api/storage/pools/{pool_id}/isos')
async def upload_iso(request: Request, pool_id: str, name: str = Query(..., min_length=5, max_length=130)):
    session = admin_write(request)
    mgr = storage(request)
    length = request.headers.get('content-length', '')
    declared = int(length) if length.isdigit() else None
    info = await call(mgr.begin_upload, pool_id, name, declared)
    written = 0
    temp = info['temp']
    try:
        with open(temp, 'wb') as handle:
            async for chunk in request.stream():
                written += len(chunk)
                if written > MAX_ISO_BYTES:
                    raise StorageError('ISO exceeds the 8 GiB limit')
                await asyncio.to_thread(handle.write, chunk)
        result = await call(mgr.finish_upload, temp, info['final'], written)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    get_rt(request).auth.audit('storage.iso.upload', name, True, session.username, client_ip(request))
    return result


@router.delete('/api/storage/pools/{pool_id}/isos/{name}')
async def delete_iso(request: Request, pool_id: str, name: str):
    session = admin_write(request)
    result = await call(storage(request).delete_iso, pool_id, name)
    get_rt(request).auth.audit('storage.iso.delete', name, True, session.username, client_ip(request))
    return result


# ---------------------------------------------------------------- mongodb
class MongoConnect(BaseModel):
    uri: str = Field(min_length=10, max_length=2048)
    allow_writes: bool = False


class MongoSession(BaseModel):
    session: str = Field(min_length=8, max_length=128)


class MongoFind(BaseModel):
    session: str = Field(min_length=8, max_length=128)
    db: str = Field(max_length=120)
    coll: str = Field(max_length=120)
    filter: str = Field(default='', max_length=65536)
    limit: int = Field(default=20, ge=1, le=100)
    skip: int = Field(default=0, ge=0, le=10_000_000)


class MongoWrite(BaseModel):
    session: str = Field(min_length=8, max_length=128)
    db: str = Field(max_length=120)
    coll: str = Field(max_length=120)
    document: str = Field(default='', max_length=65536)


class MongoDelete(BaseModel):
    session: str = Field(min_length=8, max_length=128)
    db: str = Field(max_length=120)
    coll: str = Field(max_length=120)
    id: str = Field(max_length=512)


class MongoDrop(BaseModel):
    session: str = Field(min_length=8, max_length=128)
    db: str = Field(max_length=120)
    coll: str = Field(max_length=120)
    confirm: str = Field(max_length=120)


@router.post('/api/mongo/connect')
async def mongo_connect(request: Request, payload: MongoConnect):
    session = admin_write(request)
    result = await call(_STUDIO.connect, payload.uri, payload.allow_writes)
    get_rt(request).auth.audit('mongo.connect', result['host'], True, session.username, client_ip(request))
    return result


@router.post('/api/mongo/disconnect')
async def mongo_disconnect(request: Request, payload: MongoSession):
    admin_write(request)
    return await call(_STUDIO.disconnect, payload.session)


@router.get('/api/mongo/status')
async def mongo_status(request: Request, session: str = Query(..., min_length=8, max_length=128)):
    admin_read(request)
    return await call(_STUDIO.status, session)


@router.get('/api/mongo/databases')
async def mongo_databases(request: Request, session: str = Query(..., min_length=8, max_length=128)):
    admin_read(request)
    return await call(_STUDIO.databases, session)


@router.get('/api/mongo/collections')
async def mongo_collections(request: Request, session: str = Query(..., min_length=8, max_length=128),
                            db: str = Query(..., max_length=120)):
    admin_read(request)
    return await call(_STUDIO.collections, session, db)


@router.post('/api/mongo/find')
async def mongo_find(request: Request, payload: MongoFind):
    admin_read(request)
    return await call(_STUDIO.find, payload.session, payload.db, payload.coll, payload.filter,
                      payload.limit, payload.skip)


@router.post('/api/mongo/insert')
async def mongo_insert(request: Request, payload: MongoWrite):
    session = admin_write(request)
    result = await call(_STUDIO.insert, payload.session, payload.db, payload.coll, payload.document)
    get_rt(request).auth.audit('mongo.insert', payload.db + '.' + payload.coll, True, session.username,
                               client_ip(request))
    return result


@router.post('/api/mongo/delete')
async def mongo_delete(request: Request, payload: MongoDelete):
    session = admin_write(request)
    result = await call(_STUDIO.delete, payload.session, payload.db, payload.coll, payload.id)
    get_rt(request).auth.audit('mongo.delete', payload.db + '.' + payload.coll, True, session.username,
                               client_ip(request))
    return result


@router.post('/api/mongo/drop')
async def mongo_drop(request: Request, payload: MongoDrop):
    session = admin_write(request)
    result = await call(_STUDIO.drop_collection, payload.session, payload.db, payload.coll, payload.confirm)
    get_rt(request).auth.audit('mongo.drop', payload.db + '.' + payload.coll, True, session.username,
                               client_ip(request))
    return result


# ------------------------------------------------------------------ nodes
class EnrollPayload(BaseModel):
    token: str = Field(min_length=8, max_length=128)
    name: Optional[str] = Field(default='', max_length=64)
    hostname: Optional[str] = Field(default='', max_length=120)
    arch: Optional[str] = Field(default='', max_length=32)
    version: Optional[str] = Field(default='', max_length=32)


class NodeCommand(BaseModel):
    action: str = Field(max_length=16)


@router.get('/api/nodes')
async def list_nodes(request: Request):
    admin_read(request)
    return {'items': await call(registry(request).list)}


@router.post('/api/nodes/enrollment')
async def create_enrollment(request: Request):
    session = admin_write(request)
    result = await call(registry(request).create_enrollment, session.username)
    base = get_rt(request).cfg.public_url or str(request.base_url).rstrip('/')
    result['install_command'] = install_command(base, result['token'])
    get_rt(request).auth.audit('nodes.enrollment', 'token issued', True, session.username, client_ip(request))
    return result


@router.post('/api/nodes/enroll')
async def enroll_node(request: Request, payload: EnrollPayload):
    """Public endpoint: the one-time enrollment token is the only credential."""
    rt = get_rt(request)
    key = 'node-enroll|' + client_ip(request)
    if rt.limiter.retry_after(key):
        raise HTTPException(429, 'Too many enrollment attempts; try again later')
    try:
        result = await call(registry(request).enroll, payload.token, _dump(payload))
    except HTTPException:
        rt.limiter.register_failure(key)
        raise
    rt.auth.audit('nodes.enroll', result['node_id'], True, 'node-agent', client_ip(request))
    return result


@router.post('/api/nodes/{node_id}/heartbeat')
async def node_heartbeat(request: Request, node_id: str):
    """Node credentials: Authorization: Bearer <node secret>."""
    scheme, _, secret = request.headers.get('authorization', '').partition(' ')
    if scheme.lower() != 'bearer' or not secret:
        raise HTTPException(401, 'Node credentials are required')
    try:
        metrics = await request.json()
    except ValueError:
        raise HTTPException(400, 'Expected a JSON body')
    try:
        return await call(registry(request).heartbeat, node_id, secret.strip(), metrics)
    except HTTPException as exc:
        if 'authentication' in str(exc.detail):
            raise HTTPException(401, 'Node authentication failed') from exc
        raise


@router.post('/api/nodes/{node_id}/command')
async def node_command(request: Request, node_id: str, payload: NodeCommand):
    session = admin_write(request)
    result = await call(registry(request).queue, node_id, payload.action)
    get_rt(request).auth.audit('nodes.command', payload.action + ' ' + node_id, True, session.username,
                               client_ip(request))
    return result


@router.delete('/api/nodes/{node_id}')
async def remove_node(request: Request, node_id: str):
    session = admin_write(request)
    result = await call(registry(request).remove, node_id)
    get_rt(request).auth.audit('nodes.remove', node_id, True, session.username, client_ip(request))
    return result


@router.get('/api/nodes/agent.py')
async def agent_download(request: Request):
    """Public read-only download of the agent. It contains no secrets."""
    with open(_STATIC_AGENT, 'rb') as handle:
        body = handle.read()
    digest = hashlib.sha256(body).hexdigest()
    from fastapi.responses import Response
    return Response(content=body, media_type='text/x-python',
                    headers={'X-Agent-SHA256': digest, 'Cache-Control': 'no-store',
                             'Content-Disposition': 'inline; filename="node_agent.py"'})
