"""HTTP routes for isolated sandboxes (``/API/sandbox``), bearer provisioning keys.

Same contract as ``/API/vm``: JSON with ``Accept: application/json``, otherwise
plain text with the SSHx link. Only the key that created a sandbox can read or
delete it.
"""
import asyncio
from functools import partial
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt
from ..sandbox import (DEFAULT_MEMORY_MB, DEFAULT_TTL, MAX_MEMORY_MB, MAX_TTL, MIN_MEMORY_MB,
                       MIN_TTL, SandboxError, SandboxManager)
from .vm_api_routes import _key

router = APIRouter(tags=['sandbox-api'])


class CreateSandbox(BaseModel):
    name: Optional[str] = Field(default=None, max_length=40)
    memory: int = Field(default=DEFAULT_MEMORY_MB, ge=MIN_MEMORY_MB, le=MAX_MEMORY_MB)
    ttl: int = Field(default=DEFAULT_TTL, ge=MIN_TTL, le=MAX_TTL)
    backend: str = Field(default='auto', max_length=8)
    network: str = Field(default='internet', max_length=8)


def _api(request: Request) -> SandboxManager:
    return SandboxManager(get_rt(request).cfg.data_dir)


async def _run(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    except SandboxError as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, 'Sandbox not found') from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/API/sandbox')
async def create_sandbox(request: Request, payload: CreateSandbox, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    api = _api(request)
    result = await _run(api.create, token, payload.name, payload.memory, payload.ttl,
                        payload.backend, payload.network)
    get_rt(request).auth.audit('sandbox_api.create', result['id'], True, 'provisioning-api', client_ip(request))
    wants_json = 'application/json' in request.headers.get('accept', '')
    if not wants_json and not wait:
        wait = 600  # curl-style clients get the SSHx link printed
    if wait:
        result = await _run(api.status, token, result['id'], wait)
    ready = result['status'] == 'ready'
    if not wants_json:
        lines = []
        if ready:
            lines.append('SSHx:  ' + result['sshx'])
        else:
            lines.append('Sandbox ' + result['id'] + ' is ' + result['status'] + '; check '
                         + result['status_url'] + '?wait=600 with the same key.')
        lines.append('isolation: ' + result['isolation'])
        return PlainTextResponse('\n'.join(lines) + '\n', status_code=200 if ready else 202,
                                 headers={'Cache-Control': 'no-store'})
    return JSONResponse(result, status_code=200 if ready else 202, headers={'Cache-Control': 'no-store'})


@router.get('/API/sandbox/{sandbox_id}')
async def sandbox_status(request: Request, sandbox_id: str, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    result = await _run(_api(request).status, token, sandbox_id, wait)
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})


@router.delete('/API/sandbox/{sandbox_id}')
async def sandbox_delete(request: Request, sandbox_id: str):
    token = _key(request)
    result = await _run(_api(request).delete, token, sandbox_id)
    get_rt(request).auth.audit('sandbox_api.delete', sandbox_id, True, 'provisioning-api', client_ip(request))
    return result
