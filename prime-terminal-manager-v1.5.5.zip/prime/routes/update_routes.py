"""Administrator ZIP upload and supervised update endpoints."""
import asyncio
import os
import sys
import tempfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from starlette.background import BackgroundTask
from fastapi.responses import JSONResponse

from ..deps import get_rt, get_session, require_csrf, client_ip
from ..updater import MAX_UPLOAD, UpdateError, UpdateStore

router = APIRouter(prefix='/api/updates', tags=['updates'])


def store_for(request):
    if os.environ.get('PRIME_WORKSPACE') == '1':
        raise HTTPException(403, 'Panel updates are managed by the host administrator')
    return UpdateStore(get_rt(request).cfg.data_dir)


@router.get('')
async def status(request: Request):
    get_session(request)
    return store_for(request).status()


@router.post('/upload')
async def upload(request: Request):
    session = get_session(request)
    require_csrf(request, session)
    store = store_for(request)
    size = 0
    path = None
    try:
        with tempfile.NamedTemporaryFile(dir=str(store.root), suffix='.zip', delete=False) as output:
            path = Path(output.name)
            async for block in request.stream():
                size += len(block)
                if size > MAX_UPLOAD:
                    raise HTTPException(413, 'Update ZIP exceeds 64 MiB')
                output.write(block)
        result = await asyncio.get_running_loop().run_in_executor(None, store.stage, path)
        get_rt(request).auth.audit('update.validate', result['id'], True, session.username, client_ip(request))
        return result
    except UpdateError as exc:
        raise HTTPException(400, str(exc)) from exc
    finally:
        if path:
            path.unlink(missing_ok=True)


async def restart(runner, control, rt):
    await asyncio.sleep(.75)
    await rt.terms.close_all()
    await asyncio.get_running_loop().run_in_executor(None, rt.tunnels.shutdown)
    os.execv(sys.executable, [sys.executable, runner, control])


@router.post('/apply')
async def apply(request: Request):
    session = get_session(request)
    require_csrf(request, session)
    try:
        runner, control = store_for(request).prepare_restart(get_rt(request).cfg)
    except UpdateError as exc:
        raise HTTPException(400, str(exc)) from exc
    get_rt(request).auth.audit('update.apply', 'validated ZIP', True, session.username, client_ip(request))
    return JSONResponse({'phase': 'restarting'}, background=BackgroundTask(restart, runner, control, get_rt(request)))
