"""HTTP routes for named proot workspaces.

Two surfaces, one backend (prime/freeroot.py):

  /API/freeroot         bearer provisioning key (like /API/vm and /API/sandbox).
                        Only the key that created a workspace can read or delete it.
  /api/freeroot*        the panel tab "Named proot workspace". Administrator session
                        plus the CSRF token for writes. Owned by the signed-in user.
"""
import asyncio
from functools import partial
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt, get_session, require_csrf
from ..freeroot import (DEFAULT_TTL, MAX_TTL, MIN_TTL, FreeRootError, FreeRootManager, panel_owner)
from .vm_api_routes import _key

router = APIRouter(tags=["freeroot-api"])


class CreateFreeRoot(BaseModel):
    name: Optional[str] = Field(default=None, max_length=40)
    ttl: int = Field(default=DEFAULT_TTL, ge=MIN_TTL, le=MAX_TTL)


def _manager(request: Request) -> FreeRootManager:
    return FreeRootManager(get_rt(request).cfg.data_dir)


async def _run(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    except FreeRootError as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, "Workspace not found") from exc
    except OSError as exc:
        raise HTTPException(500, "Workspace operation failed: " + (exc.strerror or exc.__class__.__name__)) from exc


# ------------------------------------------------------- provisioning API
@router.post("/API/freeroot")
async def create_freeroot(request: Request, payload: CreateFreeRoot, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    api = _manager(request)
    result = await _run(api.create, token, payload.ttl, payload.name)
    get_rt(request).auth.audit("freeroot.create", result["id"], True, "provisioning-api", client_ip(request))
    wants_json = "application/json" in request.headers.get("accept", "")
    if not wants_json and not wait:
        # Reverse proxies (including quick tunnels) cut requests after about 100 s, so the
        # default wait stays short. The first setup can take minutes: poll status_url.
        wait = 50
    if wait:
        result = await _run(api.status, token, result["id"], wait)
    ready = result["status"] == "ready"
    if not wants_json:
        lines = []
        if ready:
            lines.append("SSHx:  " + result["sshx"])
        else:
            lines.append("Workspace " + result["id"] + " is " + result["status"] + "; check "
                         + result["status_url"] + "?wait=900 with the same key.")
        lines.append("isolation: " + result["isolation"])
        return PlainTextResponse("\n".join(lines) + "\n", status_code=200 if ready else 202,
                                 headers={"Cache-Control": "no-store"})
    return JSONResponse(result, status_code=200 if ready else 202, headers={"Cache-Control": "no-store"})


@router.get("/API/freeroot/{sandbox_id}")
async def freeroot_status(request: Request, sandbox_id: str, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    result = await _run(_manager(request).status, token, sandbox_id, wait)
    return JSONResponse(result, headers={"Cache-Control": "no-store"})


@router.delete("/API/freeroot/{sandbox_id}")
async def freeroot_delete(request: Request, sandbox_id: str):
    token = _key(request)
    result = await _run(_manager(request).delete, token, sandbox_id)
    get_rt(request).auth.audit("freeroot.delete", sandbox_id, True, "provisioning-api", client_ip(request))
    return result


# ------------------------------------------------------------ panel tab
def _panel(request: Request, write: bool = False) -> str:
    session = get_session(request)
    if write:
        require_csrf(request, session)
    return panel_owner(session.username)


@router.get("/api/freeroot/status")
async def panel_info(request: Request):
    _panel(request)
    return JSONResponse(await _run(lambda: _manager(request).status_info()))


@router.get("/api/freeroot")
async def panel_list(request: Request):
    owner = _panel(request)
    items = await _run(_manager(request).list_for, owner)
    return JSONResponse({"items": items})


@router.post("/api/freeroot")
async def panel_create(request: Request, payload: CreateFreeRoot):
    owner = _panel(request, write=True)
    result = await _run(_manager(request).create_for, owner, payload.ttl, payload.name)
    get_rt(request).auth.audit("freeroot.create", result["id"], True, "panel", client_ip(request))
    return JSONResponse(result, status_code=202, headers={"Cache-Control": "no-store"})


@router.get("/api/freeroot/{sandbox_id}")
async def panel_status(request: Request, sandbox_id: str):
    owner = _panel(request)
    return JSONResponse(await _run(_manager(request).status_for, owner, sandbox_id, 0),
                        headers={"Cache-Control": "no-store"})


@router.delete("/api/freeroot/{sandbox_id}")
async def panel_delete(request: Request, sandbox_id: str):
    owner = _panel(request, write=True)
    result = await _run(_manager(request).delete_for, owner, sandbox_id)
    get_rt(request).auth.audit("freeroot.delete", sandbox_id, True, "panel", client_ip(request))
    return result
