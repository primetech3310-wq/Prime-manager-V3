"""Authenticated local VM management routes."""
import asyncio
import os
from functools import partial
from urllib.parse import urlsplit

from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from ..deps import SESSION_COOKIE, client_ip, get_rt, get_session, require_csrf
from ..management import Management
from ..vms import VMError, VMStore, capabilities

router = APIRouter(prefix='/api/vms', tags=['vms'])


class CreateVM(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    image: str = Field(min_length=1, max_length=4096)
    memory: int = Field(default=1024, ge=128, le=65536)
    cpus: int = Field(default=1, ge=1, le=64)
    username: str = Field(default='', max_length=31)
    password: str = Field(default='', max_length=256)
    acceleration: str = Field(default='auto', pattern='^(auto|tcg|kvm)$')


class RecoveryPoint(BaseModel):
    label: str = Field(default='Disk recovery point', min_length=1, max_length=64)


class Schedule(BaseModel):
    label: str = Field(min_length=1, max_length=64)
    action: str = Field(pattern='^(start|stop|restart|backup)$')
    run_at: float
    interval: int = Field(default=0, ge=0, le=31622400)
    keep: int = Field(default=5, ge=1, le=100)


async def run_operation(func, *args):
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(func, *args))
    except VMError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('')
async def list_vms(request: Request):
    get_session(request)
    store = VMStore(get_rt(request).cfg.data_dir)
    return {'capabilities': capabilities(), 'items': await run_operation(store.list)}


@router.post('')
async def create_vm(request: Request, payload: CreateVM):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    vm = await run_operation(VMStore(rt.cfg.data_dir).create, payload.name, payload.image,
                             payload.memory, payload.cpus, payload.username, payload.password, payload.acceleration)
    rt.auth.audit('vm.create', vm['id'], True, session.username, client_ip(request))
    return vm


@router.post('/images/debian')
async def download_image(request: Request):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    result = await run_operation(VMStore(rt.cfg.data_dir).download_debian)
    rt.auth.audit('vm.image', 'debian-12', True, session.username, client_ip(request))
    return result


@router.get('/{vm_id}/console')
async def vm_console(request: Request, vm_id: str):
    get_session(request)
    return {'content': await run_operation(VMStore(get_rt(request).cfg.data_dir).console, vm_id)}


@router.get('/{vm_id}/recovery')
async def recovery_points(request: Request, vm_id: str):
    get_session(request)
    return await run_operation(VMStore(get_rt(request).cfg.data_dir).recovery, vm_id)


@router.post('/{vm_id}/backups')
@router.post('/{vm_id}/snapshots')
async def create_recovery_point(request: Request, vm_id: str, payload: RecoveryPoint):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    kind = 'backup' if request.url.path.endswith('/backups') else 'snapshot'
    result = await run_operation(getattr(VMStore(rt.cfg.data_dir), kind), vm_id, payload.label)
    rt.auth.audit('vm.' + kind, vm_id, True, session.username, client_ip(request))
    return result


@router.post('/{vm_id}/schedules')
async def create_schedule(request: Request, vm_id: str, payload: Schedule):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    result = await run_operation(VMStore(rt.cfg.data_dir).add_schedule, vm_id, payload.label,
                                 payload.action, payload.run_at, payload.interval, payload.keep)
    rt.auth.audit('vm.schedule', vm_id, True, session.username, client_ip(request))
    return result


@router.post('/{vm_id}/{kind}/{item_id}/{action}')
async def recovery_action(request: Request, vm_id: str, kind: str, item_id: str, action: str):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    method = {'backups': 'backup_action', 'snapshots': 'snapshot_action', 'schedules': 'schedule_action'}.get(kind)
    if not method:
        raise HTTPException(404, 'Unknown recovery type')
    result = await run_operation(getattr(VMStore(rt.cfg.data_dir), method), vm_id, item_id, action)
    rt.auth.audit('vm.' + kind + '.' + action, vm_id, True, session.username, client_ip(request))
    return result


@router.websocket('/{vm_id}/vnc')
async def vm_vnc(ws: WebSocket, vm_id: str):
    # HTTP middleware does not protect WebSocket routes inside guest containers.
    if os.environ.get('PRIME_WORKSPACE') == '1':
        await ws.close(code=4403)
        return
    rt = ws.app.state.rt
    try:
        origin = ws.headers.get('origin')
        if origin and urlsplit(origin).netloc != ws.headers.get('host', ''):
            await ws.close(code=4403)
            return
    except ValueError:
        await ws.close(code=4403)
        return
    token = ws.cookies.get(SESSION_COOKIE, '')
    session = rt.auth.lookup(token) if token else None
    if not session or not Management(rt.auth).allowed(session, vm_id, 'console') or not rt.auth.consume_ws_ticket(ws.query_params.get('ticket', ''), token):
        await ws.close(code=4401)
        return
    store = VMStore(rt.cfg.data_dir)
    try:
        store._read(vm_id)
        if not store._running(vm_id):
            raise VMError('VM is stopped')
        reader, writer = await asyncio.wait_for(asyncio.open_unix_connection(str(store.vnc_socket(vm_id))), 5)
    except (VMError, OSError, TimeoutError):
        await ws.close(code=4404)
        return
    tasks = []
    try:
        protocols = ws.headers.get('sec-websocket-protocol', '').split(',')
        await ws.accept(subprotocol='binary' if 'binary' in [p.strip() for p in protocols] else None)
        rt.auth.audit('vm.vnc', vm_id, True, session.username, ws.client.host if ws.client else '')

        async def from_guest():
            while data := await reader.read(65536):
                await ws.send_bytes(data)

        async def from_browser():
            while True:
                data = await ws.receive_bytes()
                if len(data) > 1024 * 1024:
                    return
                writer.write(data)
                await writer.drain()

        async def check_session():
            while True:
                await asyncio.sleep(15)
                current = rt.auth.lookup(token)
                if not current or not Management(rt.auth).allowed(current, vm_id, 'console'):
                    return

        tasks = [asyncio.create_task(pump()) for pump in (from_guest, from_browser, check_session)]
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    except (WebSocketDisconnect, OSError, RuntimeError):
        pass
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        writer.close()
        try:
            await writer.wait_closed()
            await ws.close()
        except (WebSocketDisconnect, OSError, RuntimeError):
            pass


@router.post('/{vm_id}/{action}')
async def control_vm(request: Request, vm_id: str, action: str):
    session = get_session(request)
    require_csrf(request, session)
    rt = get_rt(request)
    store = VMStore(rt.cfg.data_dir)
    if action not in ('start', 'stop', 'restart', 'delete'):
        raise HTTPException(404, 'Unknown action')
    result = await run_operation(getattr(store, action), vm_id)
    rt.auth.audit('vm.' + action, vm_id, True, session.username, client_ip(request))
    return result
