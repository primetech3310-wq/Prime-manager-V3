"""Admin controls and bearer-key provisioning for private Docker workspaces."""
import asyncio
import os
from functools import partial
from urllib.parse import urlsplit

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt, get_session, require_csrf
from ..workspaces import WorkspaceError, WorkspaceStore, _ID

router = APIRouter(tags=['workspaces'])


class KeyPayload(BaseModel):
    name: str = Field(min_length=1, max_length=64)


class OpenPayload(BaseModel):
    token: str = Field(min_length=1, max_length=256)


def store_for(request):
    if os.environ.get('PRIME_WORKSPACE') == '1':
        raise HTTPException(403, 'Only the host administrator can provision workspaces')
    return WorkspaceStore(get_rt(request).cfg.data_dir)


async def operation(function, *args):
    try:
        return await asyncio.get_running_loop().run_in_executor(None, partial(function, *args))
    except WorkspaceError as exc:
        raise HTTPException(400, str(exc)) from exc


def admin_write(request):
    session = get_session(request)
    require_csrf(request, session)
    return session


@router.get('/api/workspaces')
async def overview(request: Request):
    get_session(request)
    store = store_for(request)
    return {'capabilities': await operation(store.capabilities), 'settings': store.public_settings(), 'items': store.list()}


@router.put('/api/workspaces/settings')
async def settings(request: Request):
    admin_write(request)
    values = await request.json()
    if not isinstance(values, dict):
        raise HTTPException(400, 'Expected a settings object')
    return await operation(store_for(request).save_settings, values)


@router.post('/api/workspaces/build')
async def build(request: Request):
    admin_write(request)
    return await operation(store_for(request).build)


@router.post('/api/workspaces/keys')
async def create_key(request: Request, payload: KeyPayload):
    admin_write(request)
    return await operation(store_for(request).create_key, payload.name)


@router.delete('/api/workspaces/keys/{key_id}')
async def revoke_key(request: Request, key_id: str):
    admin_write(request)
    await operation(store_for(request).revoke_key, key_id)
    return {'ok': True}


@router.delete('/api/workspaces/{ident}')
async def delete(request: Request, ident: str):
    session = admin_write(request)
    result = await operation(store_for(request).delete, ident)
    get_rt(request).auth.audit('workspace.delete', ident, True, session.username, client_ip(request))
    return result


@router.post('/api/workspaces/{ident}/open')
async def open_link(request: Request, ident: str, payload: OpenPayload):
    store = store_for(request)
    rt = get_rt(request)
    key = 'workspace-open|' + client_ip(request)
    if rt.limiter.retry_after(key):
        raise HTTPException(429, 'Too many invalid workspace requests; try again later')
    try:
        result = await operation(store.open, ident, payload.token)
    except HTTPException:
        rt.limiter.register_failure(key)
        raise HTTPException(404, 'Workspace link is invalid, expired or stopped')
    rt.limiter.reset(key)
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})


async def provision(request, kind, cookie_auth=False):
    store = store_for(request)
    if cookie_auth:
        session = admin_write(request)
        actor = session.username
    else:
        scheme, _, token = request.headers.get('authorization', '').partition(' ')
        if scheme.lower() != 'bearer' or not store.authenticate_key(token):
            raise HTTPException(401, 'A valid provisioning API key is required', headers={'WWW-Authenticate': 'Bearer'})
        actor = 'provisioning-api'
    rt = get_rt(request)
    public_url = rt.cfg.public_url or str(request.base_url).rstrip('/')
    parsed = urlsplit(public_url)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username or parsed.password:
        raise HTTPException(400, 'Configure a valid panel public_url')
    parent_origin = parsed.scheme + '://' + parsed.netloc
    result = await operation(store.create, kind, public_url, parent_origin)
    rt.auth.audit('workspace.create', result['id'] + ' (' + result['kind'] + ')', True, actor, client_ip(request))
    headers = {'Cache-Control': 'no-store', 'X-Workspace-Expires': str(int(result['expires_at']))}
    if cookie_auth or 'application/json' in request.headers.get('accept', ''):
        return JSONResponse(result, headers=headers)
    return PlainTextResponse(result['url'] + '\n', headers=headers)


@router.post('/api/workspaces/create/{kind}')
async def admin_create(request: Request, kind: str):
    return await provision(request, kind, cookie_auth=True)


@router.api_route('/API/{kind}', methods=['GET', 'POST'])
async def api_create(request: Request, kind: str):
    return await provision(request, kind)


# Included after the app's ordinary single-segment routes.
@router.get('/{ident}')
async def landing(request: Request, ident: str):
    if not _ID.fullmatch(ident):
        raise HTTPException(404, 'Not found')
    return FileResponse(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'workspace.html'),
                        headers={'Cache-Control': 'no-store'})
