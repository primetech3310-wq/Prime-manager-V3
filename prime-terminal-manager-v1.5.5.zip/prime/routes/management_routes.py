"""Administrator management and explicitly delegated tenant VM access."""
from __future__ import annotations
import asyncio
import sqlite3
import time
from functools import partial
from typing import List
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from ..deps import client_ip, get_rt, get_session, require_csrf
from ..management import Management
from ..vms import VMStore, VMError

router = APIRouter(prefix='/api', tags=['management'])

def manager(request):
    return Management(get_rt(request).auth)

async def operation(func, *args):
    try:
        return await asyncio.get_running_loop().run_in_executor(None, partial(func, *args))
    except (ValueError, sqlite3.IntegrityError) as exc:
        raise HTTPException(400,str(exc)) from exc

def admin_write(request):
    session = get_session(request)
    require_csrf(request,session)
    return session

def audit(request, action, detail):
    session = get_session(request)
    get_rt(request).auth.audit(action,detail,True,session.username,client_ip(request))

class Invitation(BaseModel):
    username: str = Field(min_length=1,max_length=64)
    hours: int = Field(default=24,ge=1,le=168)
class Accept(BaseModel):
    token: str = Field(min_length=30,max_length=128)
    password: str = Field(min_length=10,max_length=512)
class Grant(BaseModel):
    username: str = Field(min_length=1,max_length=64)
    vm_id: str = Field(pattern='^[a-f0-9]{32}$')
    permissions: List[str] = Field(max_length=3)
class Plan(BaseModel):
    name: str = Field(min_length=1,max_length=100)
    cents: int = Field(ge=0,le=100000000)
    currency: str = Field(default='USD',pattern='^[A-Z]{3}$')
    cpus: int = Field(default=1,ge=1,le=64)
    memory: int = Field(default=1024,ge=128,le=65536)
    disk: int = Field(default=20,ge=1,le=100000)
class Coupon(BaseModel):
    code: str = Field(min_length=1,max_length=32)
    kind: str = Field(pattern='^(fixed|percentage)$')
    value: int = Field(ge=1,le=100000000)
    max_uses: int = Field(default=100,ge=1,le=1000000)
    expires: float = Field(gt=0,allow_inf_nan=False)
class Invoice(BaseModel):
    username: str = Field(min_length=1,max_length=64)
    plan_id: str = Field(pattern='^[a-f0-9]{32}$')
    due: float = Field(gt=0,allow_inf_nan=False)
    coupon: str = Field(default='',max_length=32)
class InvoiceStatus(BaseModel):
    status: str = Field(pattern='^(pending|paid|cancelled)$')

@router.get('/management')
async def overview(request:Request):
    get_session(request)
    m = manager(request)
    return {'users':m.users(),'grants':m.grants(), 'plans':m.list('plans'),
            'invoices':m.list('invoices'),'coupons':m.list('coupons')}

@router.post('/management/invitations')
async def invite(request:Request, payload:Invitation):
    admin_write(request)
    token = await operation(manager(request).invite,payload.username,payload.hours)
    audit(request,'user.invite',payload.username)
    return {'token':token,'username':payload.username}

@router.post('/auth/accept-invitation')
async def accept(request:Request,payload:Accept):
    # A high-entropy single-use secret authorizes account creation.
    username = await operation(manager(request).accept,payload.token,payload.password)
    return {'ok':True,'username':username}

@router.delete('/management/users/{username}')
async def delete_user(request:Request,username:str):
    admin_write(request)
    await operation(manager(request).delete_user,username)
    audit(request,'user.delete',username)
    return {'ok':True}

@router.post('/management/grants')
async def grant(request:Request,payload:Grant):
    admin_write(request)
    await operation(VMStore(get_rt(request).cfg.data_dir)._read,payload.vm_id)
    await operation(manager(request).grant,payload.username,payload.vm_id,payload.permissions)
    audit(request,'vm.grant',payload.username+':'+payload.vm_id)
    return {'ok':True}

@router.post('/management/plans')
async def plan(request:Request,payload:Plan):
    admin_write(request)
    ident = await operation(partial(manager(request).plan,**payload.model_dump()))
    audit(request,'billing.plan',ident)
    return {'id':ident}

@router.post('/management/coupons')
async def coupon(request:Request,payload:Coupon):
    admin_write(request)
    ident = await operation(partial(manager(request).coupon,**payload.model_dump()))
    audit(request,'billing.coupon',ident)
    return {'code':ident}

@router.post('/management/invoices')
async def invoice(request:Request,payload:Invoice):
    admin_write(request)
    ident = await operation(partial(manager(request).invoice,**payload.model_dump()))
    audit(request,'billing.invoice',str(ident))
    return {'id':ident}

@router.post('/management/invoices/{ident}/status')
async def invoice_status(request:Request,ident:int,payload:InvoiceStatus):
    admin_write(request)
    await operation(manager(request).status,ident,payload.status)
    audit(request,'billing.status',str(ident)+':'+payload.status)
    return {'ok':True}

@router.delete('/management/{kind}/{ident}')
async def remove(request:Request,kind:str,ident:str):
    admin_write(request)
    await operation(manager(request).remove,kind,ident)
    return {'ok':True}

@router.get('/tenant')
async def tenant(request:Request):
    session = get_session(request,admin=False)
    m = manager(request)
    store = VMStore(get_rt(request).cfg.data_dir)
    granted = {r['vm_id']:r['permissions'] for r in m.grants(session.username)}
    items = await asyncio.get_running_loop().run_in_executor(None, store.list)
    # Never return host file paths, boot logs or provisioning credentials.
    return {'username':session.username,'invoices':m.list('invoices',session.username),
            'vms':[{**{k:v[k] for k in ('id','name','cpus','memory','running')}, 'permissions':granted[v['id']]}
                   for v in items if v['id'] in granted]}

@router.post('/tenant/vms/{vm_id}/{action}')
async def tenant_power(request:Request,vm_id:str,action:str):
    session = get_session(request,admin=False)
    require_csrf(request,session)
    if action not in ('start','stop','restart') or not manager(request).allowed(session,vm_id,'power'):
        raise HTTPException(403,'VM power permission required')
    result = await operation(getattr(VMStore(get_rt(request).cfg.data_dir),action),vm_id)
    get_rt(request).auth.audit('tenant.vm.'+action,vm_id,True,session.username,client_ip(request))
    return result
