"""Public links: publish a local port through a Cloudflare quick tunnel."""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt, get_session, require_csrf
from ..tunnels import TunnelError

router = APIRouter(prefix="/api/public", tags=["public"])


class PublishPayload(BaseModel):
    port: int = Field(ge=1, le=65535)
    label: str = Field(default="", max_length=60)


def _wrap(exc: TunnelError) -> HTTPException:
    return HTTPException(status_code=400, detail=str(exc))


@router.get("/status")
async def status(request: Request):
    rt = get_rt(request)
    get_session(request)
    return rt.tunnels.status()


@router.post("/links")
async def publish(payload: PublishPayload, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    loop = asyncio.get_running_loop()
    try:
        rec = await loop.run_in_executor(None, rt.tunnels.create, payload.port, payload.label)
    except TunnelError as exc:
        rt.auth.audit("public.create", f"port {payload.port}: {exc}", False, session.username,
                      client_ip(request))
        raise _wrap(exc)
    rt.auth.audit("public.create", f"port {payload.port} -> {rec.get('url', '')}", True,
                  session.username, client_ip(request))
    return {"ok": True, "item": rec, **rt.tunnels.status()}


@router.post("/links/{tid}/restart")
async def restart(tid: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    loop = asyncio.get_running_loop()
    try:
        rec = await loop.run_in_executor(None, rt.tunnels.restart, tid)
    except TunnelError as exc:
        raise _wrap(exc)
    rt.auth.audit("public.restart", f"{tid} -> {rec.get('url', '')}", True, session.username,
                  client_ip(request))
    return {"ok": True, "item": rec}


@router.post("/links/{tid}/stop")
async def stop(tid: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, rt.tunnels.stop, tid)
    except TunnelError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    rt.auth.audit("public.stop", tid, True, session.username, client_ip(request))
    return {"ok": True}


@router.delete("/links/{tid}")
async def remove(tid: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, rt.tunnels.remove, tid)
    except TunnelError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    rt.auth.audit("public.remove", tid, True, session.username, client_ip(request))
    return {"ok": True}


@router.post("/install")
async def install(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, rt.tunnels.ensure_binary)
    except TunnelError as exc:
        rt.auth.audit("public.install", str(exc), False, session.username, client_ip(request))
        raise _wrap(exc)
    rt.auth.audit("public.install", "cloudflared ready", True, session.username, client_ip(request))
    return rt.tunnels.status()
