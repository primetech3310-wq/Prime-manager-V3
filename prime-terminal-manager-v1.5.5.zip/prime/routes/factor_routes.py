"""Account security self-service, available to both administrators and tenants."""
from fastapi import APIRouter,HTTPException,Request
from pydantic import BaseModel,Field
from ..deps import get_session,get_rt,require_csrf,client_ip
from ..factors import Factors
from .. import security
router=APIRouter(prefix='/api/auth/totp',tags=['account security'])
class Verification(BaseModel):
 password:str=Field(min_length=1,max_length=512)
 code:str=Field(default='',max_length=32)

@router.get('')
async def status(request:Request):
 session=get_session(request,admin=False)
 return {'enabled':Factors(get_rt(request).auth).enabled(session.user_id)}

@router.post('/{action}')
async def change(request:Request,action:str,payload:Verification):
 session=get_session(request,admin=False);require_csrf(request,session)
 auth=get_rt(request).auth
 user=auth.get_user(session.username)
 if not security.verify_password(payload.password,user['password_hash']):raise HTTPException(403,'Current password is incorrect')
 factors=Factors(auth)
 try:
  if action=='begin':return factors.begin(user)
  if action=='confirm':result={'codes':factors.confirm(session.user_id,payload.code)}
  elif action=='disable':factors.disable(session.user_id,payload.code);result={'ok':True}
  else:raise HTTPException(404,'Unknown security action')
 except ValueError as exc:raise HTTPException(400,str(exc)) from exc
 auth.destroy_all_for_user(session.username,keep_token=session.token)
 auth.audit('auth.totp.'+action,'',True,session.username,client_ip(request))
 return result
