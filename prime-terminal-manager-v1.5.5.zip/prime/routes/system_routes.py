"""System information endpoints — all values come from /proc, /sys or statvfs."""
from __future__ import annotations
import json
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Request

from .. import ops, sysinfo
from ..auth import AuthError
from ..deps import client_ip, get_rt, get_session, require_csrf
from ..port_scope import PortScope, PortScopeError

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/snapshot")
async def snapshot(request: Request):
    get_session(request)
    return sysinfo.snapshot()


@router.get("/overview")
async def overview(request: Request):
    rt = get_rt(request)
    get_session(request)
    host_specs = None
    if os.environ.get('PRIME_WORKSPACE') == '1':
        try:
            host_specs = json.loads((Path(rt.cfg.data_dir) / 'host-specs.json').read_text())
        except (OSError, ValueError):
            pass
    return {
        "os": sysinfo.os_info(),
        "cpu": sysinfo.cpu_info(),
        "memory": sysinfo.memory_info(),
        "disk": sysinfo.disk_info(),
        "network": sysinfo.network_info(),
        "capabilities": sysinfo.capabilities(),
        "panel": ops.panel_status(rt.cfg, {"version": rt.version,
                                           "sessions": len(rt.terms.sessions),
                                           "started": rt.started}),
        "thermal": sysinfo.thermal_info(),
        'host_specs': host_specs,
    }


@router.get("/cpu")
async def cpu(request: Request):
    get_session(request)
    return sysinfo.cpu_info()


@router.get("/memory")
async def memory(request: Request):
    get_session(request)
    return sysinfo.memory_info()


@router.get("/disk")
async def disk(request: Request):
    get_session(request)
    return sysinfo.disk_info()


@router.get("/network")
async def network(request: Request):
    get_session(request)
    return sysinfo.network_info()


@router.get("/processes")
async def processes(request: Request, limit: int = Query(200, ge=1, le=2000),
                    sort: str = Query("cpu", pattern="^(cpu|mem|pid|name)$")):
    session = get_session(request)
    data = sysinfo.list_processes(limit=limit, sort=sort)
    items = _scope(request).filter_items(session.username, data.get("items", []))
    data["items"] = items
    data["total"] = len(items)
    return data


@router.get("/process/{pid}")
async def process_detail(pid: int, request: Request):
    session = get_session(request)
    detail = sysinfo.process_detail(pid)
    if detail is None or not _scope(request).visible(session.username, detail.get("user")):
        raise HTTPException(404, "no such process")
    return detail


@router.post("/process/{pid}/signal")
async def process_signal(pid: int, request: Request, signal: str = Query("TERM")):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    if pid <= 1:
        raise HTTPException(400, "refusing to signal PID 1")
    detail = sysinfo.process_detail(pid)
    if detail is None or not _scope(request).visible(session.username, detail.get("user")):
        raise HTTPException(404, "no such process")
    ok, message = sysinfo.kill_process(pid, signal)
    rt.auth.audit("process.signal", f"{signal} {pid}: {message}", ok, session.username,
                  client_ip(request))
    if not ok:
        raise HTTPException(403 if "permission" in message else 400, message)
    return {"ok": True, "message": message}


def _scope(request: Request) -> PortScope:
    return PortScope(get_rt(request).cfg.data_dir, get_rt(request).auth.first_username())


@router.get("/ports")
async def ports(request: Request):
    session = get_session(request)
    data = sysinfo.listening_ports()
    data["items"] = _scope(request).filter_items(session.username, data.get("items", []))
    data["scope"] = _scope(request).os_user_for(session.username)
    return data


@router.get("/port-scope")
async def port_scope_list(request: Request):
    """Administrator: which OS user each panel account may see (admin session only)."""
    get_session(request)
    scope = _scope(request)
    return {"primary": get_rt(request).auth.first_username(), "mappings": scope.mappings()}


@router.put("/port-scope/{username}")
async def port_scope_set(username: str, request: Request, payload: dict):
    session = get_session(request)
    require_csrf(request, session)
    os_user = str((payload or {}).get("os_user", "")).strip()
    if not os_user:
        raise HTTPException(400, "os_user is required (an OS user name, or * for all)")
    try:
        _scope(request).set_mapping(username, os_user)
    except PortScopeError as exc:
        raise HTTPException(400, str(exc)) from exc
    get_rt(request).auth.audit("port_scope.set", f"{username} -> {os_user}", True, session.username, client_ip(request))
    return {"ok": True, "username": username, "os_user": os_user}


@router.delete("/port-scope/{username}")
async def port_scope_remove(username: str, request: Request):
    session = get_session(request)
    require_csrf(request, session)
    try:
        _scope(request).remove_mapping(username)
    except LookupError as exc:
        raise HTTPException(404, "no explicit mapping for this account") from exc
    get_rt(request).auth.audit("port_scope.remove", username, True, session.username, client_ip(request))
    return {"ok": True}


@router.get("/capabilities")
async def capabilities(request: Request):
    get_session(request)
    return sysinfo.capabilities()


@router.get("/panel")
async def panel(request: Request):
    rt = get_rt(request)
    get_session(request)
    return ops.panel_status(rt.cfg, {"version": rt.version,
                                     "sessions": len(rt.terms.sessions),
                                     "started": rt.started})


@router.get("/users")
async def users(request: Request):
    get_session(request)
    import os
    import pwd
    return {"users": ops.users_list(),
            "whoami": pwd.getpwuid(os.geteuid()).pw_name,
            "root": os.geteuid() == 0}
