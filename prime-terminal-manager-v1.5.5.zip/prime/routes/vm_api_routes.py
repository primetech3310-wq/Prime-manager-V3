"""HTTP routes for the VM provisioning API (bearer provisioning keys).

Mounted before the workspace /API/{kind} catch-all so /API/vm is handled here.
"""
import asyncio
import os
from functools import partial
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from ..deps import client_ip, get_rt
from ..vm_api import VMApi
from ..vms import VMError
from ..workspaces import WorkspaceStore

router = APIRouter(tags=['vm-api'])


class CreateVM(BaseModel):
    name: Optional[str] = Field(default=None, max_length=64)
    memory: int = Field(default=2048, ge=128, le=65536)
    cpus: int = Field(default=2, ge=1, le=64)
    ttl: int = Field(default=3600, ge=300, le=86400)
    image: str = Field(default='debian', max_length=32)


def _key(request: Request) -> str:
    if os.environ.get('PRIME_WORKSPACE') == '1':
        raise HTTPException(403, 'Managed by the host administrator')
    scheme, _, token = request.headers.get('authorization', '').partition(' ')
    token = token.strip()
    rt = get_rt(request)
    store = WorkspaceStore(rt.cfg.data_dir)
    if scheme.lower() != 'bearer' or not token or not store.authenticate_key(token):
        raise HTTPException(401, 'A valid provisioning API key is required', headers={'WWW-Authenticate': 'Bearer'})
    return token


def _api(request: Request) -> VMApi:
    rt = get_rt(request)
    return VMApi(rt.cfg.data_dir, rt.cfg.port)


async def _run(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    except VMError as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, 'VM not found') from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/API/vm')
async def create_vm(request: Request, payload: CreateVM, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    api = _api(request)
    result = await _run(api.create, token, payload.name, payload.memory, payload.cpus,
                        payload.ttl, payload.image)
    rt = get_rt(request)
    rt.auth.audit('vm_api.create', result['id'], True, 'provisioning-api', client_ip(request))
    wants_json = 'application/json' in request.headers.get('accept', '')
    if not wants_json and not wait:
        # curl-style clients get the links printed, so wait for the guest to report them.
        wait = 900
    if wait:
        result = await _run(api.status, token, result['id'], wait)
    if not wants_json:
        lines = []
        if result['status'] == 'ready':
            lines.append('SSHx:  ' + (result.get('sshx') or '(not reported)'))
            lines.append('ttyd:  ' + (result.get('ttyd') or '(not reported)'))
            creds = result.get('ttyd_credentials') or {}
            lines.append('ttyd login: ' + str(creds.get('user')) + ' / ' + str(creds.get('password')))
        else:
            lines.append('VM ' + result['id'] + ' is still booting; check ' + '/API/vm/' + result['id'] + '?wait=900 with the same key.')
        login = result.get('guest_login') or {}
        lines.append('guest login: ' + str(login.get('user')) + ' / ' + str(login.get('password')))
        return PlainTextResponse('\n'.join(lines) + '\n', status_code=200 if result['status'] == 'ready' else 202,
                                 headers={'Cache-Control': 'no-store'})
    status_code = 200 if result['status'] == 'ready' else 202
    return JSONResponse({**result, 'status_url': '/API/vm/' + result['id']},
                        status_code=status_code, headers={'Cache-Control': 'no-store'})


@router.get('/API/vm/{vm_id}')
async def vm_status(request: Request, vm_id: str, wait: int = Query(0, ge=0, le=900)):
    token = _key(request)
    result = await _run(_api(request).status, token, vm_id, wait)
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})


@router.delete('/API/vm/{vm_id}')
async def vm_delete(request: Request, vm_id: str):
    token = _key(request)
    result = await _run(_api(request).delete, token, vm_id)
    get_rt(request).auth.audit('vm_api.delete', vm_id, True, 'provisioning-api', client_ip(request))
    return result


@router.post('/API/vm-callback/{callback_token}')
async def vm_callback(request: Request, callback_token: str):
    """Called by the guest with its links. The token in the path is the credential."""
    try:
        payload = await request.json()
    except ValueError:
        raise HTTPException(400, 'Expected a JSON body')
    if not isinstance(payload, dict):
        raise HTTPException(400, 'Expected a JSON object')
    rt = get_rt(request)
    key = 'vm-callback|' + client_ip(request)
    if rt.limiter.retry_after(key):
        raise HTTPException(429, 'Too many callbacks; try again later')
    try:
        result = await _run(_api(request).record_callback, callback_token, payload)
    except HTTPException:
        rt.limiter.register_failure(key)
        raise HTTPException(404, 'Unknown callback')
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})
