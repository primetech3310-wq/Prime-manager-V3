"""Appearance and performance settings (Settings → Appearance)."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from ..deps import client_ip, get_rt, get_session, require_csrf
from ..uisettings import DEFAULTS, UISettingsError, UISettingsStore

router = APIRouter(prefix="/api/ui", tags=["ui"])


def _store(request: Request) -> UISettingsStore:
    return UISettingsStore(get_rt(request).cfg)


@router.get("/settings")
async def get_ui_settings(request: Request):
    # Public read on purpose: the login screen needs the look too. Holds no secrets.
    return {"settings": _store(request).get(), "defaults": DEFAULTS}


@router.put("/settings")
async def put_ui_settings(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        payload = await request.json()
    except ValueError:
        raise HTTPException(400, "request body must be JSON")
    try:
        updated = _store(request).update(payload)
    except UISettingsError as exc:
        raise HTTPException(400, str(exc))
    rt.auth.audit("ui-settings", "changed: " + ", ".join(sorted(payload)), True,
                  session.username, client_ip(request))
    return {"ok": True, "settings": updated}


@router.post("/settings/reset")
async def reset_ui_settings(request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    restored = _store(request).reset()
    rt.auth.audit("ui-settings", "reset to defaults", True, session.username, client_ip(request))
    return {"ok": True, "settings": restored}
