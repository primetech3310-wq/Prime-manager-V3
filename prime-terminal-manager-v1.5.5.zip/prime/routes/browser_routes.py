"""Embedded browser: a sandboxed page proxy for the panel's Browser view."""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, Response

from .. import browser_proxy
from ..deps import get_rt, get_session
from ..uisettings import UISettingsStore

router = APIRouter(prefix="/api/browser", tags=["browser"])


def _error(status: int, title: str, message: str, url: str) -> HTMLResponse:
    return HTMLResponse(browser_proxy.error_page(title, message, url), status_code=status,
                        headers=browser_proxy.security_headers())


@router.get("/fetch")
async def browser_fetch(request: Request, url: str = Query(default="", max_length=2048)):
    get_session(request)
    rt = get_rt(request)
    if not UISettingsStore(rt.cfg).get()["browser_enabled"]:
        return _error(403, "Browser is turned off",
                      "An administrator disabled the embedded browser in Settings → Appearance.", url)
    try:
        target = browser_proxy.normalize_url(url)
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, browser_proxy.fetch, target)
    except browser_proxy.BrowserError as exc:
        return _error(exc.status, "Page could not be loaded", exc.message, url)

    headers = browser_proxy.security_headers()
    if result.is_html:
        text = browser_proxy.decode_html(result.body, result.charset)
        page = browser_proxy.rewrite_html(text, result.final_url)
        return Response(content=page.encode("utf-8"), status_code=200,
                        media_type="text/html; charset=utf-8", headers=headers)
    return Response(content=result.body, status_code=200,
                    media_type=result.content_type or "application/octet-stream", headers=headers)
