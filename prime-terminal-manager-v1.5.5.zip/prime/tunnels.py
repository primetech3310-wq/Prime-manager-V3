"""Public quick tunnels.

A "public link" exposes one local TCP port to the internet through Cloudflare's
quick tunnel (``cloudflared tunnel --url http://127.0.0.1:<port>``). Cloudflare
hands back a random ``https://<words>.trycloudflare.com`` address; no account,
domain or open inbound port is needed.

Design notes:
  * cloudflared is downloaded on first use from the official GitHub release
    and stored in <data_dir>/bin, unless a copy is already on PATH.
  * Each tunnel is a child process in its own session, so it can be stopped as
    a group. The panel stops every tunnel it started when it shuts down, so no
    port stays exposed after the panel is gone.
  * A watchdog restarts a tunnel whose cloudflared process died (up to a small
    limit). Quick-tunnel URLs change on every restart; the record reflects that.
  * Only 127.0.0.1 is ever used as the target, and the panel's own port is
    refused, so the control plane is never published by accident.
"""
from __future__ import annotations

import json
import logging
import os
import platform
import re
import shutil
import signal
import stat
import subprocess
import threading
import time
import uuid
from collections import deque
from typing import Any, Deque, Dict, List, Optional

from . import sysinfo

log = logging.getLogger("prime.tunnels")

URL_RE = re.compile(r"https://([a-z0-9][a-z0-9-]*)\.trycloudflare\.com", re.I)
RELEASE_BASE = "https://github.com/cloudflare/cloudflared/releases/latest/download/"
ASSET_BY_ARCH = {
    "x86_64": "cloudflared-linux-amd64",
    "amd64": "cloudflared-linux-amd64",
    "aarch64": "cloudflared-linux-arm64",
    "arm64": "cloudflared-linux-arm64",
    "armv7l": "cloudflared-linux-arm",
    "armv6l": "cloudflared-linux-arm",
}
MAX_LINKS = 20
MAX_RESTARTS = 3
STARTUP_TIMEOUT = 60.0
MIN_BINARY_BYTES = 5 * 1024 * 1024


class TunnelError(Exception):
    """A user-facing failure (bad port, nothing listening, install failed...)."""


class TunnelManager:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.bin_dir = os.path.join(cfg.data_dir, "bin")
        self.state_file = os.path.join(cfg.data_dir, "tunnels.json")
        self._lock = threading.RLock()
        self._install_lock = threading.Lock()
        self._records: Dict[str, Dict[str, Any]] = {}
        self._procs: Dict[str, subprocess.Popen] = {}
        self._logs: Dict[str, Deque[str]] = {}
        self._version: Optional[str] = None
        self.install: Dict[str, Any] = {"state": "idle", "message": ""}
        self._load()
        self._reap_orphans()

    # ------------------------------------------------------------ binary ----
    def binary(self) -> Optional[str]:
        override = os.environ.get("PRIME_CLOUDFLARED", "")
        if override and os.access(override, os.X_OK):
            return override
        found = shutil.which("cloudflared")
        if found:
            return found
        local = os.path.join(self.bin_dir, "cloudflared")
        if os.path.isfile(local) and os.access(local, os.X_OK):
            return local
        return None

    def _probe_version(self, path: str) -> Optional[str]:
        try:
            out = subprocess.run([path, "--version"], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, timeout=15,
                                 universal_newlines=True)
            return (out.stdout or "").strip().splitlines()[0][:120] if out.stdout else None
        except (OSError, subprocess.SubprocessError, IndexError):
            return None

    def ensure_binary(self) -> str:
        """Return a usable cloudflared path, downloading it if necessary (blocking)."""
        path = self.binary()
        if path:
            return path
        with self._install_lock:
            path = self.binary()  # another request may have finished the install
            if path:
                return path
            return self._download()

    def _download(self) -> str:
        arch = platform.machine().lower()
        asset = ASSET_BY_ARCH.get(arch)
        if not asset:
            raise TunnelError(f"No cloudflared build is published for architecture '{arch}'. "
                              "Install cloudflared manually and put it on PATH.")
        os.makedirs(self.bin_dir, exist_ok=True)
        target = os.path.join(self.bin_dir, "cloudflared")
        tmp = target + ".part"
        url = RELEASE_BASE + asset
        self._set_install("downloading", f"Downloading cloudflared ({asset})…")
        try:
            import urllib.request
            req = urllib.request.Request(url, headers={"User-Agent": "prime-terminal"})
            written = 0
            with urllib.request.urlopen(req, timeout=60) as resp, open(tmp, "wb") as out:
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    written += len(chunk)
            if written < MIN_BINARY_BYTES:
                raise TunnelError(f"Download of cloudflared was too small ({written} bytes).")
            os.chmod(tmp, os.stat(tmp).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            version = self._probe_version(tmp)
            if not version:
                raise TunnelError("The downloaded cloudflared did not run on this system.")
            os.replace(tmp, target)
        except TunnelError as exc:
            self._cleanup_tmp(tmp)
            self._set_install("error", str(exc))
            raise
        except Exception as exc:  # noqa: BLE001 — network / disk errors are reported to the user
            self._cleanup_tmp(tmp)
            message = f"Could not download cloudflared from GitHub: {exc}"
            self._set_install("error", message)
            raise TunnelError(message) from exc
        self._version = version
        self._set_install("ready", f"cloudflared installed ({version})")
        log.info("installed cloudflared to %s (%s)", target, version)
        return target

    @staticmethod
    def _cleanup_tmp(path: str) -> None:
        try:
            os.remove(path)
        except OSError:
            pass

    def _set_install(self, state: str, message: str) -> None:
        with self._lock:
            self.install = {"state": state, "message": message}

    # ----------------------------------------------------------- persistence --
    def _load(self) -> None:
        try:
            with open(self.state_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return
        for rec in data.get("items", []):
            if isinstance(rec, dict) and rec.get("id"):
                rec["status"] = "stopped"
                rec["desired"] = False
                rec.setdefault("error", "")
                rec.setdefault("restarts", 0)
                self._records[rec["id"]] = rec

    def _save(self) -> None:
        with self._lock:
            items = [{k: v for k, v in rec.items() if not k.startswith("_")}
                     for rec in self._records.values()]
        tmp = self.state_file + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"items": items}, fh, indent=2)
            os.replace(tmp, self.state_file)
        except OSError:
            log.exception("could not persist public links")

    def _reap_orphans(self) -> None:
        """Kill cloudflared children left behind by a previous panel process."""
        changed = False
        for rec in self._records.values():
            pid = rec.get("pid")
            if not pid:
                continue
            if _is_cloudflared(pid):
                try:
                    os.killpg(pid, signal.SIGTERM)
                except OSError:
                    pass
            rec["pid"] = None
            changed = True
        if changed:
            self._save()

    # ------------------------------------------------------------- process ---
    def _launch(self, tid: str) -> None:
        """Start cloudflared for a record. Does not wait for the URL."""
        path = self.binary()
        if not path:
            raise TunnelError("cloudflared is not installed.")
        with self._lock:
            rec = self._records[tid]
            port = rec["port"]
            rec.update(status="starting", url="", error="", desired=True)
            self._logs[tid] = deque(maxlen=40)
        cmd = [path, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{port}"]
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, start_new_session=True,
                                universal_newlines=True, bufsize=1)
        with self._lock:
            self._procs[tid] = proc
            self._records[tid]["pid"] = proc.pid
            self._save()
        threading.Thread(target=self._pump_output, args=(tid, proc),
                         name=f"cloudflared-{tid}", daemon=True).start()

    def _pump_output(self, tid: str, proc: subprocess.Popen) -> None:
        try:
            for line in proc.stdout:  # type: ignore[union-attr]
                line = line.rstrip()
                with self._lock:
                    buf = self._logs.get(tid)
                    if buf is not None:
                        buf.append(line)
                    rec = self._records.get(tid)
                    if rec is None or rec.get("url"):
                        continue
                    if self._procs.get(tid) is not proc:
                        continue
                    for match in URL_RE.finditer(line):
                        if match.group(1).lower() == "api":
                            continue
                        rec["url"] = match.group(0)
                        rec["status"] = "live"
                        rec["started_at"] = time.time()
                        self._save()
                        break
        except (OSError, ValueError):
            pass

    def _wait_live(self, tid: str, timeout: float = STARTUP_TIMEOUT) -> Dict[str, Any]:
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                rec = self._records.get(tid)
                if rec is None:
                    raise TunnelError("The link was removed while starting.")
                if rec.get("url"):
                    return dict(rec)
                proc = self._procs.get(tid)
            if proc is None or proc.poll() is not None:
                break
            time.sleep(0.25)
        with self._lock:
            rec = self._records.get(tid, {})
            if rec.get("url"):
                return dict(rec)
            tail = list(self._logs.get(tid, []))[-6:]
        reason = " | ".join(line for line in tail if line) or "cloudflared did not announce a public address"
        self._kill(tid)
        with self._lock:
            rec = self._records.get(tid)
            if rec is not None:
                rec.update(status="error", error=reason[:600], desired=False, url="")
                self._save()
        raise TunnelError(f"Could not start the public link: {reason[:300]}")

    def _kill(self, tid: str) -> None:
        with self._lock:
            proc = self._procs.pop(tid, None)
            rec = self._records.get(tid)
            if rec is not None:
                rec["pid"] = None
        if proc is None:
            return
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except OSError:
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                pass
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass

    # ------------------------------------------------------------- public API -
    def _listening_tcp_ports(self) -> set:
        return {p["port"] for p in sysinfo.listening_ports()["items"]
                if str(p.get("protocol", "")).startswith("tcp") and p.get("state") == "LISTEN"}

    def create(self, port: int, label: str = "") -> Dict[str, Any]:
        if not 1 <= port <= 65535:
            raise TunnelError("Port must be between 1 and 65535.")
        if port == self.cfg.port:
            raise TunnelError("This is the control panel's own port. Publishing the panel "
                              "is refused; publish the service you run on another port.")
        with self._lock:
            for rec in self._records.values():
                if rec["port"] == port and rec.get("status") in ("live", "starting") and rec.get("url"):
                    return dict(rec)  # idempotent: already public
            if len(self._records) >= MAX_LINKS:
                raise TunnelError(f"Limit reached ({MAX_LINKS} public links). Stop one first.")
        if port not in self._listening_tcp_ports():
            raise TunnelError(f"Nothing is listening on TCP port {port}. Start the service first.")
        self.ensure_binary()
        tid = uuid.uuid4().hex[:10]
        with self._lock:
            self._records[tid] = {
                "id": tid, "port": port, "label": (label or "").strip()[:60],
                "url": "", "status": "starting", "error": "", "created": time.time(),
                "started_at": None, "pid": None, "restarts": 0, "desired": True,
            }
            self._save()
        try:
            self._launch(tid)
            return self._wait_live(tid)
        except Exception as exc:  # noqa: BLE001 — a failed start must not leave a dead row behind
            self._kill(tid)
            with self._lock:
                self._records.pop(tid, None)
                self._logs.pop(tid, None)
                self._save()
            if isinstance(exc, TunnelError):
                raise
            raise TunnelError(f"Could not start cloudflared: {exc}") from exc

    def restart(self, tid: str) -> Dict[str, Any]:
        with self._lock:
            if tid not in self._records:
                raise TunnelError("No such public link.")
            self._records[tid]["restarts"] = 0
        self._kill(tid)
        self.ensure_binary()
        self._launch(tid)
        return self._wait_live(tid)

    def stop(self, tid: str) -> None:
        with self._lock:
            rec = self._records.get(tid)
            if rec is None:
                raise TunnelError("No such public link.")
            rec["desired"] = False
        self._kill(tid)
        with self._lock:
            rec = self._records.get(tid)
            if rec is not None:
                rec.update(status="stopped", url="", pid=None)
                self._save()

    def remove(self, tid: str) -> None:
        self.stop(tid)
        with self._lock:
            self._records.pop(tid, None)
            self._logs.pop(tid, None)
            self._save()

    def sweep(self) -> None:
        """Watchdog, called periodically by the sampler. Never blocks."""
        with self._lock:
            candidates = [(tid, rec) for tid, rec in self._records.items()
                          if rec.get("desired") and rec.get("status") == "live"]
        for tid, rec in candidates:
            proc = self._procs.get(tid)
            if proc is None or proc.poll() is None:
                continue
            code = proc.returncode
            with self._lock:
                self._procs.pop(tid, None)
                if rec.get("restarts", 0) >= MAX_RESTARTS:
                    rec.update(status="error", desired=False, url="", pid=None,
                               error=f"cloudflared exited (code {code}) and the restart limit was reached.")
                    self._save()
                    continue
                rec["restarts"] = rec.get("restarts", 0) + 1
                rec.update(status="starting", url="", pid=None,
                           error=f"cloudflared exited (code {code}); restarting…")
                self._save()
            threading.Thread(target=self._auto_restart, args=(tid,), daemon=True).start()

    def _auto_restart(self, tid: str) -> None:
        try:
            self.ensure_binary()
            self._launch(tid)
            self._wait_live(tid)
            log.info("public link %s restarted automatically", tid)
        except TunnelError as exc:
            log.warning("auto-restart of public link %s failed: %s", tid, exc)

    def status(self) -> Dict[str, Any]:
        path = self.binary()
        if path and not self._version:
            self._version = self._probe_version(path)
        listening = self._listening_tcp_ports()
        now = time.time()
        with self._lock:
            items = []
            for rec in sorted(self._records.values(), key=lambda r: r.get("created", 0)):
                row = {k: v for k, v in rec.items() if not k.startswith("_")}
                row["port_open"] = rec["port"] in listening
                row["uptime"] = int(now - rec["started_at"]) if rec.get("started_at") and rec.get("status") == "live" else 0
                items.append(row)
            install = dict(self.install)
        return {"installed": bool(path), "path": path or "", "version": self._version or "",
                "install": install, "items": items, "limit": MAX_LINKS,
                "panel_port": self.cfg.port}

    def shutdown(self) -> None:
        with self._lock:
            tids = list(self._records.keys())
            for rec in self._records.values():
                rec["desired"] = False
        for tid in tids:
            self._kill(tid)
        with self._lock:
            for rec in self._records.values():
                if rec.get("status") in ("live", "starting"):
                    rec.update(status="stopped", url="", pid=None)
            self._save()


def _is_cloudflared(pid: int) -> bool:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as fh:
            return b"cloudflared" in fh.read()
    except OSError:
        return False
