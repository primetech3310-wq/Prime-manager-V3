"""Distributed node orchestration: node registry, enrollment and heartbeats.

Nodes run ``prime/node_agent.py`` (standard library only). The model is pull-free:
each agent pushes heartbeats to the panel, so nodes behind NAT or firewalls work
without inbound ports. The panel answers each heartbeat with queued commands from
a fixed allow-list (refresh, update, restart). There is no arbitrary remote
command execution by design.

Credentials:
  * Enrollment tokens are random, single-use, expire after one hour, and only
    their hashes are stored.
  * Each node receives a random secret on enrollment, stored as a hash.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

ENROLL_TTL = 3600
ONLINE_WINDOW = 75
MAX_NODES = 200
COMMANDS = ("refresh", "update", "restart")
_LOCK = threading.RLock()
_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,39}$")


class NodeError(ValueError):
    pass


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _num(value: Any, lo: float, hi: float, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number != number:  # NaN
        return default
    return max(lo, min(hi, number))


def _text(value: Any, limit: int = 120) -> str:
    return str(value or "")[:limit]


def sanitise_metrics(raw: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        raise NodeError("Metrics must be a JSON object")
    return {
        "hostname": _text(raw.get("hostname"), 120),
        "arch": _text(raw.get("arch"), 32),
        "kernel": _text(raw.get("kernel"), 120),
        "agent_version": _text(raw.get("agent_version"), 32),
        "cpu_count": int(_num(raw.get("cpu_count"), 0, 4096)),
        "load1": _num(raw.get("load1"), 0, 100000),
        "mem_total": int(_num(raw.get("mem_total"), 0, 1e15)),
        "mem_available": int(_num(raw.get("mem_available"), 0, 1e15)),
        "disk_total": int(_num(raw.get("disk_total"), 0, 1e18)),
        "disk_free": int(_num(raw.get("disk_free"), 0, 1e18)),
        "uptime": int(_num(raw.get("uptime"), 0, 1e10)),
    }


class NodeRegistry:
    def __init__(self, data_dir: str):
        self.dir = Path(data_dir).resolve() / "nodes"
        self.dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = self.dir / "registry.json"

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"enrollments": [], "nodes": []}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _save(self, data: Dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    # ----------------------------------------------------------- enroll
    def create_enrollment(self, created_by: str) -> Dict[str, Any]:
        token = "pne_" + secrets.token_urlsafe(24)
        now = time.time()
        with _LOCK:
            data = self._load()
            data["enrollments"] = [e for e in data["enrollments"] if e["expires_at"] > now and not e["used"]]
            data["enrollments"].append({"hash": _hash(token), "created_by": _text(created_by, 64),
                                        "created_at": now, "expires_at": now + ENROLL_TTL, "used": False})
            self._save(data)
        return {"token": token, "expires_at": now + ENROLL_TTL}

    def enroll(self, token: str, info: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(token, str) or not token.startswith("pne_") or len(token) > 128:
            raise NodeError("Enrollment token is not valid")
        name = str(info.get("name") or info.get("hostname") or "node").strip()
        if not _NAME.fullmatch(name):
            raise NodeError("Node name: 1–40 letters, digits, spaces, dots, dashes or underscores")
        now = time.time()
        wanted = _hash(token)
        with _LOCK:
            data = self._load()
            if len(data["nodes"]) >= MAX_NODES:
                raise NodeError(f"At most {MAX_NODES} nodes can be enrolled")
            match = None
            for entry in data["enrollments"]:
                if secrets.compare_digest(entry["hash"], wanted):
                    match = entry
                    break
            if not match or match["used"] or match["expires_at"] < now:
                raise NodeError("Enrollment token is invalid, expired or already used")
            match["used"] = True
            node_id = uuid.uuid4().hex[:16]
            secret = "pns_" + secrets.token_urlsafe(32)
            data["nodes"].append({"id": node_id, "name": name, "secret_hash": _hash(secret),
                                  "enrolled_at": now, "last_seen": 0, "metrics": {}, "queue": [],
                                  "last_command_at": 0})
            self._save(data)
        return {"node_id": node_id, "secret": secret, "heartbeat_seconds": 20}

    # -------------------------------------------------------- heartbeats
    def _authenticate(self, data: Dict[str, Any], node_id: str, secret: str) -> Dict[str, Any]:
        for node in data["nodes"]:
            if node["id"] == node_id:
                if not isinstance(secret, str) or not secrets.compare_digest(node["secret_hash"], _hash(secret)):
                    break
                return node
        raise NodeError("Node authentication failed")

    def heartbeat(self, node_id: str, secret: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
        # An empty body is a plain keep-alive: the last reported metrics are kept.
        clean = sanitise_metrics(metrics) if metrics else None
        with _LOCK:
            data = self._load()
            node = self._authenticate(data, node_id, secret)
            node["last_seen"] = time.time()
            if clean is not None:
                node["metrics"] = clean
            queued = node.get("queue", [])
            node["queue"] = []
            self._save(data)
        return {"commands": queued}

    def queue(self, node_id: str, action: str) -> Dict[str, Any]:
        if action not in COMMANDS:
            raise NodeError("Action must be refresh, update or restart")
        with _LOCK:
            data = self._load()
            node = next((n for n in data["nodes"] if n["id"] == node_id), None)
            if not node:
                raise NodeError("Node not found")
            if action not in node["queue"]:
                node["queue"].append(action)
            self._save(data)
        return {"ok": True, "queued": action}

    def remove(self, node_id: str) -> Dict[str, Any]:
        with _LOCK:
            data = self._load()
            before = len(data["nodes"])
            data["nodes"] = [n for n in data["nodes"] if n["id"] != node_id]
            if len(data["nodes"]) == before:
                raise NodeError("Node not found")
            self._save(data)
        return {"ok": True}

    def list(self) -> List[Dict[str, Any]]:
        now = time.time()
        items = []
        for node in self._load()["nodes"]:
            online = node["last_seen"] and now - node["last_seen"] < ONLINE_WINDOW
            items.append({"id": node["id"], "name": node["name"], "enrolled_at": node["enrolled_at"],
                          "last_seen": node["last_seen"], "online": bool(online),
                          "metrics": node.get("metrics", {}), "queued": node.get("queue", [])})
        return items


def install_command(panel_url: str, token: str) -> str:
    base = panel_url.rstrip("/")
    return (f"mkdir -p /opt/prime-node && curl -fsSL {base}/api/nodes/agent.py -o /opt/prime-node/node_agent.py"
            f" && python3 /opt/prime-node/node_agent.py enroll --panel {base} --token {token}"
            f" && python3 /opt/prime-node/node_agent.py run")
