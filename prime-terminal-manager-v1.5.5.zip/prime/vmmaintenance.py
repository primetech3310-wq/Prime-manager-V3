"""Offline QEMU disk recovery and persistent, bounded VM automation.

All mutation uses VMStore's process-wide lock. Run one panel worker per data
directory, as required by the application updater and PTY manager too.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import time
import uuid


class MaintenanceMixin:
    def _error(self, message):
        from .vms import VMError
        return VMError(message)

    def _offline(self, vm_id):
        vm = self._read(vm_id)
        if self._running(vm_id):
            raise self._error('Stop the VM before changing or copying its disk')
        return vm

    def _label(self, label):
        if not isinstance(label, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9 _.-]{0,63}', label):
            raise self._error('Use a label of 1–64 letters, digits, spaces, dots, dashes or underscores')
        return label

    def _image(self, *args):
        try:
            return subprocess.run(['qemu-img', *map(str, args)], check=True, timeout=1800,
                                  capture_output=True, text=True).stdout
        except (OSError, subprocess.SubprocessError) as exc:
            raise self._error('QEMU disk operation failed; check disk space and image integrity') from exc

    @staticmethod
    def _digest(path):
        digest = hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda: source.read(1024 * 1024), b''):
                digest.update(block)
        return digest.hexdigest()

    def vnc_socket(self, vm_id):
        self._dir(vm_id)  # validate before constructing any path
        # AF_UNIX paths must be short even when the panel data path is long.
        suffix = hashlib.sha256(str(self.root).encode()).hexdigest()[:16]
        directory = Path('/tmp') / f'prime-vnc-{os.getuid()}-{suffix}'
        directory.mkdir(mode=0o700, exist_ok=True)
        info = directory.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
            raise self._error('VNC socket directory must be private and owned by the panel user')
        return directory / (vm_id + '.sock')

    def restart(self, vm_id):
        with self._lock:
            self._read(vm_id)
            if self._running(vm_id):
                self.stop(vm_id)
            return self.start(vm_id)

    def recovery(self, vm_id):
        with self._lock:
            vm = self._read(vm_id)
            return {'backups': list(vm.get('backups', {}).values()),
                    'snapshots': list(vm.get('snapshots', {}).values()),
                    'schedules': list(vm.get('schedules', {}).values())}

    def backup(self, vm_id, label='Disk backup'):
        with self._lock:
            vm = self._offline(vm_id)
            self._label(label)
            if len(vm.get('backups', {})) >= 100:
                raise self._error('Delete an older backup first (maximum 100 per VM)')
            ident = uuid.uuid4().hex
            directory = self._dir(vm_id) / 'backups'
            directory.mkdir(mode=0o700, exist_ok=True)
            dest = directory / (ident + '.qcow2')
            try:
                self._image('convert', '-f', 'qcow2', '-O', 'qcow2', self._dir(vm_id) / 'disk.qcow2', dest)
                os.chmod(dest, 0o600)
                self._image('check', '-f', 'qcow2', dest)
                item = {'id': ident, 'label': label, 'created_at': time.time(),
                        'size': dest.stat().st_size, 'sha256': self._digest(dest)}
                vm.setdefault('backups', {})[ident] = item
                self._write(vm)
                return item
            except BaseException:
                dest.unlink(missing_ok=True)
                raise

    def backup_action(self, vm_id, backup_id, action):
        with self._lock:
            vm = self._offline(vm_id) if action == 'restore' else self._read(vm_id)
            self._dir(backup_id)  # same strict UUID syntax
            item = vm.get('backups', {}).get(backup_id)
            if not item:
                raise self._error('Backup not found')
            source = self._dir(vm_id) / 'backups' / (backup_id + '.qcow2')
            if action == 'delete':
                # Commit metadata first: a failed unlink can only leave an orphan,
                # never a listed recovery point whose disk has disappeared.
                del vm['backups'][backup_id]
                self._write(vm)
                source.unlink(missing_ok=True)
                return {'ok': True}
            if action != 'restore':
                raise self._error('Unknown backup action')
            if not source.is_file() or self._digest(source) != item['sha256']:
                raise self._error('Backup is missing or its checksum has changed')
            candidate = self._dir(vm_id) / ('restore-' + uuid.uuid4().hex + '.qcow2')
            try:
                shutil.copyfile(source, candidate)
                os.chmod(candidate, 0o600)
                if self._digest(candidate) != item['sha256']:
                    raise self._error('Restored copy failed checksum verification')
                self._image('check', '-f', 'qcow2', candidate)
                # Conversion backups contain the active disk, not internal
                # snapshots. Clear their catalog before replacing the disk.
                vm['snapshots'] = {}
                self._write(vm)
                os.replace(candidate, self._dir(vm_id) / 'disk.qcow2')
                return {'ok': True}
            finally:
                candidate.unlink(missing_ok=True)

    def snapshot(self, vm_id, label='Disk snapshot'):
        with self._lock:
            vm = self._offline(vm_id)
            self._label(label)
            if len(vm.get('snapshots', {})) >= 100:
                raise self._error('Delete an older snapshot first (maximum 100 per VM)')
            ident = uuid.uuid4().hex
            self._image('snapshot', '-c', ident, self._dir(vm_id) / 'disk.qcow2')
            item = {'id': ident, 'label': label, 'created_at': time.time()}
            vm.setdefault('snapshots', {})[ident] = item
            self._write(vm)
            return item

    def snapshot_action(self, vm_id, snapshot_id, action):
        with self._lock:
            vm = self._offline(vm_id)
            self._dir(snapshot_id)
            if snapshot_id not in vm.get('snapshots', {}):
                raise self._error('Snapshot not found')
            if action not in ('restore', 'delete'):
                raise self._error('Unknown snapshot action')
            self._image('snapshot', '-a' if action == 'restore' else '-d', snapshot_id,
                        self._dir(vm_id) / 'disk.qcow2')
            if action == 'delete':
                del vm['snapshots'][snapshot_id]
                self._write(vm)
            return {'ok': True}

    def add_schedule(self, vm_id, label, action, run_at, interval=0, keep=5):
        with self._lock:
            vm = self._read(vm_id)
            self._label(label)
            if action not in ('start', 'stop', 'restart', 'backup'):
                raise self._error('Schedule action must be start, stop, restart or backup')
            if (isinstance(run_at, bool) or not isinstance(run_at, (int, float))
                    or not math.isfinite(run_at) or not time.time() < run_at <= time.time() + 366 * 86400):
                raise self._error('Choose a future date within one year')
            if isinstance(interval, bool) or not isinstance(interval, int) or interval != 0 and not 60 <= interval <= 366 * 86400:
                raise self._error('Repeat interval must be 0 (once) or 60–31622400 seconds')
            if isinstance(keep, bool) or not isinstance(keep, int) or not 1 <= keep <= 100:
                raise self._error('Keep between 1 and 100 scheduled backups')
            if len(vm.get('schedules', {})) >= 100:
                raise self._error('Maximum 100 schedules per VM')
            item = {'id': uuid.uuid4().hex, 'label': label, 'action': action, 'next_run': run_at,
                    'interval': interval, 'keep': keep, 'enabled': True, 'state': 'waiting',
                    'last_run': None, 'last_error': ''}
            vm.setdefault('schedules', {})[item['id']] = item
            self._write(vm)
            return item

    def schedule_action(self, vm_id, schedule_id, action):
        with self._lock:
            vm = self._read(vm_id)
            self._dir(schedule_id)
            item = vm.get('schedules', {}).get(schedule_id)
            if not item:
                raise self._error('Schedule not found')
            if action == 'delete':
                del vm['schedules'][schedule_id]
            elif action in ('enable', 'disable'):
                if action == 'enable' and not item['interval'] and item['next_run'] <= time.time():
                    raise self._error('Create a new one-time schedule for a future date')
                item['enabled'] = action == 'enable'
            else:
                raise self._error('Unknown schedule action')
            self._write(vm)
            return {'ok': True}

    def recover_schedules(self):
        """Called once at process startup; never replay an interrupted claim."""
        with self._lock:
            for vm in self.list():
                dirty = False
                for item in vm.get('schedules', {}).values():
                    if item['state'] == 'running':
                        item.update(state='interrupted', last_error='Panel stopped during this operation; check the VM before retrying')
                        dirty = True
                if dirty:
                    self._write(vm)

    def run_due(self, now=None):
        """Persist each claim before executing; missed intervals are coalesced."""
        now = time.time() if now is None else now
        with self._lock:
            for listed in self.list():
                vm_id = listed['id']
                for schedule_id in list(listed.get('schedules', {})):
                    vm = self._read(vm_id)
                    item = vm['schedules'][schedule_id]
                    if not item['enabled'] or item['next_run'] > now:
                        continue
                    item.update(state='running', last_run=now, last_error='')
                    if item['interval']:
                        item['next_run'] += (int((now - item['next_run']) // item['interval']) + 1) * item['interval']
                    else:
                        item['enabled'] = False
                    self._write(vm)
                    try:
                        action = item['action']
                        if action == 'backup':
                            # Prune this schedule's previous successful copies only
                            # after the new copy has passed its integrity check.
                            if len(vm.get('backups', {})) >= 100:
                                raise self._error('Backup limit reached; delete an older backup')
                            backup = self.backup(vm_id, item['label'])
                            current = self._read(vm_id)
                            current['backups'][backup['id']]['schedule_id'] = schedule_id
                            self._write(current)
                            copies = sorted((b for b in current['backups'].values() if b.get('schedule_id') == schedule_id),
                                            key=lambda b: b['created_at'], reverse=True)
                            for old in copies[item['keep']:]:
                                self.backup_action(vm_id, old['id'], 'delete')
                        elif action == 'restart':
                            self.restart(vm_id)
                        elif bool(self._running(vm_id)) != (action == 'start'):
                            getattr(self, action)(vm_id)
                        state, error = 'complete', ''
                    except Exception as exc:
                        state, error = 'failed', str(exc)[:400]
                    current = self._read(vm_id)
                    current['schedules'][schedule_id].update(state=state, last_error=error)
                    self._write(current)
