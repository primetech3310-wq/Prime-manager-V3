"""Storage pools and ISO image administration.

A pool is a registered directory with its own capacity figures. ISO images live in
``<pool>/iso``. Uploads are streamed to a temporary file, checked for the ISO 9660
signature and free space, then renamed into place. Paths are always resolved and
checked, so an upload name can never leave its pool.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

MAX_ISO_BYTES = 8 * 1024 * 1024 * 1024
FREE_RESERVE_BYTES = 1024 * 1024 * 1024
MAX_POOLS = 20
ISO_SIGNATURE_OFFSET = 32769
ISO_SIGNATURE = b"CD001"
_POOL_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,39}$")
_ISO_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}\.iso$", re.IGNORECASE)
_LOCK = threading.RLock()


class StorageError(ValueError):
    pass


def _safe_dir(path_text: str) -> Path:
    if not isinstance(path_text, str) or not path_text.startswith("/"):
        raise StorageError("Pool path must be an absolute path")
    if "\x00" in path_text or len(path_text) > 1024:
        raise StorageError("Pool path is not valid")
    path = Path(path_text).resolve()
    if str(path) in ("/", "/boot", "/etc", "/usr", "/bin", "/sbin", "/lib", "/proc", "/sys", "/dev", "/run"):
        raise StorageError("Choose a dedicated directory, not a system directory")
    return path


class StorageManager:
    def __init__(self, data_dir: str):
        self.base = Path(data_dir).resolve() / "storage"
        self.base.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.config_path = self.base / "pools.json"
        self._ensure_default()

    # ----------------------------------------------------------- config
    def _load(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return {"pools": []}
        return json.loads(self.config_path.read_text(encoding="utf-8"))

    def _save(self, data: Dict[str, Any]) -> None:
        tmp = self.config_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.config_path)

    def _ensure_default(self) -> None:
        with _LOCK:
            data = self._load()
            if not any(p["id"] == "default" for p in data["pools"]):
                default_path = (self.base / "default-pool").resolve()
                default_path.mkdir(mode=0o750, parents=True, exist_ok=True)
                data["pools"].insert(0, {"id": "default", "name": "Default", "path": str(default_path),
                                         "created_at": time.time(), "builtin": True})
                self._save(data)

    def _pool(self, pool_id: str) -> Dict[str, Any]:
        for pool in self._load()["pools"]:
            if pool["id"] == pool_id:
                return pool
        raise StorageError("Storage pool not found")

    # ------------------------------------------------------------ pools
    def pools(self) -> List[Dict[str, Any]]:
        result = []
        for pool in self._load()["pools"]:
            entry = dict(pool)
            try:
                usage = shutil.disk_usage(pool["path"])
                entry.update({"total": usage.total, "used": usage.used, "free": usage.free, "available": True})
            except OSError:
                entry.update({"total": 0, "used": 0, "free": 0, "available": False})
            entry["iso_count"] = len(self.list_isos(pool["id"]))
            result.append(entry)
        return result

    def add_pool(self, name: str, path_text: str) -> Dict[str, Any]:
        if not isinstance(name, str) or not _POOL_NAME.fullmatch(name.strip()):
            raise StorageError("Pool name: 1–40 letters, digits, spaces, dots, dashes or underscores")
        path = _safe_dir(path_text)
        with _LOCK:
            data = self._load()
            if len(data["pools"]) >= MAX_POOLS:
                raise StorageError(f"At most {MAX_POOLS} pools are allowed")
            if any(Path(p["path"]).resolve() == path for p in data["pools"]):
                raise StorageError("That directory is already a pool")
            try:
                path.mkdir(mode=0o750, parents=True, exist_ok=True)
            except OSError as exc:
                raise StorageError("Cannot create that directory") from exc
            if not os.access(path, os.W_OK):
                raise StorageError("The panel cannot write to that directory")
            pool = {"id": uuid.uuid4().hex[:10], "name": name.strip(), "path": str(path),
                    "created_at": time.time(), "builtin": False}
            data["pools"].append(pool)
            self._save(data)
            return pool

    def remove_pool(self, pool_id: str) -> Dict[str, Any]:
        """Unregister a pool. Files are never deleted, and the built-in pool cannot be removed."""
        with _LOCK:
            data = self._load()
            pool = self._pool(pool_id)
            if pool.get("builtin"):
                raise StorageError("The default pool cannot be removed")
            if self.list_isos(pool_id):
                raise StorageError("Delete the ISO images in this pool first")
            data["pools"] = [p for p in data["pools"] if p["id"] != pool_id]
            self._save(data)
            return {"ok": True, "files_kept": True}

    # ------------------------------------------------------------- ISOs
    def _iso_dir(self, pool_id: str) -> Path:
        pool = self._pool(pool_id)
        directory = Path(pool["path"]) / "iso"
        directory.mkdir(mode=0o750, parents=True, exist_ok=True)
        return directory

    def list_isos(self, pool_id: str) -> List[Dict[str, Any]]:
        try:
            pool = self._pool(pool_id)
        except StorageError:
            return []
        directory = Path(pool["path"]) / "iso"
        if not directory.is_dir():
            return []
        items = []
        for entry in sorted(directory.iterdir()):
            if entry.is_file() and _ISO_NAME.fullmatch(entry.name):
                stat = entry.stat()
                items.append({"name": entry.name, "size": stat.st_size, "modified": stat.st_mtime})
        return items

    def iso_path(self, pool_id: str, name: str) -> Path:
        if not isinstance(name, str) or not _ISO_NAME.fullmatch(name):
            raise StorageError("Invalid ISO name")
        directory = self._iso_dir(pool_id).resolve()
        path = (directory / name).resolve()
        if path.parent != directory or not path.is_file():
            raise StorageError("ISO image not found")
        return path

    def checksum(self, pool_id: str, name: str) -> Dict[str, Any]:
        path = self.iso_path(pool_id, name)
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
                digest.update(block)
        return {"name": name, "sha256": digest.hexdigest(), "size": path.stat().st_size}

    def begin_upload(self, pool_id: str, name: str, declared_size: Optional[int]) -> Dict[str, Any]:
        """Validate an upload before any bytes are written. Returns a temp path to stream into."""
        if not isinstance(name, str) or not _ISO_NAME.fullmatch(name):
            raise StorageError("ISO name must end in .iso and use letters, digits, dots, dashes or underscores")
        directory = self._iso_dir(pool_id)
        final = directory / name
        if final.exists():
            raise StorageError("An ISO with that name already exists")
        if declared_size is not None:
            if declared_size <= 0 or declared_size > MAX_ISO_BYTES:
                raise StorageError("ISO must be between 1 byte and 8 GiB")
            if shutil.disk_usage(directory).free < declared_size + FREE_RESERVE_BYTES:
                raise StorageError("Not enough free space in this pool for that ISO")
        temp = directory / (".upload-" + uuid.uuid4().hex + ".part")
        return {"temp": str(temp), "final": str(final)}

    def finish_upload(self, temp: str, final: str, written: int) -> Dict[str, Any]:
        """Check the ISO signature of a finished upload, then move it into place."""
        temp_path = Path(temp)
        final_path = Path(final)
        try:
            if written <= 0:
                raise StorageError("Upload was empty")
            if written > MAX_ISO_BYTES:
                raise StorageError("ISO exceeds the 8 GiB limit")
            with temp_path.open("rb") as handle:
                handle.seek(ISO_SIGNATURE_OFFSET)
                if handle.read(len(ISO_SIGNATURE)) != ISO_SIGNATURE:
                    raise StorageError("The file is not an ISO 9660 image")
            os.chmod(temp_path, 0o640)
            os.replace(temp_path, final_path)
            return {"ok": True, "name": final_path.name, "size": written}
        finally:
            temp_path.unlink(missing_ok=True)

    def delete_iso(self, pool_id: str, name: str) -> Dict[str, Any]:
        path = self.iso_path(pool_id, name)
        path.unlink()
        return {"ok": True}
