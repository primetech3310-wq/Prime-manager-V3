"""Isolated, short-lived sandboxes for the provisioning API (``POST /API/sandbox``).

A sandbox is a Linux user environment that installs SSHx and reports its link.
It is created and read only by the key that created it.

Backends, chosen per host:

  bwrap  bubblewrap user namespaces (preferred, full speed, no emulation).
         * own PID, IPC, UTS and mount namespaces, all capabilities dropped,
           nested user namespaces disabled, new session (no TTY hijack);
         * root filesystem is an overlay: the shared read-only template is the
           lower layer, the sandbox's own directory the upper layer. Creating a
           sandbox copies nothing, and writes never reach the template;
         * the host filesystem is not visible at all;
         * network: ``internet`` runs the sandbox in a pasta network namespace
           (outbound only, no inbound ports); ``none`` has no network at all.
  proot  fallback for containers and hosts that block user namespaces.
         Filesystem view only: processes and (for ``internet``) the network are
         still shared with the host. The API reports this as ``isolation``.

Full virtual machines stay in ``prime/vms.py`` for hosts with KVM.

The sandbox writes its outputs into one directory that is bind-mounted from the
host: ``status``, ``sshx.txt``, ``sshx.log``, ``install.log``. The panel reads
the link from that file, so no callback or inbound network path is needed.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

try:  # POSIX only; the limits are skipped elsewhere.
    import resource
except ImportError:  # pragma: no cover
    resource = None

DEFAULT_TTL = 3600
MIN_TTL = 300
MAX_TTL = 86400
DEFAULT_MEMORY_MB = 1024
MIN_MEMORY_MB = 256
MAX_MEMORY_MB = 8192
MAX_PER_KEY = 3
MAX_TOTAL = 20
BACKENDS = ("auto", "bwrap", "proot")
NETWORKS = ("internet", "none")
GUEST_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
OUT_DIR = "/run/prime-out"
_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$")
SSHX_LINK = re.compile(r"^https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}$")
_LINK_IN_LOG = re.compile(r"https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}")
_LOCK = threading.RLock()

# Runs as PID 1 inside the sandbox. Writes its state into OUT_DIR.
GUEST_SCRIPT = """
OUT=/run/prime-out
echo starting > $OUT/status
export TAR_OPTIONS=--no-same-owner
if ! command -v sshx >/dev/null 2>&1; then
  curl -sSf https://sshx.io/get 2>>$OUT/install.log | sh >>$OUT/install.log 2>&1 || {
    echo install-failed > $OUT/status; exit 1; }
fi
nohup sshx > $OUT/sshx.log 2>&1 &
i=0
while [ $i -lt 120 ]; do
  link=$(grep -o 'https://sshx.io/s/[^[:space:]]*' $OUT/sshx.log 2>/dev/null | head -n 1)
  if [ -n "$link" ]; then echo "$link" > $OUT/sshx.txt; echo ready > $OUT/status; break; fi
  i=$((i + 1)); sleep 1
done
[ -f $OUT/sshx.txt ] || { echo no-link > $OUT/status; exit 1; }
wait
""".strip()


class SandboxError(ValueError):
    """A request the host cannot satisfy or that breaks the rules (maps to HTTP 400/503)."""


def owner_ref(token: str) -> str:
    """Only this hash of an API key is stored. It identifies the owner of a sandbox."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


def _version(text: str) -> tuple:
    match = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", text or "")
    if not match:
        return (0, 0, 0)
    return tuple(int(part or 0) for part in match.groups())


def probe_backends(which: Callable[[str], Optional[str]] = shutil.which,
                   run: Callable[..., Any] = subprocess.run) -> Dict[str, Any]:
    """Find the sandbox tools on this host and check that bubblewrap really works here."""
    found: Dict[str, Any] = {
        "bwrap": None, "bwrap_overlay": False, "bwrap_works": False,
        "pasta": None, "pasta_works": False,
        "slirp4netns": None, "slirp_works": False,
        "proot": None,
    }
    bwrap = which("bwrap")
    if bwrap:
        found["bwrap"] = bwrap
        try:
            version = run([bwrap, "--version"], capture_output=True, text=True, timeout=5).stdout
            help_out = run([bwrap, "--help"], capture_output=True, text=True, timeout=5).stdout or ""
            found["bwrap_overlay"] = "--overlay" in help_out or "--overlay-src" in help_out
            probe = run([bwrap, "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev",
                         "--unshare-pid", "--", "/bin/true"], capture_output=True, timeout=10)
            found["bwrap_works"] = probe.returncode == 0
        except (OSError, subprocess.SubprocessError):
            found["bwrap_works"] = False
    found["pasta"] = which("pasta")
    found["slirp4netns"] = which("slirp4netns")
    # pasta only when non-root (root mapping fails on many hosts)
    if found["pasta"] and found["bwrap_works"] and os.geteuid() != 0:
        try:
            probe = run([found["pasta"], "--config-net", "-t", "none", "-u", "none", "--",
                         found["bwrap"], "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev",
                         "--unshare-pid", "--", "/bin/true"], capture_output=True, timeout=10)
            found["pasta_works"] = probe.returncode == 0
        except (OSError, subprocess.SubprocessError):
            found["pasta_works"] = False
    # slirp4netns: binary present is enough; attach is tested at launch
    if found["slirp4netns"]:
        found["slirp_works"] = True
    found["proot"] = which("proot")
    return found


_PROBE: Dict[str, Any] = {}
_PROBE_LOCK = threading.Lock()


def cached_backends() -> Dict[str, Any]:
    """The host probe, run once per panel process. Requests create a new manager each time,
    so caching here is what keeps them from re-running bubblewrap and pasta every call."""
    with _PROBE_LOCK:
        if not _PROBE:
            _PROBE.update(probe_backends())
        return _PROBE


def peek_backends() -> Optional[Dict[str, Any]]:
    """The probe result if it is ready, else None. Never blocks."""
    return _PROBE or None


def sandbox_argv(*, bwrap: str, lower: Path, upper: Path, work: Path, out_dir: Path,
                 hostname: str, network: str, pasta: Optional[str], overlay: bool,
                 use_slirp: bool = False) -> List[str]:
    """Build the bubblewrap command line (pure function, no side effects).

    network=none or use_slirp: --unshare-net (slirp4netns attaches after start).
    network=internet + pasta: pasta wraps argv and owns the netns (no --unshare-net).
    Never silently shares the host network.
    """
    if network not in NETWORKS:
        raise SandboxError("network must be internet or none")
    argv = [bwrap, "--die-with-parent", "--new-session", "--cap-drop", "ALL"]
    if os.geteuid() != 0:
        argv += ["--disable-userns", "--unshare-user-try"]
    argv += ["--unshare-pid", "--unshare-ipc", "--unshare-uts", "--unshare-cgroup-try",
             "--hostname", hostname, "--clearenv",
             "--setenv", "HOME", "/root", "--setenv", "PATH", GUEST_PATH,
             "--setenv", "TERM", "xterm-256color", "--setenv", "LANG", "C.UTF-8"]
    # Private netns for none, or when slirp will attach; pasta owns netns itself.
    if network == "none" or use_slirp or not pasta:
        argv += ["--unshare-net"]
    if overlay:
        argv += ["--overlay-src", str(lower), "--overlay", str(upper), str(work), "/"]
    else:
        argv += ["--bind", str(upper), "/"]
    argv += ["--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp", "--tmpfs", "/run",
             "--bind", str(out_dir), OUT_DIR, "--chdir", "/root",
             "--", "/bin/sh", "-c", GUEST_SCRIPT]
    if network == "internet" and pasta and not use_slirp:
        return [pasta, "--config-net", "-t", "none", "-u", "none", "--"] + argv
    return argv


def proot_argv(*, proot: str, root: Path, out_dir: Path) -> List[str]:
    return ["env", "-i", "HOME=/root", "PATH=" + GUEST_PATH, "TERM=xterm-256color", "LANG=C.UTF-8",
            proot, "-0", "-r", str(root), "-b", "/proc", "-b", "/dev",
            "-b", f"{out_dir}:{OUT_DIR}", "-w", "/root", "/bin/sh", "-c", GUEST_SCRIPT]


def _limits(memory_mb: int):
    """Applied in the child before exec. Address space is capped at three times the
    memory budget because runtimes reserve more virtual memory than they use."""
    def apply():
        if resource is None:
            return
        address_space = memory_mb * 3 * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (address_space, address_space))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
    return apply


def _alive(pid: Optional[int]) -> bool:
    if not pid or pid <= 1:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:  # a zombie still answers kill(0); it is not running any more
        with open(f"/proc/{pid}/stat", encoding="utf-8") as handle:
            return handle.read().rsplit(")", 1)[1].split()[0] != "Z"
    except (OSError, IndexError):
        return True


class SandboxManager:
    def __init__(self, data_dir: str, *, backends: Optional[Dict[str, Any]] = None):
        self.root = Path(data_dir).resolve() / "sandboxes"
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.registry = self.root / "registry.json"
        self.template = Path(os.environ.get("PRIME_SANDBOX_ROOTFS") or (self.root / "template"))
        self.backends = backends if backends is not None else cached_backends()
        self._procs: Dict[str, Any] = {}

    # ------------------------------------------------------------ storage
    def _load(self) -> Dict[str, Any]:
        if not self.registry.exists():
            return {"sandboxes": []}
        return json.loads(self.registry.read_text(encoding="utf-8"))

    def _save(self, data: Dict[str, Any]) -> None:
        tmp = self.registry.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.registry)

    # ----------------------------------------------------------- choices
    def template_ready(self) -> bool:
        return (self.template / "bin").is_dir() or (self.template / "usr").is_dir()

    def choose_backend(self, requested: str, network: str) -> str:
        if requested not in BACKENDS:
            raise SandboxError("backend must be auto, bwrap or proot")
        if network not in NETWORKS:
            raise SandboxError("network must be internet or none")
        b = self.backends
        net_ok = network == "none" or bool(b.get("pasta_works")) or bool(b.get("slirp_works"))
        if requested in ("auto", "bwrap") and b.get("bwrap_works") and (network == "none" or net_ok):
            return "bwrap"
        if requested == "bwrap":
            if not b.get("bwrap_works"):
                raise SandboxError("bubblewrap cannot create namespaces on this host (install bwrap, "
                                   "and allow unprivileged user namespaces), or use backend proot.")
            if network == "internet" and not net_ok:
                raise SandboxError("Internet sandboxes need pasta (non-root) or slirp4netns. "
                                   "Neither works on this host; use network 'none' or install tools.")
            return "bwrap"
        if network == "none":
            raise SandboxError("Network isolation needs bubblewrap (bwrap) on this host. "
                               "Create the sandbox with network 'internet' to use proot.")
        if b.get("proot"):
            return "proot"
        raise SandboxError("No sandbox backend is available. Install bubblewrap with pasta/slirp4netns "
                           "(preferred) or proot.")

    def isolation(self, backend: str, network: str, net_impl: str = "") -> str:
        if backend == "proot":
            return "filesystem only (proot): processes and network are shared with the host"
        if network == "none":
            return "namespaces: pid, ipc, uts, mount, network (none); capabilities dropped"
        impl = net_impl or ("pasta" if self.backends.get("pasta_works") else
                            "slirp4netns" if self.backends.get("slirp_works") else "unavailable")
        if impl == "pasta":
            return "namespaces: pid, ipc, uts, mount, network (pasta, outbound only); capabilities dropped"
        if impl == "slirp4netns":
            return "namespaces: pid, ipc, uts, mount, network (slirp4netns, outbound only); capabilities dropped"
        return "namespaces: pid, ipc, uts, mount, network (none — internet unavailable); capabilities dropped"

    # -------------------------------------------------------------- create
    def create(self, token: str, name: Optional[str], memory_mb: int, ttl: int,
               backend: str = "auto", network: str = "internet") -> Dict[str, Any]:
        if name is not None and not _NAME.fullmatch(name):
            raise SandboxError("name: 1-40 letters, digits, dots, dashes or underscores")
        if not MIN_MEMORY_MB <= int(memory_mb) <= MAX_MEMORY_MB:
            raise SandboxError(f"memory must be {MIN_MEMORY_MB}-{MAX_MEMORY_MB} MB")
        if not MIN_TTL <= int(ttl) <= MAX_TTL:
            raise SandboxError(f"ttl must be {MIN_TTL}-{MAX_TTL} seconds")
        if not self.template_ready():
            raise SandboxError("The sandbox template is not built. Run scripts/build_sandbox_rootfs.sh "
                               "on the host, then try again.")
        chosen = self.choose_backend(backend, network)
        if network == "internet":
            if self.backends.get("pasta_works"):
                net_impl = "pasta"
            elif self.backends.get("slirp_works"):
                net_impl = "slirp4netns"
            else:
                raise SandboxError("Internet is unavailable on this host (need pasta or slirp4netns). "
                                   "Create with network 'none' instead.")
        else:
            net_impl = "none"
        owner = owner_ref(token)
        now = time.time()
        sid = "sbx-" + secrets.token_hex(6)
        base = self.root / "instances" / sid
        record = {"id": sid, "owner": owner, "name": name or sid, "backend": chosen,
                  "network": network, "net_impl": net_impl,
                  "memory_mb": int(memory_mb), "created_at": now,
                  "expires_at": now + int(ttl), "pid": None, "dir": str(base)}
        with _LOCK:
            data = self._load()
            mine = [r for r in data["sandboxes"] if hmac.compare_digest(r["owner"], owner)]
            if len(mine) >= MAX_PER_KEY:
                raise SandboxError(f"Each key may have up to {MAX_PER_KEY} active sandboxes")
            if len(data["sandboxes"]) >= MAX_TOTAL:
                raise SandboxError("The host has no free sandbox slots; try again later")
            for sub in ("out", "upper", "work"):
                (base / sub).mkdir(mode=0o700, parents=True, exist_ok=True)
            data["sandboxes"].append(record)
            self._save(data)
        try:
            pid = self._launch(record)
        except Exception:
            with _LOCK:
                data = self._load()
                data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != sid]
                self._save(data)
            shutil.rmtree(base, ignore_errors=True)
            raise
        with _LOCK:
            data = self._load()
            for item in data["sandboxes"]:
                if item["id"] == sid:
                    item["pid"] = pid
            self._save(data)
        return self._public(dict(record, pid=pid))

    def _launch(self, record: Dict[str, Any]) -> Optional[int]:
        base = Path(record["dir"])
        out = base / "out"
        upper = base / "upper"
        work = base / "work"
        (upper / "run" / "prime-out").mkdir(parents=True, exist_ok=True)
        net_impl = record.get("net_impl") or "none"
        if record["backend"] == "bwrap":
            pasta = self.backends.get("pasta") if self.backends.get("pasta_works") else None
            use_slirp = (record["network"] == "internet" and not pasta and
                         bool(self.backends.get("slirp_works")))
            argv = sandbox_argv(bwrap=self.backends["bwrap"], lower=self.template, upper=upper,
                                work=work, out_dir=out, hostname="sbx-" + record["id"][-8:],
                                network=record["network"], pasta=pasta,
                                overlay=bool(self.backends.get("bwrap_overlay")),
                                use_slirp=use_slirp)
            if not self.backends.get("bwrap_overlay"):
                subprocess.run(["cp", "-a", "--reflink=auto", str(self.template) + "/.", str(upper)],
                               check=True, timeout=900)
            # Ensure DNS works inside private netns (slirp/pasta).
            etc = upper / "etc"
            etc.mkdir(exist_ok=True)
            (etc / "resolv.conf").write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        else:
            subprocess.run(["cp", "-a", "--reflink=auto", str(self.template) + "/.", str(upper)],
                           check=True, timeout=900)
            argv = proot_argv(proot=self.backends["proot"], root=upper, out_dir=out)
            use_slirp = False
        log_path = base / "console.log"
        log = open(log_path, "ab")
        try:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                    start_new_session=True, close_fds=True,
                                    preexec_fn=_limits(record["memory_mb"]))
            self._procs[record["id"]] = proc
            # Attach slirp4netns to the sandbox netns for outbound-only internet.
            if record["backend"] == "bwrap" and use_slirp and proc.pid:
                slirp = self.backends.get("slirp4netns")
                try:
                    time.sleep(0.2)
                    if _alive(proc.pid):
                        sp = subprocess.Popen(
                            [slirp, "--configure", "--mtu=65520", "--disable-host-loopback",
                             str(proc.pid), "tap0"],
                            stdin=subprocess.DEVNULL, stdout=log, stderr=log, close_fds=True)
                        time.sleep(0.5)
                        if sp.poll() is None:
                            self._procs[record["id"] + ":slirp"] = sp
                        else:
                            log.write(b"slirp4netns exited early\n")
                            log.flush()
                except (OSError, subprocess.SubprocessError) as exc:
                    log.write(f"slirp4netns attach failed: {exc}\n".encode())
                    log.flush()
        finally:
            log.close()
        return proc.pid

    # ------------------------------------------------------------ reading
    def _owned(self, token: str, sid: str) -> Dict[str, Any]:
        owner = owner_ref(token)
        for record in self._load()["sandboxes"]:
            if record["id"] == sid and hmac.compare_digest(record["owner"], owner):
                return record
        raise LookupError(sid)

    def _read(self, record: Dict[str, Any], name: str) -> str:
        try:
            return (Path(record["dir"]) / "out" / name).read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            return ""

    def _link(self, record: Dict[str, Any]) -> Optional[str]:
        raw = self._read(record, "sshx.txt")
        if not raw:
            raw = next(iter(_LINK_IN_LOG.findall(self._read(record, "sshx.log"))), "")
        # strip residual ANSI colour codes from sshx output
        raw = re.sub(r"\x1b\[[0-9;]*m", "", raw or "").strip()
        return raw if raw and SSHX_LINK.fullmatch(raw) else None

    def _state(self, record: Dict[str, Any]) -> Dict[str, Any]:
        link = self._link(record)
        if link:
            status = "ready"
        else:
            phase = self._read(record, "status")
            if phase in ("install-failed", "no-link"):
                status = "failed"
            elif _alive(record.get("pid")):
                status = "starting"
            else:
                status = "failed" if phase else "stopped"
        return {"status": status, "sshx": link}

    def _public(self, record: Dict[str, Any]) -> Dict[str, Any]:
        state = self._state(record)
        return {"id": record["id"], "name": record["name"], "status": state["status"],
                "running": _alive(record.get("pid")), "sshx": state["sshx"],
                "backend": record["backend"], "network": record["network"],
                "isolation": self.isolation(record["backend"], record["network"],
                                              record.get("net_impl", "")),
                "memory_mb": record["memory_mb"], "expires_at": int(record["expires_at"]),
                "status_url": "/API/sandbox/" + record["id"]}

    def status(self, token: str, sid: str, wait: int = 0) -> Dict[str, Any]:
        deadline = time.time() + max(0, min(int(wait), 900))
        while True:
            record = self._owned(token, sid)
            state = self._state(record)
            if state["status"] != "starting" or time.time() >= deadline:
                return self._public(record)
            time.sleep(2)

    # ------------------------------------------------------------- delete
    def delete(self, token: str, sid: str) -> Dict[str, Any]:
        record = self._owned(token, sid)
        self._stop(record)
        with _LOCK:
            data = self._load()
            data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != sid]
            self._save(data)
        shutil.rmtree(record["dir"], ignore_errors=True)
        return {"ok": True, "id": sid}

    def _stop(self, record: Dict[str, Any]) -> None:
        proc = self._procs.pop(record["id"], None)
        pid = record.get("pid")
        if proc is not None:
            proc.poll()
        if not pid or pid <= 1 or not _alive(pid):
            return
        try:
            os.killpg(pid, signal.SIGTERM)  # the sandbox leads its own session
        except OSError:
            pass
        for _ in range(30):
            if not _alive(pid):
                break
            time.sleep(0.1)
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                pass
        if proc is not None:
            try:
                proc.wait(timeout=5)
            except subprocess.SubprocessError:
                pass

    def expire_due(self) -> int:
        now = time.time()
        with _LOCK:
            due = [r for r in self._load()["sandboxes"] if r["expires_at"] <= now]
        for record in due:
            self._stop(record)
            with _LOCK:
                data = self._load()
                data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != record["id"]]
                self._save(data)
            shutil.rmtree(record["dir"], ignore_errors=True)
        return len(due)
