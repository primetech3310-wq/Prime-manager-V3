"""Bounded ZIP validation, application backup, and supervised restart.

Only application files are replaced. Data, config, virtualenvs and VM disks stay
outside the transaction. Uploaded application code is trusted administrator code.
This file also runs as a standalone stdlib-only restart supervisor.
"""
from __future__ import annotations

import ast
import fcntl
import json
import os
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from urllib.request import urlopen

MAX_UPLOAD = 64 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
APP_ITEMS = ('prime', 'run.py', 'panel.sh', 'requirements.txt', 'docs', 'tests', 'workspace-runtime')
REQUIRED = ('prime/app.py', 'prime/__init__.py', 'prime/static/index.html', 'run.py')


class UpdateError(ValueError):
    pass


def write_json(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8') as output:
        os.chmod(temporary, 0o600)
        json.dump(data, output)
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def validate_zip(archive, destination):
    """Extract only an explicitly allowed application tree, never user data."""
    destination = Path(destination)
    try:
        with zipfile.ZipFile(archive) as source:
            entries = source.infolist()
            if not entries or len(entries) > 5000:
                raise UpdateError('Archive must contain between 1 and 5000 entries')
            names = set()
            total = 0
            for entry in entries:
                name = entry.filename.rstrip('/')
                parts = PurePosixPath(name).parts
                if (not name or not parts or name.startswith('/') or '\\' in name or
                        any(p in ('..', '.') or ':' in p for p in name.split('/')) or
                        any(ord(c) < 32 for c in name) or len(name) > 1024 or name in names):
                    raise UpdateError('Archive contains unsafe or duplicate paths')
                names.add(name)
                mode = entry.external_attr >> 16
                kind = stat.S_IFMT(mode)
                if kind not in (0, stat.S_IFDIR, stat.S_IFREG) or entry.flag_bits & 1:
                    raise UpdateError('Links, special files and encrypted entries are not supported')
                if (entry.is_dir() and kind == stat.S_IFREG) or (not entry.is_dir() and kind == stat.S_IFDIR):
                    raise UpdateError('Archive has conflicting file types')
                total += entry.file_size
                if total > MAX_EXPANDED or entry.file_size > MAX_EXPANDED or entry.file_size > max(1, entry.compress_size) * 500:
                    raise UpdateError('Archive exceeds the expanded size or compression limit')
            prefix = ''
            if not all(n in names for n in REQUIRED):
                roots = {PurePosixPath(n).parts[0] for n in names}
                if len(roots) != 1:
                    raise UpdateError('Archive must contain the panel application at its root or one enclosing folder')
                prefix = next(iter(roots)) + '/'
                if not all(prefix + n in names for n in REQUIRED):
                    raise UpdateError('Archive is missing required panel files')
            written = 0
            for entry in entries:
                name = entry.filename.rstrip('/')
                if prefix and name == prefix[:-1]:
                    continue
                relative = name[len(prefix):]
                parts = PurePosixPath(relative).parts
                # Archives may contain release notes; configuration, databases,
                # .venv, hidden files, VM disks and all other paths are ignored.
                if not parts or parts[0] not in APP_ITEMS:
                    continue
                if any(p.startswith('.') or p == '__pycache__' for p in parts):
                    continue
                if len(parts) > 1 and parts[0] in ('run.py', 'panel.sh', 'requirements.txt'):
                    raise UpdateError('Expected a regular application file')
                target = destination.joinpath(*parts)
                if entry.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.open(entry) as incoming, target.open('xb') as output:
                    while True:
                        block = incoming.read(1024 * 1024)
                        if not block:
                            break
                        written += len(block)
                        if written > MAX_EXPANDED:
                            raise UpdateError('Archive expanded beyond its limit')
                        output.write(block)
                os.chmod(target, 0o755 if relative == 'panel.sh' else 0o644)
                if target.suffix == '.py':
                    ast.parse(target.read_bytes(), filename=relative)
            if not all((destination / name).is_file() for name in REQUIRED):
                raise UpdateError('Archive is missing required application files')
            return {'files': sum(1 for p in destination.rglob('*') if p.is_file()), 'expanded_bytes': written}
    except (zipfile.BadZipFile, zipfile.LargeZipFile, OSError, RuntimeError, SyntaxError, ValueError) as exc:
        if isinstance(exc, UpdateError):
            raise
        raise UpdateError('Invalid update archive: ' + str(exc)[:200]) from exc


def health(port, timeout=2):
    try:
        # Ignore any proxy environment for a loopback readiness check.
        import urllib.request
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open('http://127.0.0.1:%d/api/health' % port, timeout=timeout) as response:
            return json.load(response).get('ok') is True
    except (OSError, ValueError):
        return False


def start_candidate(root, env, log):
    return subprocess.Popen([sys.executable, '-c', 'from prime.app import run; run()'],
                            cwd=str(root), env=env, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)


def stop_candidate(process):
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=12)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)


def boot_check(root, environment, log_path, seconds=30):
    """Check an uploaded panel against an empty, disposable data directory."""
    with tempfile.TemporaryDirectory(prefix='prime-update-check-') as scratch:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 0))
            port = probe.getsockname()[1]
        env = dict(environment)
        env.update(PRIME_HOST='127.0.0.1', PRIME_PORT=str(port), PRIME_DATA_DIR=scratch,
                   PRIME_CONFIG=str(Path(scratch) / 'config.json'))
        write_json(Path(scratch) / 'config.json', {'data_dir': scratch, 'db_path': str(Path(scratch) / 'panel.db'),
                                                   'log_path': str(Path(scratch) / 'panel.log')})
        with open(log_path, 'ab') as output:
            process = start_candidate(root, env, output)
            try:
                deadline = time.monotonic() + seconds
                while time.monotonic() < deadline and process.poll() is None:
                    if health(port):
                        return
                    time.sleep(.2)
                raise UpdateError('Uploaded panel failed its startup check with the installed Python dependencies')
            finally:
                stop_candidate(process)


class UpdateStore:
    def __init__(self, data_dir, app_dir=None):
        self.app = Path(app_dir or Path(__file__).resolve().parent.parent).resolve()
        self.root = Path(data_dir).resolve() / 'updates'
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.state_path = self.root / 'state.json'
        for item in APP_ITEMS:
            if self.root == self.app / item or self.app / item in self.root.parents:
                raise UpdateError('Move the panel data directory outside application files before updating')

    @contextmanager
    def lock(self):
        with (self.root / 'update.lock').open('a') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise UpdateError('Another update is already in progress') from exc
            try:
                yield
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    def status(self):
        try:
            data = json.loads(self.state_path.read_text())
        except (OSError, ValueError):
            data = {'phase': 'idle'}
        return {k: data[k] for k in ('id', 'phase', 'message', 'created_at', 'files', 'expanded_bytes', 'backup') if k in data}

    def stage(self, archive):
        with self.lock():
            if self.status()['phase'] in ('applying', 'restarting'):
                raise UpdateError('Wait for the current update to finish')
            ident = uuid.uuid4().hex
            stage = self.root / ('stage-' + ident)
            stage.mkdir(mode=0o700)
            try:
                info = validate_zip(archive, stage)
                boot_check(stage, os.environ, self.root / 'startup-check.log')
                previous = self.status().get('id')
                write_json(self.state_path, {**info, 'id': ident, 'phase': 'ready', 'created_at': time.time(),
                                             'message': 'Archive validated; startup check passed'})
                if previous and len(previous) == 32 and previous.isalnum():
                    shutil.rmtree(self.root / ('stage-' + previous), ignore_errors=True)
                return self.status()
            except Exception:
                shutil.rmtree(stage, ignore_errors=True)
                raise

    def prepare_restart(self, cfg):
        with self.lock():
            state = self.status()
            ident = state.get('id', '')
            if state['phase'] != 'ready' or not (self.root / ('stage-' + ident)).is_dir():
                raise UpdateError('Upload and validate an update first')
            if not os.access(self.app, os.W_OK):
                raise UpdateError('The application directory is not writable by the panel service')
            # A copy outside the application stays usable during replacement.
            runner = self.root / ('runner-' + ident + '.py')
            shutil.copyfile(__file__, runner)
            os.chmod(runner, 0o600)
            config = self.root / ('config-' + ident + '.json')
            write_json(config, cfg.public_dict(include_paths=True))
            control = self.root / ('control-' + ident + '.json')
            write_json(control, {'id': ident, 'app': str(self.app), 'root': str(self.root),
                                  'config': str(config), 'host': cfg.host, 'port': cfg.port,
                                  'data_dir': cfg.data_dir})
            state.update(phase='restarting', message='Restarting into the uploaded release')
            write_json(self.state_path, state)
            return str(runner), str(control)

    def install(self, ident):
        stage = self.root / ('stage-' + ident)
        backup = self.root / ('backup-' + ident)
        backup.mkdir(mode=0o700)
        journal = {'moved': [], 'installed': []}
        write_json(backup / 'journal.json', journal)
        try:
            for item in APP_ITEMS:
                incoming = stage / item
                current = self.app / item
                if not incoming.exists():
                    continue
                if current.is_symlink():
                    raise UpdateError('Application path cannot be a symbolic link: ' + item)
                if current.exists():
                    shutil.move(str(current), str(backup / item))
                    journal['moved'].append(item)
                    write_json(backup / 'journal.json', journal)
                shutil.move(str(incoming), str(current))
                journal['installed'].append(item)
                write_json(backup / 'journal.json', journal)
        except Exception:
            self.rollback(ident)
            raise
        return backup

    def rollback(self, ident):
        backup = self.root / ('backup-' + ident)
        journal = json.loads((backup / 'journal.json').read_text())
        for item in reversed(APP_ITEMS):
            target = self.app / item
            if item in journal['installed'] and target.exists():
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink()
            if item in journal['moved']:
                shutil.move(str(backup / item), str(target))
        write_json(backup / 'journal.json', {'moved': [], 'installed': [], 'restored': True})


def supervise(control_path):
    control = json.loads(Path(control_path).read_text())
    store = UpdateStore(control['data_dir'], control['app'])
    ident = control['id']
    process = None
    stopping = False

    def shutdown(_signum, _frame):
        nonlocal stopping
        stopping = True
        if process:
            stop_candidate(process)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    env = dict(os.environ)
    env.update(PRIME_CONFIG=control['config'], PRIME_DATA_DIR=control['data_dir'],
               PRIME_HOST=control['host'], PRIME_PORT=str(control['port']))
    with store.lock(), (store.root / ('restart-' + ident + '.log')).open('ab') as output:
        try:
            store.install(ident)
            process = start_candidate(store.app, env, output)
            deadline = time.monotonic() + 60
            ready = False
            while time.monotonic() < deadline and process.poll() is None and not stopping:
                if health(control['port']):
                    ready = True
                    break
                time.sleep(.3)
            if not ready:
                raise UpdateError('New release failed its readiness check')
            write_json(store.state_path, {'id': ident, 'phase': 'complete', 'backup': 'backup-' + ident,
                                          'message': 'Update started successfully; previous application files were backed up'})
        except Exception as exc:
            if process:
                stop_candidate(process)
            backup = store.root / ('backup-' + ident) / 'journal.json'
            if backup.exists():
                journal = json.loads(backup.read_text())
                if not journal.get('restored'):
                    store.rollback(ident)
            write_json(store.state_path, {'id': ident, 'phase': 'rolled_back',
                                          'message': 'Previous application restored: ' + str(exc)[:200]})
            if not stopping:
                process = start_candidate(store.app, env, output)
    # Retain the service PID and forward stop signals for systemd/nohup callers.
    if process:
        while process.poll() is None:
            time.sleep(.5)
        return process.returncode
    return 1


if __name__ == '__main__':
    raise SystemExit(supervise(sys.argv[1]))
