"""RFC 6238 TOTP with single-use steps and hashed recovery codes."""
import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote
from . import security

SCHEMA='''CREATE TABLE IF NOT EXISTS user_factors(user_id INTEGER PRIMARY KEY, secret TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, last_step INTEGER NOT NULL DEFAULT -1);
CREATE TABLE IF NOT EXISTS recovery_codes(user_id INTEGER NOT NULL, digest TEXT NOT NULL UNIQUE);'''

def totp(secret,step):
 key=base64.b32decode(secret,casefold=True)
 digest=hmac.new(key,struct.pack('>Q',step),hashlib.sha1).digest()
 offset=digest[-1]&15
 return str((struct.unpack('>I',digest[offset:offset+4])[0]&0x7fffffff)%1000000).zfill(6)

class Factors:
 def __init__(self,auth):
  self.auth,self.db,self.lock=auth,auth._conn,auth._lock
  with self.lock:self.db.executescript(SCHEMA);self.db.commit()
 def enabled(self,user_id):
  with self.lock:
   row=self.db.execute('SELECT enabled FROM user_factors WHERE user_id=?',(user_id,)).fetchone()
   return bool(row and row['enabled'])
 def begin(self,user):
  with self.lock,self.db:
   if self.enabled(user['id']):raise ValueError('Two-factor authentication is already enabled')
   secret=base64.b32encode(secrets.token_bytes(20)).decode()
   self.db.execute('INSERT OR REPLACE INTO user_factors(user_id,secret) VALUES (?,?)',(user['id'],secret))
  return {'secret':secret,'uri':'otpauth://totp/'+quote('Prime:'+user['username'],safe='')+'?secret='+secret+'&issuer=Prime&algorithm=SHA1&digits=6&period=30'}
 def _step(self,secret,code,last):
  now=int(time.time())//30
  for step in (now,now-1,now+1):
   if step>last and hmac.compare_digest(totp(secret,step),code):return step
  return None
 def confirm(self,user_id,code):
  with self.lock,self.db:
   row=self.db.execute('SELECT * FROM user_factors WHERE user_id=?',(user_id,)).fetchone()
   if not row or row['enabled']:raise ValueError('Start enrollment first')
   step=self._step(row['secret'],code,-1)
   if step is None:raise ValueError('Invalid authenticator code')
   codes=[secrets.token_hex(8) for _ in range(10)]
   self.db.execute('UPDATE user_factors SET enabled=1,last_step=? WHERE user_id=?',(step,user_id))
   self.db.execute('DELETE FROM recovery_codes WHERE user_id=?',(user_id,))
   self.db.executemany('INSERT INTO recovery_codes VALUES (?,?)',[(user_id,security.token_hash(c)) for c in codes])
   return codes
 def verify(self,user_id,code):
  with self.lock,self.db:
   row=self.db.execute('SELECT * FROM user_factors WHERE user_id=?',(user_id,)).fetchone()
   if not row or not row['enabled']:return True
   code=code.strip()
   if len(code)==16:
    cursor=self.db.execute('DELETE FROM recovery_codes WHERE user_id=? AND digest=?',(user_id,security.token_hash(code)))
    return cursor.rowcount==1
   if len(code)!=6 or not code.isascii() or not code.isdigit():return False
   step=self._step(row['secret'],code,row['last_step'])
   if step is None:return False
   self.db.execute('UPDATE user_factors SET last_step=? WHERE user_id=?',(step,user_id))
   return True
 def disable(self,user_id,code):
  if not self.verify(user_id,code):raise ValueError('Invalid or already used authenticator/recovery code')
  with self.lock,self.db:
   self.db.execute('DELETE FROM user_factors WHERE user_id=?',(user_id,))
   self.db.execute('DELETE FROM recovery_codes WHERE user_id=?',(user_id,))
