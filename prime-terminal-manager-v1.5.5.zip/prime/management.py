"""Persistent tenant delegation and billing; monetary values use integer cents."""
import json
import re
import time
import uuid
from . import security

SCHEMA = '''
CREATE TABLE IF NOT EXISTS invitations(token_hash TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS resource_grants(username TEXT NOT NULL, vm_id TEXT NOT NULL, permissions TEXT NOT NULL, PRIMARY KEY(username,vm_id));
CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY, name TEXT NOT NULL, cents INTEGER NOT NULL, currency TEXT NOT NULL, cpus INTEGER NOT NULL, memory INTEGER NOT NULL, disk INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS coupons(code TEXT PRIMARY KEY, kind TEXT NOT NULL, value INTEGER NOT NULL, max_uses INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0, expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, description TEXT NOT NULL, cents INTEGER NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, due REAL NOT NULL, paid REAL, coupon TEXT);
'''

class Management:
    def __init__(self, auth):
        self.auth, self.db, self.lock = auth, auth._conn, auth._lock
        with self.lock:
            self.db.executescript(SCHEMA)
            self.db.commit()

    def users(self):
        with self.lock:
            return [dict(r) for r in self.db.execute('SELECT id,username,is_admin,created_at FROM users ORDER BY id')]

    def invite(self, username, hours=24):
        # Same username constraints as AuthStore, with no credentials yet.
        if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,64}', username):
            raise ValueError('Use 1–64 letters, numbers, dots, underscores or dashes')
        if self.auth.get_user(username):
            raise ValueError('User already exists')
        with self.lock:
            if self.db.execute('SELECT 1 FROM invoices WHERE username=? LIMIT 1',(username,)).fetchone():
                raise ValueError('Username is reserved by historical invoices')
        token = security.new_token(32)
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO invitations VALUES (?,?,?)',
                            (security.token_hash(token), username, time.time()+hours*3600))
        return token

    def accept(self, token, password):
        problems = security.password_problems(password)
        if problems:
            raise ValueError(' '.join(problems))
        hashed = security.hash_password(password)
        now = time.time()
        with self.lock, self.db:
            row = self.db.execute('SELECT * FROM invitations WHERE token_hash=? AND expires>?',
                                  (security.token_hash(token), now)).fetchone()
            if not row:
                raise ValueError('Invitation is invalid or expired')
            self.db.execute('INSERT INTO users(username,password_hash,is_admin,created_at,updated_at,password_changed_at) VALUES (?,?,0,?,?,?)',
                            (row['username'], hashed, now, now, now))
            self.db.execute('DELETE FROM invitations WHERE token_hash=?', (security.token_hash(token),))
            return row['username']

    def delete_user(self, username):
        from .factors import Factors
        Factors(self.auth)
        with self.lock, self.db:
            user = self.auth.get_user(username)
            if not user or user['is_admin']:
                raise ValueError('Only tenant accounts can be deleted here')
            self.db.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
            self.db.execute('DELETE FROM user_factors WHERE user_id=?',(user['id'],))
            self.db.execute('DELETE FROM recovery_codes WHERE user_id=?',(user['id'],))
            self.db.execute('DELETE FROM resource_grants WHERE username=?', (username,))
            self.db.execute('DELETE FROM users WHERE id=?', (user['id'],))

    def grants(self, username=None):
        with self.lock:
            rows = self.db.execute('SELECT * FROM resource_grants' + (' WHERE username=?' if username else ''),
                                   (username,) if username else ()).fetchall()
            return [{**dict(r), 'permissions':json.loads(r['permissions'])} for r in rows]

    def grant(self, username, vm_id, permissions):
        user = self.auth.get_user(username)
        if not user or user['is_admin']:
            raise ValueError('Choose an existing tenant account')
        if not set(permissions) <= {'view','power','console'}:
            raise ValueError('Unknown permission')
        with self.lock, self.db:
            if not permissions:
                self.db.execute('DELETE FROM resource_grants WHERE username=? AND vm_id=?', (username,vm_id))
            else:
                self.db.execute('INSERT OR REPLACE INTO resource_grants VALUES (?,?,?)',
                                (username,vm_id,json.dumps(sorted(set(permissions)|{'view'}))))

    def allowed(self, session, vm_id, permission):
        if session.is_admin:
            return True
        return any(r['vm_id']==vm_id and permission in r['permissions'] for r in self.grants(session.username))

    def list(self, kind, username=None):
        if kind not in ('plans','coupons','invoices'):
            raise ValueError('Unknown billing collection')
        with self.lock:
            if kind == 'invoices' and username:
                rows = self.db.execute('SELECT * FROM invoices WHERE username=? ORDER BY id DESC LIMIT 500', (username,))
            else:
                rows = self.db.execute('SELECT * FROM '+kind+' LIMIT 500')
            return [dict(r) for r in rows]

    def plan(self, name, cents, currency, cpus, memory, disk, ident=None):
        ident = ident or uuid.uuid4().hex
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO plans VALUES (?,?,?,?,?,?,?,1)',
                            (ident,name,cents,currency,cpus,memory,disk))
        return ident

    def coupon(self, code, kind, value, max_uses, expires):
        code = code.upper()
        if not re.fullmatch(r'[A-Z0-9_-]{1,32}',code) or kind not in ('fixed','percentage'):
            raise ValueError('Invalid coupon')
        if kind == 'percentage' and value > 100:
            raise ValueError('Percentage must not exceed 100')
        with self.lock, self.db:
            self.db.execute('INSERT INTO coupons(code,kind,value,max_uses,expires) VALUES (?,?,?,?,?)',
                            (code,kind,value,max_uses,expires))
        return code

    def invoice(self, username, plan_id, due, coupon=''):
        if not self.auth.get_user(username):
            raise ValueError('User not found')
        with self.lock, self.db:
            plan = self.db.execute('SELECT * FROM plans WHERE id=? AND active=1',(plan_id,)).fetchone()
            if not plan:
                raise ValueError('Active plan not found')
            cents = plan['cents']
            if coupon:
                row = self.db.execute('SELECT * FROM coupons WHERE code=?',(coupon.upper(),)).fetchone()
                if not row or row['expires'] <= time.time() or row['used'] >= row['max_uses']:
                    raise ValueError('Coupon invalid, expired or exhausted')
                discount = (cents * row['value'] + 50)//100 if row['kind']=='percentage' else row['value']
                cents = max(0,cents-discount)
                self.db.execute('UPDATE coupons SET used=used+1 WHERE code=?',(row['code'],))
            cursor = self.db.execute('INSERT INTO invoices(username,description,cents,currency,status,created,due,coupon) VALUES (?,?,?,?,?,?,?,?)',
                                    (username,plan['name'],cents,plan['currency'],'pending',time.time(),due,coupon.upper()))
            return cursor.lastrowid

    def status(self, ident, status):
        if status not in ('pending','paid','cancelled'):
            raise ValueError('Invalid invoice status')
        with self.lock, self.db:
            cursor = self.db.execute('UPDATE invoices SET status=?,paid=? WHERE id=?',
                                    (status,time.time() if status=='paid' else None,ident))
            if not cursor.rowcount:
                raise ValueError('Invoice not found')

    def remove(self, kind, ident):
        with self.lock, self.db:
            if kind == 'plans':
                self.db.execute('UPDATE plans SET active=0 WHERE id=?',(ident,))
            elif kind == 'coupons':
                self.db.execute('DELETE FROM coupons WHERE code=?',(ident,))
            else:
                raise ValueError('Unknown collection')
