"""Per-account visibility of listening ports and processes.

Each panel account sees, and can signal, only what belongs to the OS user it is
mapped to. The mapping is stored in data/port_scope.json as {panel user: OS user}.

  * "*" means every port and process (administrator choice). The setup account
    (the first account created) is "*" by default, so an existing install keeps
    its view.
  * Any other account sees nothing until an administrator maps it.
  * Unmapped accounts cannot list, inspect or signal anything.

Limit: the panel usually runs as root, so processes started by root are all
owned by the root OS user. Two panel accounts that are both mapped to root share
root's processes. Give separate accounts separate OS users to isolate them.
"""
from __future__ import annotations

import json
import os
import pwd
import threading
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

ALL = "*"
_LOCK = threading.RLock()


class PortScopeError(ValueError):
    pass


class PortScope:
    def __init__(self, data_dir: str, primary: Optional[str]) -> None:
        self.path = Path(data_dir) / "port_scope.json"
        self.primary = primary

    def _load(self) -> Dict[str, str]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _save(self, data: Dict[str, str]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    def os_user_for(self, username: str) -> Optional[str]:
        """The OS user this panel account may see, '*' for everything, or None."""
        data = self._load()
        if username in data:
            return data[username]
        if username and username == self.primary:
            return ALL
        return None

    def mappings(self) -> Dict[str, str]:
        data = self._load()
        if self.primary and self.primary not in data:
            data[self.primary] = ALL
        return data

    def set_mapping(self, username: str, os_user: str) -> None:
        if not username:
            raise PortScopeError("panel account is required")
        if os_user != ALL:
            try:
                pwd.getpwnam(os_user)
            except KeyError as exc:
                raise PortScopeError(f"OS user '{os_user}' does not exist") from exc
        with _LOCK:
            data = self._load()
            data[username] = os_user
            self._save(data)

    def remove_mapping(self, username: str) -> None:
        with _LOCK:
            data = self._load()
            if username not in data:
                raise LookupError(username)
            del data[username]
            self._save(data)

    def visible(self, username: str, owner: Optional[str]) -> bool:
        mapped = self.os_user_for(username)
        if mapped is None:
            return False
        if mapped == ALL:
            return True
        return bool(owner) and owner == mapped

    def filter_items(self, username: str, items: Iterable[Dict[str, Any]], key: str = "user") -> List[Dict[str, Any]]:
        return [item for item in items if self.visible(username, item.get(key))]
