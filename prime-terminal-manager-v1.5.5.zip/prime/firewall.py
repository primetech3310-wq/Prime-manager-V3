"""Host firewall management with staged apply, confirmation and automatic rollback.

Rules are kept by the panel in a dedicated table so the panel never rewrites rules
it does not own:
  * nftables: table ``inet prime_fw`` with one input chain, if ``nft`` is present
  * iptables: chain ``PRIME-FW`` jumped to from INPUT, if only iptables is present

Changes are staged first. The admin has ``CONFIRM_SECONDS`` to confirm; otherwise
the previous committed state is restored. A pending change is also recovered after
a panel restart, so a bad rule set cannot survive a crash.
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

NFT_TABLE = "prime_fw"
IPT_CHAIN = "PRIME-FW"
CONFIRM_SECONDS = 90
MAX_RULES = 200
ACTIONS = ("accept", "drop", "reject")
PROTOCOLS = ("tcp", "udp", "any")
POLICIES = ("accept", "drop")
_COMMENT = re.compile(r"^[A-Za-z0-9 ._-]{0,64}$")
_PORT = re.compile(r"^(\d{1,5})(?:-(\d{1,5}))?$")


class FirewallError(ValueError):
    pass


def _port_range(text: str) -> tuple:
    m = _PORT.fullmatch(text.strip())
    if not m:
        raise FirewallError("Port must be a number (80) or a range (8000-8100)")
    lo = int(m.group(1))
    hi = int(m.group(2)) if m.group(2) else lo
    if not (1 <= lo <= 65535 and 1 <= hi <= 65535 and lo <= hi):
        raise FirewallError("Ports must be between 1 and 65535, and ranges must ascend")
    return lo, hi


def validate_rule(data: Dict[str, Any]) -> Dict[str, Any]:
    """Return a normalised rule, or raise FirewallError."""
    if not isinstance(data, dict):
        raise FirewallError("Rule must be an object")
    action = str(data.get("action", "accept")).lower()
    protocol = str(data.get("protocol", "tcp")).lower()
    if action not in ACTIONS:
        raise FirewallError("Action must be accept, drop or reject")
    if protocol not in PROTOCOLS:
        raise FirewallError("Protocol must be tcp, udp or any")
    port = str(data.get("port") or "").strip()
    if protocol == "any" and port:
        raise FirewallError("A port cannot be used with protocol 'any'")
    if protocol != "any":
        if not port:
            raise FirewallError("Choose a port for tcp or udp rules")
        _port_range(port)
    source = str(data.get("source") or "").strip()
    if source:
        try:
            net = ipaddress.ip_network(source, strict=False)
        except ValueError as exc:
            raise FirewallError("Source must be an IPv4 address or CIDR, for example 203.0.113.0/24") from exc
        if net.version != 4:
            raise FirewallError("Only IPv4 sources are supported")
        source = str(net)
    comment = str(data.get("comment") or "").strip()
    if not _COMMENT.fullmatch(comment):
        raise FirewallError("Comment may contain letters, digits, spaces, dots, dashes and underscores (64 max)")
    return {"id": str(data.get("id") or uuid.uuid4().hex[:12]), "action": action, "protocol": protocol,
            "port": port, "source": source, "comment": comment}


def _nft_rule(rule: Dict[str, Any]) -> str:
    parts = []
    if rule["source"]:
        parts.append(("ip saddr " if ":" not in rule["source"] else "ip6 saddr ") + rule["source"])
    if rule["protocol"] != "any":
        lo, hi = _port_range(rule["port"])
        span = f"{lo}-{hi}" if hi != lo else str(lo)
        parts.append(f"{rule['protocol']} dport {span}")
    parts.append(rule["action"])
    if rule["comment"]:
        parts.append(f'comment "{rule["comment"]}"')
    return " ".join(parts)


def _ipt_args(rule: Dict[str, Any]) -> List[str]:
    args: List[str] = []
    if rule["source"]:
        args += ["-s", rule["source"]]
    if rule["protocol"] != "any":
        lo, hi = _port_range(rule["port"])
        span = f"{lo}:{hi}" if hi != lo else str(lo)
        args += ["-p", rule["protocol"], "--dport", span]
    target = {"accept": "ACCEPT", "drop": "DROP", "reject": "REJECT"}[rule["action"]]
    args += ["-j", target]
    if rule["comment"]:
        args += ["-m", "comment", "--comment", rule["comment"]]
    return args


class FirewallManager:
    def __init__(self, data_dir: str, panel_port: int, ssh_ports=(22,)):
        self.dir = Path(data_dir).resolve() / "firewall"
        self.dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.committed_path = self.dir / "committed.json"
        self.pending_path = self.dir / "pending.json"
        self.panel_port = int(panel_port)
        self.ssh_ports = tuple(ssh_ports)
        self._lock = threading.RLock()
        self._timer: Optional[threading.Timer] = None

    # ----------------------------------------------------------- backend
    @staticmethod
    def backend() -> str:
        if shutil.which("nft"):
            return "nftables"
        if shutil.which("iptables"):
            return "iptables"
        return "none"

    @staticmethod
    def can_apply() -> bool:
        return os.geteuid() == 0 and FirewallManager.backend() != "none"

    def _run(self, args: List[str], stdin: Optional[str] = None, check: bool = True) -> subprocess.CompletedProcess:
        result = subprocess.run(args, input=stdin, capture_output=True, text=True, timeout=30)
        if check and result.returncode != 0:
            raise FirewallError((result.stderr or result.stdout).strip()[-400:] or f"{args[0]} failed")
        return result

    def _render_and_apply(self, state: Dict[str, Any]) -> None:
        backend = self.backend()
        rules = [validate_rule(r) for r in state["rules"]]
        if len(rules) > MAX_RULES:
            raise FirewallError(f"At most {MAX_RULES} rules are allowed")
        policy = state["policy"]
        if policy not in POLICIES:
            raise FirewallError("Default policy must be accept or drop")
        if backend == "nftables":
            self._apply_nft(rules, policy)
        elif backend == "iptables":
            self._apply_iptables(rules, policy)
        else:
            raise FirewallError("No nftables or iptables binary was found on this host")

    def _baseline(self) -> List[Dict[str, Any]]:
        """Rules that are always present so the panel and SSH stay reachable."""
        base = [{"id": "base-panel", "action": "accept", "protocol": "tcp", "port": str(self.panel_port),
                 "source": "", "comment": "panel access"}]
        for port in self.ssh_ports:
            base.append({"id": f"base-ssh-{port}", "action": "accept", "protocol": "tcp", "port": str(port),
                         "source": "", "comment": "ssh access"})
        return base

    def _apply_nft(self, rules: List[Dict[str, Any]], policy: str) -> None:
        body = []
        body.append("ct state established,related accept")
        body.append('iif "lo" accept')
        body.append("ip protocol icmp accept")
        for rule in self._baseline() + rules:
            body.append(_nft_rule(rule))
        hook_policy = "accept" if policy == "accept" else "drop"
        text = (
            f"add table inet {NFT_TABLE}\n"
            f"flush table inet {NFT_TABLE}\n"
            f"table inet {NFT_TABLE} {{\n"
            f"  chain input {{\n"
            f"    type filter hook input priority -10; policy {hook_policy};\n"
            + "".join(f"    {line}\n" for line in body)
            + "  }\n}\n"
        )
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".nft") as handle:
            handle.write(text)
            path = handle.name
        try:
            self._run(["nft", "-f", path])
        finally:
            os.unlink(path)

    def _apply_iptables(self, rules: List[Dict[str, Any]], policy: str) -> None:
        self._run(["iptables", "-N", IPT_CHAIN], check=False)
        self._run(["iptables", "-F", IPT_CHAIN])
        if self._run(["iptables", "-C", "INPUT", "-j", IPT_CHAIN], check=False).returncode != 0:
            self._run(["iptables", "-I", "INPUT", "1", "-j", IPT_CHAIN])
        self._run(["iptables", "-A", IPT_CHAIN, "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED", "-j", "ACCEPT"])
        self._run(["iptables", "-A", IPT_CHAIN, "-i", "lo", "-j", "ACCEPT"])
        self._run(["iptables", "-A", IPT_CHAIN, "-p", "icmp", "-j", "ACCEPT"])
        for rule in self._baseline() + rules:
            self._run(["iptables", "-A", IPT_CHAIN] + _ipt_args(rule))
        self._run(["iptables", "-A", IPT_CHAIN, "-j", "RETURN" if policy == "accept" else "DROP"])

    def _clear(self) -> None:
        """Remove every rule the panel owns (used when nothing is committed)."""
        backend = self.backend()
        if backend == "nftables":
            self._run(["nft", "delete", "table", "inet", NFT_TABLE], check=False)
        elif backend == "iptables":
            self._run(["iptables", "-D", "INPUT", "-j", IPT_CHAIN], check=False)
            self._run(["iptables", "-F", IPT_CHAIN], check=False)
            self._run(["iptables", "-X", IPT_CHAIN], check=False)

    def _apply_state(self, state: Dict[str, Any]) -> None:
        if not state["rules"] and state["policy"] == "accept":
            self._clear()
            return
        self._render_and_apply(state)

    # ------------------------------------------------------------- state
    def _read(self, path: Path) -> Optional[Dict[str, Any]]:
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def _write(self, path: Path, data: Dict[str, Any]) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)

    def committed(self) -> Dict[str, Any]:
        return self._read(self.committed_path) or {"policy": "accept", "rules": []}

    def pending(self) -> Optional[Dict[str, Any]]:
        return self._read(self.pending_path)

    def status(self) -> Dict[str, Any]:
        pending = self.pending()
        return {
            "backend": self.backend(),
            "can_apply": self.can_apply(),
            "committed": self.committed(),
            "pending": ({"token": pending["token"], "deadline": pending["deadline"],
                         "staged": pending["staged"]} if pending else None),
            "baseline": self._baseline(),
            "confirm_seconds": CONFIRM_SECONDS,
            "note": ("Only IPv4 rules are managed. UFW or other firewall tools can still apply their own rules."
                     if self.backend() != "none" else "No nftables or iptables binary is installed."),
        }

    # ----------------------------------------------------------- actions
    def stage(self, rules: List[Dict[str, Any]], policy: str) -> Dict[str, Any]:
        """Apply a new rule set now, but keep the previous state for rollback."""
        with self._lock:
            if not self.can_apply():
                raise FirewallError("Firewall changes need root and nftables or iptables on this host")
            if self.pending():
                raise FirewallError("A firewall change is already waiting for confirmation")
            if policy not in POLICIES:
                raise FirewallError("Default policy must be accept or drop")
            staged = {"policy": policy, "rules": [validate_rule(r) for r in rules]}
            if len(staged["rules"]) > MAX_RULES:
                raise FirewallError(f"At most {MAX_RULES} rules are allowed")
            snapshot = self.committed()
            try:
                self._apply_state(staged)
            except FirewallError:
                # A partially applied rule set must not survive a failed stage.
                try:
                    self._apply_state(snapshot)
                except FirewallError:
                    pass
                raise
            token = uuid.uuid4().hex
            pending = {"token": token, "deadline": time.time() + CONFIRM_SECONDS,
                       "staged": staged, "snapshot": snapshot}
            self._write(self.pending_path, pending)
            self._schedule(CONFIRM_SECONDS)
            return {"token": token, "deadline": pending["deadline"], "confirm_seconds": CONFIRM_SECONDS}

    def confirm(self, token: str) -> Dict[str, Any]:
        with self._lock:
            pending = self.pending()
            if not pending or pending["token"] != token:
                raise FirewallError("Nothing is waiting for this confirmation (it may have rolled back)")
            if time.time() > pending["deadline"]:
                self._rollback(pending)
                raise FirewallError("The confirmation window expired and the previous rules were restored")
            self._write(self.committed_path, pending["staged"])
            self.pending_path.unlink(missing_ok=True)
            self._cancel_timer()
            return {"ok": True, "committed": pending["staged"]}

    def cancel(self, token: str) -> Dict[str, Any]:
        with self._lock:
            pending = self.pending()
            if not pending or pending["token"] != token:
                raise FirewallError("Nothing is waiting for this confirmation")
            self._rollback(pending)
            return {"ok": True, "restored": True}

    def _rollback(self, pending: Dict[str, Any]) -> None:
        self._cancel_timer()
        try:
            self._apply_state(pending["snapshot"])
        finally:
            self.pending_path.unlink(missing_ok=True)

    def expire_if_due(self) -> bool:
        """Called periodically and at startup; restores rules when a confirmation is overdue."""
        with self._lock:
            pending = self.pending()
            if pending and time.time() > pending["deadline"]:
                try:
                    self._rollback(pending)
                except FirewallError:
                    return False
                return True
            return False

    def recover(self) -> None:
        """Startup: roll back overdue changes, or re-arm the timer for live ones."""
        with self._lock:
            pending = self.pending()
            if not pending:
                return
            if time.time() > pending["deadline"]:
                try:
                    self._rollback(pending)
                except FirewallError:
                    pass
            else:
                self._schedule(pending["deadline"] - time.time())

    def _schedule(self, seconds: float) -> None:
        self._cancel_timer()

        def fire() -> None:
            self.expire_if_due()

        self._timer = threading.Timer(max(1.0, seconds) + 1.0, fire)
        self._timer.daemon = True
        self._timer.start()

    def _cancel_timer(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def live_rules(self) -> Dict[str, Any]:
        """Read back what the kernel is actually enforcing (for display only)."""
        backend = self.backend()
        try:
            if backend == "nftables":
                out = self._run(["nft", "list", "table", "inet", NFT_TABLE], check=False)
            elif backend == "iptables":
                out = self._run(["iptables", "-S", IPT_CHAIN], check=False)
            else:
                return {"text": "", "error": "no firewall tool"}
            return {"text": out.stdout.strip() or out.stderr.strip()[:2000], "error": ""}
        except (OSError, subprocess.SubprocessError, FirewallError) as exc:
            return {"text": "", "error": str(exc)}
