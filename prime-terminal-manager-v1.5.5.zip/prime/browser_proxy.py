"""Server-side page proxy behind the panel's embedded browser.

Most websites refuse to be displayed inside another page (X-Frame-Options,
frame-ancestors). The panel fetches the page itself, drops those headers and
serves it back in a *sandboxed* frame:

* the response carries ``Content-Security-Policy: sandbox allow-scripts ...``
  without ``allow-same-origin``, so the page runs in an opaque origin and can
  never read the panel's cookies, storage or API;
* the server never forwards the panel's cookies, and only http(s) is allowed;
* link clicks, form GETs and ``window.open`` are routed back through the proxy
  by a small bridge script, so browsing stays inside the panel.

Limitations (shown in the UI): the proxy has no cookie jar, so sites that need
a login inside the page won't keep it, and script-heavy single-page apps may
not work fully. "Open in new tab" always reaches the real site.

Standard library only. Python 3.8 compatible.
"""
from __future__ import annotations

import gzip
import html as html_lib
import re
import zlib
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Dict, Optional

MAX_BYTES = 12 * 1024 * 1024
TIMEOUT_SECONDS = 20
MAX_URL_LENGTH = 2048
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/124.0 Safari/537.36")
SEARCH_URL = "https://duckduckgo.com/html/?q="

_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://")
_HOSTLIKE_RE = re.compile(r"^(localhost|\d{1,3}(\.\d{1,3}){3}|[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+)(:\d{1,5})?([/?#].*)?$")
_META_STRIP_RE = re.compile(
    r"<meta\b[^>]*(?:http-equiv\s*=\s*[\"']?(?:content-security-policy|refresh|x-frame-options)"
    r"|charset\s*=)[^>]*>", re.IGNORECASE)
_BASE_RE = re.compile(r"<base\b[^>]*>", re.IGNORECASE)
_HEAD_RE = re.compile(r"<head\b[^>]*>", re.IGNORECASE)
_HTML_RE = re.compile(r"<html\b[^>]*>", re.IGNORECASE)
_CHARSET_RE = re.compile(rb"<meta[^>]+charset\s*=\s*[\"']?\s*([A-Za-z0-9_.:-]+)", re.IGNORECASE)


class BrowserError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


@dataclass
class FetchResult:
    status: int
    final_url: str
    content_type: str
    charset: Optional[str]
    body: bytes

    @property
    def is_html(self) -> bool:
        return self.content_type in ("text/html", "application/xhtml+xml")


def normalize_url(raw: str) -> str:
    """Turn what the user typed into an absolute http(s) URL.

    Plain words become a web search, host-like input gets a scheme.
    """
    text = (raw or "").strip()
    if not text:
        raise BrowserError(400, "Type an address or a search.")
    if len(text) > MAX_URL_LENGTH:
        raise BrowserError(400, "That address is too long.")
    if _SCHEME_RE.match(text):
        candidate = text
    elif _HOSTLIKE_RE.match(text) and " " not in text:
        local = text.startswith(("localhost", "127.", "0.0.0.0"))
        candidate = ("http://" if local else "https://") + text
    else:
        return SEARCH_URL + urllib.parse.quote_plus(text)
    parts = urllib.parse.urlsplit(candidate)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise BrowserError(400, "Only web addresses (http or https) can be opened.")
    return candidate


def fetch(url: str) -> FetchResult:
    """Download a page with no cookies and no panel credentials attached."""
    request = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    context = ssl.create_default_context()
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=context))
    try:
        response = opener.open(request, timeout=TIMEOUT_SECONDS)
        status = response.status
    except urllib.error.HTTPError as exc:  # the site answered with an error page
        response = exc
        status = exc.code
    except (urllib.error.URLError, OSError, ValueError) as exc:
        reason = getattr(exc, "reason", exc)
        raise BrowserError(502, f"The site could not be reached ({reason}).")
    try:
        body = response.read(MAX_BYTES + 1)
        final_url = response.geturl() or url
        raw_type = response.headers.get("Content-Type", "") or ""
        encoding = (response.headers.get("Content-Encoding", "") or "").lower().strip()
    finally:
        response.close()
    body = _decode_body(body, encoding)
    if len(body) > MAX_BYTES:
        raise BrowserError(413, "This page is too large to show in the panel.")
    content_type = raw_type.split(";")[0].strip().lower() or "application/octet-stream"
    charset = None
    if "charset=" in raw_type.lower():
        charset = raw_type.lower().split("charset=", 1)[1].split(";")[0].strip().strip("\"'")
    return FetchResult(status=status, final_url=final_url, content_type=content_type,
                       charset=charset, body=body)


def _decode_body(body: bytes, encoding: str) -> bytes:
    """Some servers compress even when not asked; undo it so the page can be read."""
    try:
        if encoding == "gzip":
            return gzip.decompress(body)
        if encoding == "deflate":
            try:
                return zlib.decompress(body)
            except zlib.error:
                return zlib.decompress(body, -zlib.MAX_WBITS)
    except (OSError, zlib.error, EOFError):
        return body
    return body


def decode_html(body: bytes, header_charset: Optional[str]) -> str:
    candidates = []
    if header_charset:
        candidates.append(header_charset)
    sniff = _CHARSET_RE.search(body[:4096])
    if sniff:
        candidates.append(sniff.group(1).decode("ascii", "ignore"))
    candidates.append("utf-8")
    for name in candidates:
        try:
            return body.decode(name)
        except (LookupError, UnicodeDecodeError):
            continue
    return body.decode("utf-8", "replace")


# Runs inside the proxied page. It only talks to its parent (the panel) with
# plain messages; the panel checks that each message comes from its own frame.
BRIDGE_SCRIPT = r"""
(function () {
  if (window.__primeBridge) return;
  window.__primeBridge = true;
  function send(payload) {
    payload.source = "prime-browser";
    try { parent.postMessage(payload, "*"); } catch (e) { /* no parent */ }
  }
  function web(url) { return /^https?:/i.test(url); }
  document.addEventListener("click", function (event) {
    if (event.defaultPrevented || event.button !== 0) return;
    var node = event.target && event.target.closest ? event.target.closest("a[href],area[href]") : null;
    if (!node || node.hasAttribute("download")) return;
    var href = node.href;
    if (!web(href)) return;
    event.preventDefault();
    send({ type: "nav", url: href });
  }, true);
  document.addEventListener("submit", function (event) {
    var form = event.target;
    if (!form || (form.method || "get").toLowerCase() !== "get") return;
    event.preventDefault();
    var target = new URL(form.action || document.baseURI);
    target.search = "";
    new FormData(form).forEach(function (value, key) {
      if (typeof value === "string") target.searchParams.append(key, value);
    });
    send({ type: "nav", url: target.href });
  }, true);
  window.open = function (url) {
    if (url) send({ type: "nav", url: new URL(String(url), document.baseURI).href });
    return null;
  };
  function reportTitle() { send({ type: "title", title: document.title || "" }); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", reportTitle);
  else reportTitle();
  window.addEventListener("load", reportTitle);
})();
"""


def rewrite_html(text: str, base_url: str) -> str:
    """Make a page display inside the panel: base URL, bridge script, no frame-busting."""
    text = _META_STRIP_RE.sub("", text)
    text = _BASE_RE.sub("", text)
    head_open = (
        '<meta charset="utf-8">'
        f'<base href="{html_lib.escape(base_url, quote=True)}">'
        f"<script>{BRIDGE_SCRIPT}</script>"
    )
    if _HEAD_RE.search(text):
        return _HEAD_RE.sub(lambda m: m.group(0) + head_open, text, count=1)
    if _HTML_RE.search(text):
        return _HTML_RE.sub(lambda m: m.group(0) + "<head>" + head_open + "</head>", text, count=1)
    return "<!doctype html><html><head>" + head_open + "</head><body>" + text + "</body></html>"


def security_headers() -> Dict[str, str]:
    """Headers for every proxied response; the page must stay sandboxed and frameable only by the panel."""
    return {
        "Content-Security-Policy": ("sandbox allow-scripts allow-forms allow-popups; "
                                    "frame-ancestors 'self'"),
        "X-Frame-Options": "SAMEORIGIN",
        "Referrer-Policy": "no-referrer",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "no-store",
    }


def error_page(title: str, message: str, url: str) -> str:
    safe_title = html_lib.escape(title)
    safe_message = html_lib.escape(message)
    safe_url = html_lib.escape(url[:MAX_URL_LENGTH], quote=True)
    if url.lower().startswith(("http://", "https://")):
        action = (f'<p><a href="{safe_url}" target="_blank" rel="noopener noreferrer">'
                  "Open in a new tab</a></p>")
    else:
        action = ""
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{safe_title}</title>
<style>
  html,body{{margin:0;height:100%;background:#0b0d12;color:#e9edf5;
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}}
  .box{{min-height:100%;display:grid;place-items:center;padding:24px;box-sizing:border-box}}
  .card{{max-width:460px;padding:28px;border-radius:24px;background:rgba(255,255,255,.07);
    border:1px solid rgba(255,255,255,.14);box-shadow:inset 0 1px 0 rgba(255,255,255,.18)}}
  h1{{font-size:20px;margin:0 0 8px;letter-spacing:-.01em}}
  p{{margin:0 0 16px;color:#aab3c4;word-break:break-word}}
  a{{display:inline-block;padding:10px 16px;border-radius:14px;background:#0a84ff;color:#fff;
    text-decoration:none;font-weight:600}}
  code{{font-size:12px;color:#7d8799;word-break:break-all}}
</style></head>
<body><div class="box"><div class="card">
  <h1>{safe_title}</h1>
  <p>{safe_message}</p>
  {action}
  <code>{safe_url}</code>
</div></div></body></html>"""
