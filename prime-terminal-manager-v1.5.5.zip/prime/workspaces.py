"""Docker workspaces with separate PID, filesystem and network namespaces.

Requires a local rootful Docker daemon and permission to install host firewall
rules. Failure to establish the network boundary aborts provisioning. KVM is
not used. This service never mounts host source, data, or Docker sockets into a
workspace. The supervisor is a trusted host administrator component.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import platform
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

from .updater import write_json

_LOCK = threading.RLock()
_ID = re.compile(r'^[0-9a-f]{32}$')
_ALIAS = re.compile(r'^[a-z][a-z0-9-]{2,31}$')
TUNNEL = re.compile(r'https://[a-z0-9-]+\.trycloudflare\.com')
SSHX = re.compile(r'https://sshx\.io/s/[A-Za-z0-9_/#-]+')
IMAGE = 'prime-workspace:local-v1'
# Includes host loopback, metadata endpoints, multicast, CGNAT and private LANs.
DENY_NETS = ('0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8',
             '169.254.0.0/16', '172.16.0.0/12', '192.0.0.0/24', '192.0.2.0/24',
             '192.168.0.0/16', '198.18.0.0/15', '198.51.100.0/24', '203.0.113.0/24',
             '224.0.0.0/4', '240.0.0.0/4')


class WorkspaceError(ValueError):
    pass


def privileged():
    if os.geteuid() == 0:
        return []
    if shutil.which('sudo'):
        result = subprocess.run(['sudo', '-n', 'true'], capture_output=True, timeout=5)
        if result.returncode == 0:
            return ['sudo', '-n']
    raise WorkspaceError('Workspace provisioning requires local Docker and permission to manage host firewall rules')


def command(args, timeout=30, input=None, check=True):
    try:
        result = subprocess.run(args, input=input, capture_output=True, timeout=timeout)
        if check and result.returncode:
            # Never expose arguments or provider logs, which can contain tokens.
            raise WorkspaceError('Workspace runtime command failed: ' + args[len(privileged())])
        return result
    except (OSError, subprocess.SubprocessError) as exc:
        raise WorkspaceError('Workspace runtime is unavailable or timed out') from exc


def docker(*args, **kwargs):
    return command(privileged() + ['docker', '--host', 'unix:///var/run/docker.sock', *args], **kwargs)


def iptables(*args, check=True):
    return command(privileged() + ['iptables', '--wait', '5', *args], check=check)


def public_specs():
    from . import sysinfo
    return {'cpu_cores': os.cpu_count(), 'architecture': platform.machine(),
            'memory_bytes': sysinfo.memory_info().get('total'),
            'storage_bytes': shutil.disk_usage('/').total, 'recorded_at': time.time()}


class WorkspaceStore:
    def __init__(self, data_dir):
        self.root = Path(data_dir).resolve() / 'workspaces'
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.owner = hashlib.sha256(str(self.root).encode()).hexdigest()[:16]
        self.settings_path = self.root / 'settings.json'

    def _path(self, ident):
        if not isinstance(ident, str) or not _ID.fullmatch(ident):
            raise WorkspaceError('Invalid workspace ID')
        return self.root / (ident + '.json')

    def read(self, ident):
        try:
            record = json.loads(self._path(ident).read_text())
            if record.get('id') != ident:
                raise ValueError('invalid record')
            return record
        except (OSError, ValueError) as exc:
            raise WorkspaceError('Workspace not found') from exc

    def settings(self):
        defaults = {'alias': 'primeterminal', 'ttl': 3600, 'max_workspaces': 10, 'memory_mb': 1024, 'cpus': 1,
                    'resource_mode': 'limited', 'keys': []}
        try:
            defaults.update(json.loads(self.settings_path.read_text()))
        except (OSError, ValueError):
            pass
        return defaults

    def save_settings(self, values):
        with _LOCK:
            settings = self.settings()
            alias = values.get('alias', settings['alias'])
            if not isinstance(alias, str) or not _ALIAS.fullmatch(alias) or alias in ('sshx', 'ttyd'):
                raise WorkspaceError('API name must use 3–32 lowercase letters, digits or dashes')
            settings['alias'] = alias
            mode = values.get('resource_mode', settings['resource_mode'])
            if mode not in ('limited', 'shared'):
                raise WorkspaceError('Resource mode must be limited or shared')
            settings['resource_mode'] = mode
            for key, low, high in [('ttl', 60, 86400), ('max_workspaces', 1, 100), ('memory_mb', 256, 65536), ('cpus', 1, 64)]:
                value = values.get(key, settings[key])
                if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                    raise WorkspaceError('Invalid workspace setting: ' + key)
                settings[key] = value
            write_json(self.settings_path, settings)
            return self.public_settings()

    def public_settings(self):
        settings = self.settings()
        return {**settings, 'keys': [{k: value[k] for k in ('id', 'name', 'created_at')} for value in settings['keys']]}

    def create_key(self, name):
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 64:
            raise WorkspaceError('API key name must be between 1 and 64 characters')
        with _LOCK:
            settings = self.settings()
            if len(settings['keys']) >= 50:
                raise WorkspaceError('Revoke an old API key before creating another')
            token = 'prime_' + secrets.token_urlsafe(32)
            record = {'id': secrets.token_hex(8), 'name': name.strip(), 'created_at': time.time(),
                      'hash': hashlib.sha256(token.encode()).hexdigest()}
            settings['keys'].append(record)
            write_json(self.settings_path, settings)
            return {'id': record['id'], 'key': token}

    def revoke_key(self, ident):
        with _LOCK:
            settings = self.settings()
            settings['keys'] = [key for key in settings['keys'] if key['id'] != ident]
            write_json(self.settings_path, settings)

    def authenticate_key(self, token):
        if not token or len(token) > 256:
            return False
        hashed = hashlib.sha256(token.encode()).hexdigest()
        return any(secrets.compare_digest(hashed, key['hash']) for key in self.settings()['keys'])

    def capabilities(self):
        result = {'available': False, 'image_ready': False, 'runtime_ready': False, 'kvm_required': False}
        try:
            docker('info', '--format', '{{.ServerVersion}}', timeout=10)
            iptables('-S', 'INPUT')
            result['available'] = platform.machine() == 'x86_64'
            result['image_ready'] = docker('image', 'inspect', IMAGE, check=False).returncode == 0
            result['message'] = 'Containers use separate filesystems, processes and filtered networks. KVM is not needed.'
            if result['image_ready']:
                probe = docker('run', '--rm', '--network', 'none', '--user', '1000:1000',
                               '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true', '--read-only',
                               *self.resource_args(self.settings()), '--entrypoint', 'python', IMAGE,
                               '-c', 'print("runtime_ready")', check=False)
                result['runtime_ready'] = probe.returncode == 0
                if not result['runtime_ready']:
                    result['message'] = ('The host rejected this resource mode. Limited mode requires delegated CPU, memory and PID cgroups. '
                                         'Shared mode uses the host resource pool and cannot prevent resource exhaustion.')
        except WorkspaceError as exc:
            result['message'] = str(exc)
        return result

    @staticmethod
    def resource_args(settings):
        if settings.get('resource_mode') == 'shared':
            return []
        return ['--pids-limit', '256', '--memory', str(settings['memory_mb']) + 'm', '--cpus', str(settings['cpus'])]

    def build(self):
        if platform.machine() != 'x86_64':
            raise WorkspaceError('The bundled workspace image currently supports x86_64 hosts')
        source = Path(__file__).resolve().parent.parent
        # A bounded context outside encrypted checkouts works with both Docker
        # builders. Unrelated local files and credentials cannot enter it.
        with tempfile.TemporaryDirectory(prefix='prime-runtime-build-', dir='/var/tmp') as context:
            context = Path(context)
            for directory in ('prime', 'workspace-runtime'):
                shutil.copytree(source / directory, context / directory,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            shutil.copyfile(source / 'run.py', context / 'run.py')
            ca_bundle = Path('/etc/ssl/certs/ca-certificates.crt')
            if not ca_bundle.is_file():
                raise WorkspaceError('Install the host CA certificate bundle before building workspaces')
            shutil.copyfile(ca_bundle, context / 'host-ca.crt')
            result = subprocess.run(privileged() + ['docker', '--host', 'unix:///var/run/docker.sock', 'build',
                                    '--tag', IMAGE, '--file', str(context / 'workspace-runtime/Dockerfile'), str(context)],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1200)
        with (self.root / 'image-build.log').open('wb') as output:
            os.chmod(output.name, 0o600)
            output.write(result.stdout[-128000:])
        if result.returncode:
            raise WorkspaceError('Workspace image build failed; inspect workspaces/image-build.log on the host')
        return self.capabilities()

    def _container(self, record):
        name = 'prime-ws-' + record['id']
        result = docker('inspect', name, check=False)
        if result.returncode:
            raise WorkspaceError('Workspace container is not running')
        value = json.loads(result.stdout)[0]
        labels = value['Config'].get('Labels') or {}
        if labels.get('prime.workspace') != record['id'] or labels.get('prime.owner') != self.owner:
            raise WorkspaceError('Container ownership does not match this panel')
        return value

    def _policy(self, record, remove=False):
        bridge = record['bridge']
        chain = 'PW' + record['id'][:12]
        incoming = ['-i', bridge, '-m', 'conntrack', '--ctstate', 'ESTABLISHED,RELATED', '-j', 'ACCEPT']
        drop = ['-i', bridge, '-j', 'DROP']
        outgoing = ['-i', bridge, '-j', chain]
        inbound = ['-o', bridge, '-m', 'conntrack', '--ctstate', 'NEW', '-j', 'DROP']
        if remove:
            for table, rule in [('INPUT', incoming), ('INPUT', drop), ('FORWARD', outgoing), ('FORWARD', inbound)]:
                iptables('-D', table, *rule, check=False)
            iptables('-F', chain, check=False)
            iptables('-X', chain, check=False)
            return
        iptables('-N', chain)
        for network in record['blocked_networks']:
            iptables('-A', chain, '-d', network, '-j', 'DROP')
        iptables('-A', chain, '-j', 'RETURN')
        # These jumps precede Docker's own ACCEPT rules.
        iptables('-I', 'INPUT', '1', *drop)
        iptables('-I', 'INPUT', '1', *incoming)
        iptables('-I', 'FORWARD', '1', *outgoing)
        iptables('-I', 'FORWARD', '1', *inbound)
        self.verify_policy(record)

    def verify_policy(self, record):
        bridge = record['bridge']
        chain = 'PW' + record['id'][:12]
        rules = [('INPUT', ['-i', bridge, '-j', 'DROP']),
                 ('FORWARD', ['-i', bridge, '-j', chain]),
                 ('FORWARD', ['-o', bridge, '-m', 'conntrack', '--ctstate', 'NEW', '-j', 'DROP'])]
        rules += [(chain, ['-d', network, '-j', 'DROP']) for network in record['blocked_networks']]
        for table, rule in rules:
            if iptables('-C', table, *rule, check=False).returncode:
                docker('stop', '--time', '2', 'prime-ws-' + record['id'], check=False)
                raise WorkspaceError('Workspace stopped because its network isolation policy is missing')

    def _host_ips(self):
        result = command(['ip', '-j', '-4', 'address'])
        return [item['local'] + '/32' for iface in json.loads(result.stdout) for item in iface.get('addr_info', [])]

    def _probe_host(self, record):
        # Bind a real canary on the host. Before releasing access, prove that
        # the workspace cannot initiate a connection through its bridge gateway.
        with socket.socket() as listener:
            listener.bind(('0.0.0.0', 0))
            listener.listen(4)
            port = listener.getsockname()[1]
            code = ('import socket,sys\n'
                    's=socket.socket();s.settimeout(1)\n'
                    'try:\n s.connect((sys.argv[1],int(sys.argv[2])))\nexcept OSError:\n sys.exit(0)\n'
                    'sys.exit(7)')
            result = docker('exec', 'prime-ws-' + record['id'], 'python', '-c', code,
                            record['gateway'], str(port), check=False)
            if result.returncode != 0:
                raise WorkspaceError('Host isolation probe ' + ('detected host access' if result.returncode == 7 else 'could not run') + '; workspace was not released')

    def create(self, kind, public_url, parent_origin=''):
        with _LOCK:
            self.sweep()
            settings = self.settings()
            if kind.lower() == settings['alias']:
                kind = 'panel'
            else:
                kind = kind.lower()
            if kind not in ('sshx', 'panel', 'ttyd'):
                raise WorkspaceError('Unknown workspace API')
            if len(self.list()) >= settings['max_workspaces']:
                raise WorkspaceError('Workspace capacity reached; stop or delete an existing workspace')
            capability = self.capabilities()
            if not capability['image_ready']:
                raise WorkspaceError('Build the workspace runtime from the admin page first')
            if not capability['runtime_ready']:
                raise WorkspaceError(capability['message'])
            ident = secrets.token_hex(16)
            access = 'P1' + secrets.token_urlsafe(32)
            name = 'prime-ws-' + ident
            network = 'prime-net-' + ident
            volume = 'prime-data-' + ident
            bridge = 'pw' + ident[:11]
            record = {'id': ident, 'kind': kind, 'created_at': time.time(), 'expires_at': time.time() + settings['ttl'],
                      'access_hash': hashlib.sha256(access.encode()).hexdigest(), 'bridge': bridge,
                      'network': network, 'volume': volume, 'state': 'preparing', 'provider_url': '',
                      'blocked_networks': list(DENY_NETS) + self._host_ips(),
                      'memory_mb': settings['memory_mb'], 'cpus': settings['cpus'], 'resource_mode': settings['resource_mode']}
            write_json(self._path(ident), record)
            try:
                docker('network', 'create', '--driver', 'bridge', '--label', 'prime.owner=' + self.owner,
                       '--label', 'prime.workspace=' + ident, '--opt', 'com.docker.network.bridge.name=' + bridge, network)
                info = json.loads(docker('network', 'inspect', network).stdout)[0]
                if info.get('EnableIPv6'):
                    raise WorkspaceError('Workspace networks must have IPv6 disabled')
                record['gateway'] = info['IPAM']['Config'][0]['Gateway']
                write_json(self._path(ident), record)
                self._policy(record)
                docker('volume', 'create', '--label', 'prime.owner=' + self.owner, '--label', 'prime.workspace=' + ident, volume)
                # No host binds, capabilities, root UID, shared namespaces,
                # device access, Docker socket, or published host ports.
                docker('run', '-d', '--name', name, '--hostname', 'workspace', '--network', network,
                       '--label', 'prime.owner=' + self.owner, '--label', 'prime.workspace=' + ident,
                       '--user', '1000:1000', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
                       '--read-only', *self.resource_args(settings), '--restart', 'no',
                       '--cgroupns', 'private', '--ipc', 'private',
                       '--sysctl', 'net.ipv6.conf.all.disable_ipv6=1',
                       '--sysctl', 'net.ipv6.conf.default.disable_ipv6=1',
                       '--log-driver', 'local', '--log-opt', 'max-size=10m', '--log-opt', 'max-file=2',
                       '--tmpfs', '/tmp:rw,noexec,nosuid,size=128m',
                       '--mount', 'type=volume,source=' + volume + ',target=/workspace',
                       '--env', 'PRIME_WORKSPACE_KIND=' + kind, '--env', 'PRIME_WORKSPACE_ACCESS=' + access,
                       '--env', 'PRIME_WORKSPACE_EXPIRES=' + str(record['expires_at']),
                       '--env', 'PRIME_WORKSPACE_PARENT=' + parent_origin,
                       '--env', 'PRIME_HOST_SPECS=' + json.dumps({**public_specs(),
                                 'resource_mode': settings['resource_mode'], 'memory_limit_mb': settings['memory_mb'],
                                 'cpu_limit': settings['cpus']}, separators=(',', ':')), IMAGE)
                self._probe_host(record)
                deadline = time.monotonic() + 90
                while time.monotonic() < deadline:
                    info = self._container(record)
                    if not info['State']['Running']:
                        raise WorkspaceError('Workspace exited before its terminal connection was ready')
                    logs = docker('exec', name, 'tail', '-c', '65536', '/workspace/.prime/provider.log', check=False).stdout.decode(errors='replace')
                    matches = (SSHX if kind == 'sshx' else TUNNEL).findall(logs)
                    if matches:
                        record.update(state='running', provider_url=matches[-1])
                        write_json(self._path(ident), record)
                        self.verify_policy(record)
                        if kind == 'panel':
                            link = public_url.rstrip('/') + '/' + ident + '#' + access
                        elif kind == 'ttyd':
                            link = record['provider_url'] + '/' + access + '/'
                        else:
                            link = record['provider_url']
                        return {'id': ident, 'url': link, 'expires_at': record['expires_at'], 'kind': kind,
                                'memory_mb': settings['memory_mb'], 'cpus': settings['cpus'], 'resource_mode': settings['resource_mode']}
                    time.sleep(.5)
                raise WorkspaceError('Terminal provider did not issue a link before the timeout')
            except Exception:
                diagnostic = docker('logs', '--tail', '100', name, check=False)
                with (self.root / 'last-error.log').open('wb') as output:
                    os.chmod(output.name, 0o600)
                    output.write(diagnostic.stdout + diagnostic.stderr)
                self.delete(ident)
                raise

    def open(self, ident, access):
        record = self.read(ident)
        if not isinstance(access, str) or len(access) > 256 or not secrets.compare_digest(
                hashlib.sha256(access.encode()).hexdigest(), record['access_hash']):
            raise WorkspaceError('Workspace link is invalid')
        if record['expires_at'] <= time.time() or record['state'] != 'running':
            raise WorkspaceError('Workspace has expired or stopped')
        if not self._container(record)['State']['Running']:
            raise WorkspaceError('Workspace is stopped')
        self.verify_policy(record)
        if record['kind'] != 'panel':
            raise WorkspaceError('This workspace uses its terminal provider link')
        return {'url': record['provider_url'] + '/#' + access, 'expires_at': record['expires_at']}

    def list(self):
        result = []
        for path in sorted(self.root.glob('*.json')):
            if not _ID.fullmatch(path.stem):
                continue
            try:
                record = self.read(path.stem)
                result.append({**{key: record[key] for key in ('id', 'kind', 'created_at', 'expires_at', 'state', 'memory_mb', 'cpus')},
                               'resource_mode': record.get('resource_mode', 'limited')})
            except WorkspaceError:
                continue
        return result

    def delete(self, ident):
        with _LOCK:
            record = self.read(ident)
            # Refuse to operate on a container belonging to another panel.
            existing = docker('inspect', 'prime-ws-' + ident, check=False)
            if existing.returncode == 0:
                self._container(record)
                docker('rm', '--force', 'prime-ws-' + ident)
            # Owner-scoped names are generated exclusively from validated IDs.
            docker('network', 'rm', record['network'], check=False)
            self._policy(record, remove=True)
            docker('volume', 'rm', record['volume'], check=False)
            self._path(ident).unlink(missing_ok=True)
            return {'ok': True}

    def sweep(self):
        for record in self.list():
            if record['expires_at'] <= time.time():
                self.delete(record['id'])
            elif record['state'] == 'running':
                try:
                    self.verify_policy(self.read(record['id']))
                except WorkspaceError:
                    pass
