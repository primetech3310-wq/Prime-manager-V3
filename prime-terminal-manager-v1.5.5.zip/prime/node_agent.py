#!/usr/bin/env python3
"""Prime node agent (standard library only).

  python3 node_agent.py enroll --panel https://panel.example --token pne_... [--name web-2]
  python3 node_agent.py run

``enroll`` stores the node credentials in ~/.prime-node.json (mode 600). ``run``
sends a heartbeat every 20 seconds with host metrics and executes only the commands
the panel queues: refresh, update and restart. Update downloads the panel's copy of
this file, verifies its SHA-256 against the value the panel sends, and replaces
itself. Restart exits with status 75, which a supervisor such as systemd restarts.
"""
import argparse
import hashlib
import json
import os
import platform
import socket
import ssl
import sys
import time
import urllib.error
import urllib.request

AGENT_VERSION = "1.0.0"
CONF_PATH = os.environ.get("PRIME_NODE_CONF", os.path.expanduser("~/.prime-node.json"))
HEARTBEAT_SECONDS = 20
RESTART_STATUS = 75


def log(message):
    print(time.strftime("%Y-%m-%d %H:%M:%S"), message, flush=True)


def _ssl_context():
    return ssl.create_default_context()


def _request(url, body=None, headers=None, method=None, timeout=25):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method or ("POST" if data is not None else "GET"))
    req.add_header("User-Agent", "prime-node-agent/" + AGENT_VERSION)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    for key, value in (headers or {}).items():
        req.add_header(key, value)
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as response:
        return response.status, response.read(), response.headers


def read_meminfo():
    values = {}
    try:
        with open("/proc/meminfo", encoding="utf-8") as handle:
            for line in handle:
                key, _, rest = line.partition(":")
                values[key] = int(rest.strip().split()[0]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    return values.get("MemTotal", 0), values.get("MemAvailable", 0)


def read_uptime():
    try:
        with open("/proc/uptime", encoding="utf-8") as handle:
            return int(float(handle.read().split()[0]))
    except (OSError, ValueError, IndexError):
        return 0


def read_load():
    try:
        return os.getloadavg()[0]
    except (OSError, AttributeError):
        return 0.0


def metrics():
    total, available = read_meminfo()
    try:
        vfs = os.statvfs("/")
        disk_total = vfs.f_blocks * vfs.f_frsize
        disk_free = vfs.f_bavail * vfs.f_frsize
    except OSError:
        disk_total = disk_free = 0
    return {
        "hostname": socket.gethostname(),
        "arch": platform.machine(),
        "kernel": platform.release(),
        "agent_version": AGENT_VERSION,
        "cpu_count": os.cpu_count() or 0,
        "load1": round(read_load(), 2),
        "mem_total": total,
        "mem_available": available,
        "disk_total": disk_total,
        "disk_free": disk_free,
        "uptime": read_uptime(),
    }


def load_conf():
    with open(CONF_PATH, encoding="utf-8") as handle:
        return json.load(handle)


def save_conf(data):
    tmp = CONF_PATH + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(data, handle)
    os.replace(tmp, CONF_PATH)


def enroll(args):
    panel = args.panel.rstrip("/")
    if not panel.startswith("https://") and not args.insecure_http:
        sys.exit("Use an https:// panel address (or --insecure-http for a private test network)")
    body = {"token": args.token, "name": args.name or socket.gethostname(),
            "hostname": socket.gethostname(), "arch": platform.machine(), "version": AGENT_VERSION}
    try:
        _, raw, _ = _request(panel + "/api/nodes/enroll", body)
    except urllib.error.HTTPError as exc:
        sys.exit("Enrollment refused: " + exc.read().decode("utf-8", "replace")[:300])
    result = json.loads(raw.decode("utf-8"))
    save_conf({"panel": panel, "node_id": result["node_id"], "secret": result["secret"],
               "heartbeat_seconds": result.get("heartbeat_seconds", HEARTBEAT_SECONDS)})
    log("enrolled as node " + result["node_id"] + " (credentials saved to " + CONF_PATH + ")")


def self_update(conf):
    _, body, headers = _request(conf["panel"] + "/api/nodes/agent.py")
    expected = headers.get("X-Agent-SHA256", "")
    actual = hashlib.sha256(body).hexdigest()
    if not expected or expected != actual:
        raise RuntimeError("update rejected: checksum mismatch")
    here = os.path.abspath(__file__)
    tmp = here + ".new"
    with open(tmp, "wb") as handle:
        handle.write(body)
    os.replace(tmp, here)
    log("agent updated to the panel's copy; restarting")


def heartbeat(conf):
    url = conf["panel"] + "/api/nodes/" + conf["node_id"] + "/heartbeat"
    _, raw, _ = _request(url, metrics(), headers={"Authorization": "Bearer " + conf["secret"]})
    return json.loads(raw.decode("utf-8")).get("commands", [])


def run(_args):
    conf = load_conf()
    interval = conf.get("heartbeat_seconds", HEARTBEAT_SECONDS)
    log("node agent " + AGENT_VERSION + " running for " + conf["panel"])
    backoff = 5
    while True:
        try:
            commands = heartbeat(conf)
            backoff = 5
            for command in commands:
                if command == "refresh":
                    log("refresh requested")
                elif command == "update":
                    self_update(conf)
                    return RESTART_STATUS
                elif command == "restart":
                    log("restart requested by the panel")
                    return RESTART_STATUS
            time.sleep(interval)
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                log("panel rejected this node's credentials; enroll again")
                return 1
            log(f"heartbeat failed: HTTP {exc.code}")
            time.sleep(backoff)
            backoff = min(backoff * 2, 300)
        except (urllib.error.URLError, OSError, ValueError, RuntimeError) as exc:
            log("heartbeat failed: " + str(exc))
            time.sleep(backoff)
            backoff = min(backoff * 2, 300)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Prime node agent")
    sub = parser.add_subparsers(dest="command", required=True)
    e = sub.add_parser("enroll", help="register this host with a panel")
    e.add_argument("--panel", required=True)
    e.add_argument("--token", required=True)
    e.add_argument("--name", default="")
    e.add_argument("--insecure-http", action="store_true", help="allow plain http (private networks only)")
    sub.add_parser("run", help="send heartbeats and act on panel commands")
    sub.add_parser("metrics", help="print the metrics this node would send")
    args = parser.parse_args(argv)
    if args.command == "enroll":
        enroll(args)
        return 0
    if args.command == "metrics":
        print(json.dumps(metrics(), indent=2))
        return 0
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
