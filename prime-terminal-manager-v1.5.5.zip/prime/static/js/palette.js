/**
 * Command palette (Ctrl/⌘ + K): jump to any view or run a shell action from
 * the keyboard. Works the same on touch screens via the search field.
 */
import { icon } from "./icons.js";
import { esc } from "./ui.js";

let active = null;

function matches(command, query) {
  if (!query) return true;
  const hay = `${command.label} ${command.hint || ""} ${(command.keywords || []).join(" ")}`.toLowerCase();
  return query.toLowerCase().split(/\s+/).filter(Boolean).every((part) => hay.includes(part));
}

export function closePalette() {
  if (!active) return;
  document.removeEventListener("keydown", active.onKey, true);
  active.overlay.remove();
  active = null;
}

export function openPalette(commands) {
  if (active) {
    closePalette();
    return;
  }
  const overlay = document.createElement("div");
  overlay.className = "palette-overlay";
  overlay.innerHTML = `
    <div class="palette" role="dialog" aria-modal="true" aria-label="Command palette">
      <div class="palette-search">${icon("search")}
        <input id="pal-input" type="text" placeholder="Go to a view or run a command…" autocomplete="off"
          spellcheck="false" aria-label="Command">
        <kbd>esc</kbd>
      </div>
      <div class="palette-list" id="pal-list" role="listbox"></div>
      <div class="palette-foot"><span>↑ ↓ move</span><span>↵ run</span><span>esc close</span></div>
    </div>`;
  document.body.appendChild(overlay);
  const input = overlay.querySelector("#pal-input");
  const list = overlay.querySelector("#pal-list");
  let shown = [];
  let index = 0;

  const paint = () => {
    const query = input.value.trim();
    shown = commands.filter((c) => matches(c, query));
    if (index >= shown.length) index = Math.max(0, shown.length - 1);
    list.innerHTML = shown.length
      ? shown.map((c, i) => `<button class="pal-item ${i === index ? "active" : ""}" data-i="${i}" type="button" role="option">
          <span class="pal-ico">${icon(c.icon || "info")}</span>
          <span class="grow" style="min-width:0"><span class="truncate">${esc(c.label)}</span>
          ${c.hint ? `<span class="pal-hint truncate">${esc(c.hint)}</span>` : ""}</span>
          ${c.shortcut ? `<kbd>${esc(c.shortcut)}</kbd>` : ""}
        </button>`).join("")
      : `<div class="pal-empty">No matches for “${esc(query)}”</div>`;
    const current = list.querySelector(".pal-item.active");
    if (current) current.scrollIntoView({ block: "nearest" });
  };

  const run = (i) => {
    const command = shown[i];
    if (!command) return;
    closePalette();
    try {
      command.run();
    } catch (err) {
      console.error(err);
    }
  };

  const onKey = (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      closePalette();
    } else if (event.key === "ArrowDown") {
      event.preventDefault();
      index = Math.min(shown.length - 1, index + 1);
      paint();
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      index = Math.max(0, index - 1);
      paint();
    } else if (event.key === "Enter") {
      event.preventDefault();
      run(index);
    }
  };
  document.addEventListener("keydown", onKey, true);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) {
      closePalette();
      return;
    }
    const item = event.target.closest(".pal-item");
    if (item) run(Number(item.dataset.i));
  });
  input.addEventListener("input", () => {
    index = 0;
    paint();
  });
  active = { overlay, onKey };
  paint();
  requestAnimationFrame(() => input.focus());
}
