import {manageFactors} from './factors.js';
import {api,setCsrf} from './api.js';
import {esc} from './ui.js';
import * as ui from './ui.js';
import {showConsole} from './views/vm-console.js';
export async function renderTenant(root){
 document.body.style.overflow='auto';
 root.innerHTML=`<main class="stack" style="max-width:1000px;margin:24px auto;padding:18px"><div class="card row wrap"><h2 class="grow">Your workspace</h2><button class="btn" id="tenant-refresh">Refresh</button><button class="btn" id="tenant-factors">Two-factor authentication</button><button class="btn" id="tenant-password">Change password</button><button class="btn" id="tenant-logout">Sign out</button></div><div id="tenant-data" class="stack"></div></main>`;
 const box=root.querySelector('#tenant-data');
 root.querySelector('#tenant-factors').onclick=manageFactors;
 const refresh=async()=>{
  const data=await api.get('/api/tenant');
  box.innerHTML=`<div class="card"><h3>${esc(data.username)} · Shared VMs</h3>${data.vms.map(v=>`<div class="list-row" style="flex-wrap:wrap"><div class="grow"><strong>${esc(v.name)}</strong><div class="faint">${v.cpus} CPU · ${v.memory} MiB · ${v.running?'Running':'Stopped'}</div></div><div class="row wrap">${v.permissions.includes('power')?`<button class="btn" data-vm="${v.id}" data-power="${v.running?'stop':'start'}">${v.running?'Stop':'Start'}</button>`:''}${v.permissions.includes('console')&&v.running?`<button class="btn" data-console="${v.id}">Graphical console</button>`:''}</div></div>`).join('')||'<p class="faint">No VMs shared yet.</p>'}</div><div class="card"><h3>Your invoices</h3>${data.invoices.map(i=>`<div class="list-row"><div class="grow">INV-${i.id} · ${esc(i.description)}<br>${(i.cents/100).toFixed(2)} ${esc(i.currency)} · ${esc(i.status)}<br>Due ${esc(new Date(i.due*1000).toLocaleDateString())}</div></div>`).join('')||'<p class="faint">No invoices.</p>'}</div>`;
 };
 root.querySelector('#tenant-refresh').onclick=()=>refresh().catch(ui.showError);
 root.querySelector('#tenant-logout').onclick=async()=>{await api.post('/api/auth/logout');location.reload();};
 root.querySelector('#tenant-password').onclick=async()=>{
  const current=await ui.promptDialog({title:'Current password',type:'password'});if(!current)return;
  const next=await ui.promptDialog({title:'New password',type:'password'});if(!next)return;
  try{const result=await api.post('/api/auth/password',{current,new:next});setCsrf(result.csrf);ui.notifyOk('Password changed');}catch(e){ui.showError(e);}
 };
 box.onclick=async event=>{
  const button=event.target.closest('[data-power],[data-console]');if(!button)return;
  button.disabled=true;
  try{if(button.dataset.console)await showConsole(button.dataset.console);else{await api.post(`/api/tenant/vms/${button.dataset.vm}/${button.dataset.power}`);await refresh();}}
  catch(e){ui.showError(e);}finally{button.disabled=false;}
 };
 try{await refresh();}catch(e){ui.showError(e);}
}
export function renderInvitation(root,token){
 history.replaceState(null,'',location.pathname);
 document.getElementById('boot')?.remove();
 root.innerHTML=`<div class="auth-wrap"><form id="accept-invitation" class="auth-card stack"><h2>Join your workspace</h2><p>Choose a password for your tenant account.</p><label class="field">New password<input class="input" name="password" type="password" required minlength="10" autocomplete="new-password"></label><button class="btn btn-primary" type="submit">Accept invitation</button><div role="status"></div></form></div>`;
 root.querySelector('form').onsubmit=async e=>{
  e.preventDefault();const b=e.target.querySelector('button');b.disabled=true;
  try{const result=await api.post('/api/auth/accept-invitation',{token,password:new FormData(e.target).get('password')});
   const status=await api.get('/api/auth/status');
   if(status.authenticated){setCsrf(status.csrf);await api.post('/api/auth/logout');}
   e.target.innerHTML=`<h2>Account created</h2><p>Sign in as ${esc(result.username)} with the password you chose.</p><a class="btn" href="/">Sign in</a>`;}
  catch(err){e.target.querySelector('[role=status]').textContent=ui.errorText(err);b.disabled=false;}
 };
}
