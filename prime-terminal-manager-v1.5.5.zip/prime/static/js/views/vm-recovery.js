import { api } from '../api.js';
import * as ui from '../ui.js';
import { esc } from '../ui.js';

const when = timestamp => timestamp ? new Date(timestamp * 1000).toLocaleString() : 'Never';

function rows(kind, items) {
  return items.map(item => `<div class="list-row" style="flex-wrap:wrap;cursor:default">
    <div class="grow" style="min-width:0;overflow-wrap:anywhere"><div class="title">${esc(item.label)}</div>
      <div class="faint">${kind === 'schedules'
        ? `${esc(item.action)} · ${item.enabled ? 'Next: ' + esc(when(item.next_run)) : 'Disabled'} · ${esc(item.state)}<br>Last: ${esc(when(item.last_run))}${item.last_error ? '<br>' + esc(item.last_error) : ''}`
        : `${esc(when(item.created_at))}${item.size ? ' · ' + (item.size / 1048576).toFixed(1) + ' MiB' : ''}`}</div></div>
    <div class="row wrap">${kind === 'schedules'
      ? `<button class="btn btn-sm" data-kind="${kind}" data-item="${item.id}" data-action="${item.enabled ? 'disable' : 'enable'}">${item.enabled ? 'Disable' : 'Enable'}</button>`
      : `<button class="btn btn-sm" data-kind="${kind}" data-item="${item.id}" data-action="restore">Restore</button>`}
    <button class="btn btn-sm btn-danger" data-kind="${kind}" data-item="${item.id}" data-action="delete">Delete</button></div></div>`).join('') || '<p class="faint">None yet.</p>';
}

export async function showRecovery(vm) {
  const future = new Date(Date.now() + 300000);
  const defaultRunAt = new Date(future.getTime() - future.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  let sheet;
  const refresh = async () => {
    const data = await api.get(`/api/vms/${vm}/recovery`);
    if (sheet?.closed) return;
    sheet.body.querySelector('#vm-recovery-items').innerHTML = `
      <h4>Backups</h4>${rows('backups', data.backups)}
      <h4>Snapshots</h4>${rows('snapshots', data.snapshots)}
      <h4>Schedules</h4>${rows('schedules', data.schedules)}`;
  };
  sheet = ui.sheet({title:'Recovery and schedules', wide:true, content:`<div class="stack">
    <p class="faint">Stop this VM before creating or restoring disk recovery points. Backups are independent disk copies. Snapshots stay inside the same disk. Restoring a backup replaces the active disk and removes its snapshots. Neither captures RAM or external disks.</p>
    <div class="row wrap"><button class="btn" data-create="backups">Create backup</button><button class="btn" data-create="snapshots">Create snapshot</button><button class="btn" data-refresh>Refresh</button></div>
    <details><summary>Create schedule</summary><form id="vm-schedule" class="stack" style="margin-top:16px">
      <label class="field">Label<input class="input" name="label" required maxlength="64" value="VM schedule"></label>
      <label class="field">Action<select class="input" name="action"><option value="start">Start</option><option value="stop">Stop</option><option value="restart">Restart</option><option value="backup">Offline disk backup</option></select></label>
      <label class="field">First run (your local time)<input class="input" type="datetime-local" name="run_at" value="${defaultRunAt}" required></label>
      <label class="field">Repeat<select class="input" name="interval"><option value="0">Once</option><option value="3600">Every hour</option><option value="86400">Every day</option><option value="604800">Every week</option></select></label>
      <label class="field">Scheduled backups to keep<input class="input" type="number" name="keep" value="5" min="1" max="100" required></label>
      <p class="faint">The panel must be running. Missed repetitions run once when it returns. Backup schedules fail visibly if the VM is running. Interrupted operations are not automatically retried.</p>
      <button class="btn btn-primary" type="submit">Save schedule</button></form></details>
    <div id="vm-recovery-items" class="stack" role="status">Loading…</div></div>`});
  sheet.body.addEventListener('submit', async event => {
    if (event.target.id !== 'vm-schedule') return;
    event.preventDefault();
    const data = new FormData(event.target), button = event.target.querySelector('[type=submit]');
    button.disabled = true;
    try {
      await api.post(`/api/vms/${vm}/schedules`, {label:data.get('label'), action:data.get('action'),
        run_at:new Date(data.get('run_at')).getTime() / 1000, interval:Number(data.get('interval')), keep:Number(data.get('keep'))});
      ui.notifyOk('Schedule saved');
      await refresh();
    } catch (err) { ui.showError(err, 'Could not save schedule'); }
    finally { button.disabled = false; }
  });
  sheet.body.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    const {create, kind, item, action} = button.dataset;
    if (!create && !kind && !button.hasAttribute('data-refresh')) return;
    button.disabled = true;
    try {
      if (create) {
        const label = await ui.promptDialog({title:create === 'backups' ? 'Create disk backup' : 'Create disk snapshot', label:'Label', value:'Recovery point'});
        if (!label) return;
        await api.post(`/api/vms/${vm}/${create}`, {label});
      } else if (kind) {
        if ((action === 'restore' || action === 'delete') && !await ui.confirmDialog({
          title:action === 'restore' ? 'Restore this disk?' : 'Delete this item?',
          message:action === 'restore' ? 'This discards changes made since the recovery point. Stop the VM first.' : 'This cannot be undone.',
          confirmLabel:action === 'restore' ? 'Restore' : 'Delete', danger:true})) return;
        await api.post(`/api/vms/${vm}/${kind}/${item}/${action}`);
      }
      await refresh();
    } catch (err) { ui.showError(err, 'VM operation failed'); }
    finally { if (button.isConnected) button.disabled = false; }
  });
  try { await refresh(); } catch (err) { ui.showError(err, 'Could not load recovery points'); }
  return sheet;
}
