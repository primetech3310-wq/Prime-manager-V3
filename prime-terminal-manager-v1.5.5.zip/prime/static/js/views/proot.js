/** Named proot workspaces: create a proot environment and get its SSHx link. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";

const TTLS = [[3600, "1 hour"], [7200, "2 hours"], [21600, "6 hours"], [86400, "24 hours"]];
const state = { info: null, items: [], timer: null, container: null };

function expiry(ts) {
  const when = Number(ts) * 1000;
  return Number.isFinite(when) ? new Date(when).toLocaleString() : "unknown";
}

function listMarkup() {
  if (!state.items.length) return ui.emptyState("No named workspaces yet. Create one above.", "box");
  return `<div class="list">${state.items.map((item) => {
    const detail = item.sshx
      ? `<a href="${esc(item.sshx)}" target="_blank" rel="noopener">${esc(item.sshx)}</a>`
      : item.status === "failed" ? `Setup failed: ${esc(item.error || "see the console log")}. Delete it and try again.`
      : item.status === "preparing" ? "Preparing the base image. The first run takes several minutes."
      : "Installing SSHx inside the workspace…";
    return `<div class="list-row">
      <span class="lead">${icon("box")}</span>
      <span class="grow" style="min-width:0;flex:1 1 auto;overflow-wrap:anywhere">
        <span class="title">${esc(item.name)} · ${esc(item.status)}</span>
        <span class="meta" style="display:block;overflow-wrap:anywhere;word-break:break-word">${detail} · expires ${esc(expiry(item.expires_at))}</span>
      </span>
      ${item.sshx ? `<button class="icon-btn" data-copy="${esc(item.sshx)}" title="Copy SSHx link" aria-label="Copy SSHx link">${icon("copy")}</button>` : ""}
      <button class="icon-btn" data-del="${esc(item.id)}" title="Delete workspace" aria-label="Delete workspace">${icon("trash")}</button>
    </div>`;
  }).join("")}</div>`;
}

function shell() {
  const info = state.info || {};
  const building = info.template_ready === false;
  return `<div class="view-enter stack">
    ${building ? `<div class="notice">${icon("info")}<div>The Ubuntu base image is built on the first request.
      This can take several minutes. Later workspaces start quickly.</div></div>` : ""}
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("box")}</div>
        <div><h3>Named proot workspace</h3>
          <div class="sub">An Ubuntu environment under proot with SSHx. proot: ${esc(info.proot || "unknown")}.</div></div></div>
      <form id="pr-form" class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
        <label class="field" style="flex:1 1 180px;min-width:0;max-width:100%">Name (optional)
          <input class="input" name="name" maxlength="40" placeholder="build-box" style="width:100%"></label>
        <label class="field" style="flex:0 1 160px;min-width:0">Lifetime
          <select class="select" name="ttl">${TTLS.map(([value, label]) =>
            `<option value="${value}" ${value === 3600 ? "selected" : ""}>${label}</option>`).join("")}</select></label>
        <button class="btn btn-primary" type="submit">${icon("plus")}Create workspace</button>
      </form>
      <div class="faint" style="font-size:12px">Isolation: ${esc(info.isolation || "")}.</div>
    </div>
    <div class="card stack">
      <h3>Your workspaces</h3>
      <div id="pr-list">${listMarkup()}</div>
    </div>
  </div>`;
}

async function load(container) {
  const [info, list] = await Promise.all([api.get("/api/freeroot/status"), api.get("/api/freeroot")]);
  state.info = info;
  state.items = list.items || [];
  container.innerHTML = shell();
}

async function refreshList() {
  try {
    const list = await api.get("/api/freeroot");
    state.items = list.items || [];
    const target = document.getElementById("pr-list");
    if (target) target.innerHTML = listMarkup();
  } catch (_err) {
    // Transient errors are retried on the next tick.
  }
}

export default {
  title: "Named proot workspace",
  crumb: "proot environment with SSHx",
  async mount(container) {
    state.container = container;
    container.innerHTML = ui.skeletonRows(3, 90);
    try {
      await load(container);
    } catch (err) {
      container.innerHTML = `<div class="notice danger">${icon("alert")}<div>Could not load workspaces.
        <button class="btn" id="pr-retry" style="margin-left:8px">Retry</button></div></div>`;
      ui.showError(err, "Could not load workspaces");
    }
    container.addEventListener("click", async (event) => {
      if (event.target.closest("#pr-retry")) {
        container.innerHTML = ui.skeletonRows(3, 90);
        await load(container).catch((err) => ui.showError(err, "Could not load workspaces"));
        return;
      }
      const copy = event.target.closest("[data-copy]");
      if (copy) {
        await ui.copyText(copy.dataset.copy);
        return;
      }
      const del = event.target.closest("[data-del]");
      if (del) {
        try {
          await api.del("/api/freeroot/" + encodeURIComponent(del.dataset.del));
          ui.notifyOk("Deleted", "The workspace was removed.");
          await refreshList();
        } catch (err) {
          ui.showError(err, "Could not delete workspace");
        }
      }
    });
    container.addEventListener("submit", async (event) => {
      if (event.target.id !== "pr-form") return;
      event.preventDefault();
      const form = new FormData(event.target);
      const name = String(form.get("name") || "").trim();
      try {
        await api.post("/api/freeroot", { name: name || null, ttl: Number(form.get("ttl")) });
        ui.notifyOk("Workspace requested", "Setup takes a few minutes. The SSHx link appears here when it is ready.");
        await refreshList();
      } catch (err) {
        ui.showError(err, "Could not create workspace");
      }
    });
    state.timer = setInterval(refreshList, 4000);
  },
  unmount() {
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
  },
};
