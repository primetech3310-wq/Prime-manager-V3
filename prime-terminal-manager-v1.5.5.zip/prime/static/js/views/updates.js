import { api } from '../api.js';
import { icon } from '../icons.js';
import * as ui from '../ui.js';
import { esc } from '../ui.js';

export default {
  title: 'Panel updates',
  crumb: 'upload, validate and restart',
  async mount(container) {
    container.innerHTML = `<div class="card stack"><div class="card-head"><div class="card-title-icon">${icon('refresh')}</div><div><h3>Update your panel</h3><div class="sub">Upload a complete panel release ZIP</div></div></div>
      <p class="faint">The update is checked before restarting. Application files are backed up; your accounts, settings, workspaces and VM disks stay in the data directory. The previous application is restored if the new release fails to start.</p>
      <p class="faint">Upload trusted application code compatible with the installed Python dependencies. Maximum ZIP size: 64 MiB.</p>
      <label class="field">Panel release ZIP<input class="input" id="update-file" type="file" accept=".zip,application/zip"></label>
      <div class="row wrap"><button class="btn" id="update-validate">Validate upload</button><button class="btn btn-primary" id="update-apply" disabled>Install validated update</button></div>
      <div role="status" aria-live="polite" id="update-status" class="notice info">Loading update status…</div>
      <progress id="update-progress" max="1" value="0" style="width:100%" hidden></progress></div>`;
    const status = container.querySelector('#update-status');
    const apply = container.querySelector('#update-apply');
    const upload = container.querySelector('#update-validate');
    const progress = container.querySelector('#update-progress');
    const render = data => { status.textContent = data.message || data.phase; apply.disabled = data.phase !== 'ready'; };
    try { render(await api.get('/api/updates')); } catch (err) { status.textContent = ui.errorText(err); }
    upload.addEventListener('click', async () => {
      const file = container.querySelector('#update-file').files[0];
      if (!file) return ui.notifyWarn('Select a ZIP', 'Choose the panel update first.');
      upload.disabled = apply.disabled = true;
      progress.hidden = false;
      status.textContent = 'Uploading and checking the release. Keep this page open…';
      try { render(await api.upload('/api/updates/upload', file, {onProgress: value => { progress.value = value; }})); }
      catch (err) { status.textContent = ui.errorText(err); }
      finally { upload.disabled = false; progress.hidden = true; }
    });
    apply.addEventListener('click', async () => {
      if (!await ui.confirmDialog({title:'Install this update?', message:'Active panel connections will disconnect while the panel restarts.', confirmLabel:'Install update'})) return;
      apply.disabled = upload.disabled = true;
      status.innerHTML = `${icon('refresh')} Updating your panel…`;
      progress.hidden = false;
      progress.removeAttribute('value');
      try {
        await api.post('/api/updates/apply');
        const deadline = Date.now() + 120000;
        while (container.isConnected && Date.now() < deadline) {
          await new Promise(resolve => setTimeout(resolve, 1500));
          try {
            const result = await api.get('/api/updates');
            if (['complete','rolled_back'].includes(result.phase)) {
              status.textContent = result.message;
              progress.hidden = true;
              upload.disabled = false;
              if (result.phase === 'complete') { await new Promise(resolve => setTimeout(resolve, 1200)); location.reload(); }
              return;
            }
          } catch { /* service is restarting */ }
        }
        throw new Error('Restart is taking longer than expected. Check the panel service log, then reload.');
      } catch (err) { status.textContent = ui.errorText(err); progress.hidden = true; upload.disabled = false; }
    });
  },
};
