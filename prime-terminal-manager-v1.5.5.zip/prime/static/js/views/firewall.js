/** Firewall management: staged rules with confirm-or-rollback. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";

const state = { data: null, rules: [], policy: "accept", pending: null, timer: null, live: "", busy: false, container: null };

function describe(rule) {
  const port = rule.protocol === "any" ? "any port" : `${rule.protocol.toUpperCase()} ${rule.port}`;
  const from = rule.source || "anywhere";
  return `${rule.action.toUpperCase()} · ${port} · from ${from}`;
}

function rulesMarkup() {
  if (!state.rules.length) return ui.emptyState("No custom rules. Add one below.", "shield");
  return `<div class="list">${state.rules
    .map((rule, index) => `<div class="list-row">
      <span class="lead">${icon("shield")}</span>
      <span class="grow"><span class="title">${esc(describe(rule))}</span>
        <span class="meta">${esc(rule.comment || "no comment")}</span></span>
      <button class="icon-btn" data-remove="${index}" title="Remove rule" aria-label="Remove rule">${icon("trash")}</button>
    </div>`)
    .join("")}</div>`;
}

function pendingMarkup() {
  if (!state.pending) return "";
  return `<div class="notice danger" id="fw-pending">${icon("alert")}<div>
    <b>Confirm the new firewall rules</b>
    <div>They are active now. If you do not confirm, the previous rules are restored automatically.
      Time left: <span id="fw-countdown" class="mono">--</span>s</div>
    <div class="row" style="margin-top:10px;gap:8px">
      <button class="btn btn-primary" data-fw="confirm">${icon("check")}Keep these rules</button>
      <button class="btn" data-fw="cancel">${icon("x")}Restore previous</button>
    </div></div></div>`;
}

function shell() {
  const d = state.data;
  const backend = d?.backend || "none";
  return `<div class="view-enter stack">
    ${!d?.can_apply ? `<div class="notice">${icon("lock")}<div>Firewall changes need root and nftables or iptables. You can still review the rules.
      ${backend === "none" ? "No firewall tool is installed on this host." : ""}</div></div>` : ""}
    <div id="fw-pending-host">${pendingMarkup()}</div>
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("shield")}</div>
        <div><h3>Firewall</h3><div class="sub">Backend: <span class="mono">${esc(backend)}</span>. ${esc(d?.note || "")}</div></div></div>
      <div class="row" style="gap:10px;flex-wrap:wrap">
        <label class="field" style="min-width:220px">Default inbound policy
          <select class="select" id="fw-policy">
            <option value="accept" ${state.policy === "accept" ? "selected" : ""}>Accept (allow unless a rule blocks)</option>
            <option value="drop" ${state.policy === "drop" ? "selected" : ""}>Drop (block unless a rule allows)</option>
          </select></label>
        <span class="right"></span>
        <button class="btn btn-primary" id="fw-apply" ${!d?.can_apply || state.pending ? "disabled" : ""}>${icon("save")}Apply changes</button>
      </div>
      <div class="faint" style="font-size:12px">Panel and SSH ports are always allowed, so changes cannot lock you out of this panel.
        Baseline: ${(d?.baseline || []).map((r) => esc(describe(r))).join(" · ")}</div>
    </div>
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("plus")}</div><div><h3>Add rule</h3><div class="sub">Rules are applied in order.</div></div></div>
      <form id="fw-form" class="stack" autocomplete="off">
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <label class="field">Action<select class="select" name="action">
            <option value="accept">Allow</option><option value="drop">Drop</option><option value="reject">Reject</option></select></label>
          <label class="field">Protocol<select class="select" name="protocol" id="fw-protocol">
            <option value="tcp">TCP</option><option value="udp">UDP</option><option value="any">Any</option></select></label>
          <label class="field">Port or range<input class="input" name="port" id="fw-port" placeholder="443 or 8000-8100" maxlength="16"></label>
          <label class="field">Source (IPv4 or CIDR)<input class="input" name="source" placeholder="anywhere" maxlength="64"></label>
        </div>
        <label class="field">Comment<input class="input" name="comment" placeholder="e.g. web server" maxlength="64"></label>
        <div><button class="btn" type="submit">${icon("plus")}Add to list</button></div>
      </form>
    </div>
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("layers")}</div><div><h3>Rules to apply</h3><div class="sub">Not active until you press Apply.</div></div></div>
      <div id="fw-rules">${rulesMarkup()}</div>
    </div>
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("activity")}</div><div><h3>Live kernel rules</h3><div class="sub">Read back from the firewall tool.</div></div>
        <span class="right"></span><button class="btn btn-sm" id="fw-live">${icon("refresh")}Read</button></div>
      <pre class="code-out mono" id="fw-live-out" style="white-space:pre-wrap;max-height:320px;overflow:auto">${esc(state.live || "Press Read to load the active rules.")}</pre>
    </div>
  </div>`;
}

function render(container) {
  container.innerHTML = shell();
  if (state.pending) startCountdown();
}

function startCountdown() {
  stopCountdown();
  const tick = async () => {
    const out = document.getElementById("fw-countdown");
    if (!state.pending) return stopCountdown();
    const left = Math.max(0, Math.round(state.pending.deadline - Date.now() / 1000));
    if (out) out.textContent = String(left);
    if (left <= 0) {
      stopCountdown();
      await refresh(state.container);
    }
  };
  tick();
  state.timer = setInterval(tick, 1000);
}

function stopCountdown() {
  if (state.timer) clearInterval(state.timer);
  state.timer = null;
}

async function refresh(container) {
  try {
    state.data = await api.get("/api/firewall");
    state.rules = state.data.committed.rules.slice();
    state.policy = state.data.committed.policy;
    state.pending = state.data.pending ? { token: state.data.pending.token, deadline: state.data.pending.deadline } : null;
  } catch (err) {
    ui.showError(err, "Cannot load the firewall");
  }
  if (container?.isConnected) render(container);
}

async function apply(container) {
  if (state.busy) return;
  state.busy = true;
  try {
    const policy = document.getElementById("fw-policy")?.value || state.policy;
    const result = await api.post("/api/firewall/stage", { policy, rules: state.rules });
    state.pending = { token: result.token, deadline: result.deadline };
    ui.notifyWarn("Rules applied", `Confirm within ${result.confirm_seconds} seconds or they roll back.`);
  } catch (err) {
    ui.showError(err, "Rules were not applied");
  } finally {
    state.busy = false;
    render(container);
  }
}

export default {
  title: "Firewall",
  crumb: "host firewall with rollback",
  async mount(container) {
    state.container = container;
    container.innerHTML = ui.skeletonRows(3, 90);
    await refresh(container);
    container.addEventListener("click", async (event) => {
      const remove = event.target.closest("[data-remove]");
      if (remove) {
        state.rules.splice(Number(remove.dataset.remove), 1);
        render(container);
        return;
      }
      if (event.target.closest("#fw-apply")) {
        await apply(container);
        return;
      }
      if (event.target.closest("#fw-live")) {
        try {
          const live = await api.get("/api/firewall/live");
          state.live = live.error ? "Error: " + live.error : live.text || "(no rules)";
        } catch (err) {
          state.live = ui.errorText(err);
        }
        const out = document.getElementById("fw-live-out");
        if (out) out.textContent = state.live;
        return;
      }
      const action = event.target.closest("[data-fw]");
      if (action && state.pending) {
        const path = action.dataset.fw === "confirm" ? "/api/firewall/confirm" : "/api/firewall/cancel";
        try {
          await api.post(path, { token: state.pending.token });
          state.pending = null;
          ui.notifyOk(action.dataset.fw === "confirm" ? "Rules kept" : "Previous rules restored", "");
        } catch (err) {
          ui.showError(err, "Could not update the firewall");
        }
        await refresh(container);
      }
    });
    container.addEventListener("change", (event) => {
      if (event.target.id === "fw-policy") state.policy = event.target.value;
    });
    container.addEventListener("submit", (event) => {
      if (event.target.id !== "fw-form") return;
      event.preventDefault();
      const f = new FormData(event.target);
      const rule = {
        action: f.get("action"),
        protocol: f.get("protocol"),
        port: f.get("protocol") === "any" ? "" : String(f.get("port") || "").trim(),
        source: String(f.get("source") || "").trim(),
        comment: String(f.get("comment") || "").trim(),
      };
      state.rules.push(rule);
      render(container);
    });
  },
  unmount() {
    stopCountdown();
  },
};
