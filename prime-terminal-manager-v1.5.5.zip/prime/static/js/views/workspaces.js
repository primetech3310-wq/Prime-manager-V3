import { api } from '../api.js';
import { icon } from '../icons.js';
import * as ui from '../ui.js';
import { esc, timestamp } from '../ui.js';

export default {
  title:'Private workspaces', crumb:'isolated containers and provisioning APIs',
  async mount(container) {
    const refresh = async () => {
      const data = await api.get('/api/workspaces');
      if (!container.isConnected) return;
      const s = data.settings;
      container.innerHTML = `<div class="stack"><div class="card stack"><div class="card-head"><div class="card-title-icon">${icon('shield')}</div><div><h3>Private workspaces</h3><div class="sub">Docker containers · KVM is not required</div></div></div>
      <div class="notice info">${esc(data.capabilities.message)}</div>
      <p class="faint">Each workspace has its own filesystem, processes and ports. Host and private network connections are blocked. Internet connections use its filtered network. ${s.resource_mode === 'shared' ? 'Shared mode uses the host CPU and memory pool. It cannot prevent one workspace from exhausting host resources.' : 'Limited mode sets CPU, memory and process limits.'}</p>
      <button class="btn" id="workspace-build" ${data.capabilities.available ? '' : 'disabled'}>${data.capabilities.image_ready ? 'Rebuild' : 'Build'} workspace runtime</button>
      <div id="workspace-status" role="status" aria-live="polite"></div>
      <div class="row wrap">${[['SSHx','sshx'],['Panel',s.alias],['ttyd','ttyd']].map(([label,kind]) => `<button class="btn btn-primary" data-create="${esc(kind)}" ${data.capabilities.image_ready && data.capabilities.runtime_ready ? '' : 'disabled'}>Create ${label} workspace</button>`).join('')}</div></div>
      <form class="card stack" id="workspace-settings"><h3>Workspace settings</h3><label class="field">Panel API name<input class="input" name="alias" value="${esc(s.alias)}" required pattern="[a-z][a-z0-9-]{2,31}"></label>
      <label class="field">Session lifetime (seconds)<input class="input" name="ttl" type="number" min="60" max="86400" value="${s.ttl}" required></label>
      <label class="field">Maximum workspaces<input class="input" name="max_workspaces" type="number" min="1" max="100" value="${s.max_workspaces}" required></label>
      <label class="field">Memory per workspace (MiB)<input class="input" name="memory_mb" type="number" min="256" max="65536" value="${s.memory_mb}" required></label>
      <label class="field">CPUs per workspace<input class="input" name="cpus" type="number" min="1" max="64" value="${s.cpus}" required></label>
      <label class="field">Resource allocation<select class="input" name="resource_mode"><option value="limited" ${s.resource_mode === 'limited' ? 'selected' : ''}>Apply CPU, memory and process limits</option><option value="shared" ${s.resource_mode === 'shared' ? 'selected' : ''}>Share host resources (no per-workspace limits)</option></select></label>
      <button class="btn" type="submit">Save workspace settings</button></form>
      <div class="card stack"><h3>Provisioning API keys</h3><p class="faint">Send an Authorization: Bearer header to /API/SSHx, /API/${esc(s.alias)} or /API/ttyd. Each call creates one private workspace and returns its link. API keys can create workspaces; keep them private.</p>
      <button class="btn" id="workspace-key">Create API key</button><div class="list">${s.keys.map(key => `<div class="list-row"><div class="grow">${esc(key.name)}</div><button class="btn btn-sm btn-danger" data-key="${key.id}">Revoke</button></div>`).join('') || '<p class="faint">No API keys.</p>'}</div></div>
      <div class="card"><h3>Workspaces</h3><div class="list">${data.items.map(item => `<div class="list-row wrap"><div class="grow"><div class="title">${esc(item.kind)} · ${item.id.slice(0,8)}</div><div class="faint">${item.memory_mb} MiB · ${item.cpus} CPU · expires ${esc(timestamp(item.expires_at))}</div></div><button class="btn btn-danger btn-sm" data-delete="${item.id}">Delete</button></div>`).join('') || ui.emptyState('No workspaces yet','terminal')}</div></div></div>`;
    };
    container.innerHTML = ui.skeletonRows(2,120);
    try { await refresh(); } catch (err) { container.innerHTML = `<div class="card">${esc(ui.errorText(err))}</div>`; return; }
    container.addEventListener('submit', async event => {
      if (event.target.id !== 'workspace-settings') return;
      event.preventDefault();
      const values = Object.fromEntries(new FormData(event.target));
      for (const key of ['ttl','max_workspaces','memory_mb','cpus']) values[key] = Number(values[key]);
      try { await api.put('/api/workspaces/settings', values); await refresh(); ui.notifyOk('Saved','Workspace defaults updated.'); }
      catch (err) { ui.showError(err); }
    });
    container.addEventListener('click', async event => {
      const button = event.target.closest('button');
      if (!button || (button.closest('#workspace-settings') && button.type === 'submit')) return;
      const status = container.querySelector('#workspace-status');
      button.disabled = true;
      try {
        if (button.id === 'workspace-build') { status.textContent = 'Building the runtime. The first build can take several minutes…'; await api.post('/api/workspaces/build'); await refresh(); }
        else if (button.dataset.create) {
          status.textContent = 'Preparing the workspace and checking network isolation…';
          const result = await api.post(`/api/workspaces/create/${button.dataset.create}`);
          status.replaceChildren();
          const label = document.createElement('p'); label.textContent = 'Workspace ready. Save this private link; it is shown only now.';
          const link = document.createElement('a'); link.href = result.url; link.textContent = result.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.style.overflowWrap = 'anywhere';
          status.append(label, link);
          ui.notifyOk('Workspace ready', 'Your private link is available.');
        } else if (button.id === 'workspace-key') {
          const name = await ui.promptDialog({title:'API key name', value:'Automation'});
          if (!name) return;
          const result = await api.post('/api/workspaces/keys', {name});
          ui.sheet({title:'Save your API key',content:`<p>This key is shown once.</p><textarea readonly class="input mono" aria-label="New API key" rows="3">${esc(result.key)}</textarea>`});
          await refresh();
        } else if (button.dataset.key) { await api.del(`/api/workspaces/keys/${button.dataset.key}`); await refresh(); }
        else if (button.dataset.delete) {
          if (!await ui.confirmDialog({title:'Delete workspace?',message:'Its terminals, processes and files will be permanently removed.',confirmLabel:'Delete',danger:true})) return;
          await api.del(`/api/workspaces/${button.dataset.delete}`); await refresh();
        }
      } catch (err) { if (status?.isConnected) status.textContent = ui.errorText(err); ui.showError(err); }
      finally { if (button.isConnected) button.disabled = false; }
    });
  },
};
