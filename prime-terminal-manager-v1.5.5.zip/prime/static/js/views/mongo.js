/** MongoDB studio: browse databases, collections and documents. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes } from "../ui.js";

const state = {
  session: null,
  info: null,
  db: null,
  coll: null,
  items: [],
  total: 0,
  skip: 0,
  limit: 20,
  filter: "",
  dbs: [],
  colls: [],
};
const PAGE = 20;

function connectForm() {
  return `<div class="card stack">
    <div class="card-head"><div class="card-title-icon">${icon("layers")}</div>
      <div><h3>MongoDB studio</h3><div class="sub">Connect with a mongodb:// or mongodb+srv:// string. The connection lives in server memory only.</div></div></div>
    <form id="mongo-connect" class="stack" autocomplete="off">
      <label class="field">Connection string<input class="input mono" name="uri" required maxlength="2048" placeholder="mongodb://user:password@host:27017/?authSource=admin" spellcheck="false"></label>
      <label class="row" style="gap:8px"><input type="checkbox" name="allow_writes"> Allow inserts and deletes on this connection (off = read-only)</label>
      <div><button class="btn btn-primary" type="submit">${icon("link")}Connect</button></div>
    </form>
    <div class="notice">${icon("info")}<div>Needs the <span class="mono">pymongo</span> package on this host (<span class="mono">pip install pymongo</span>).</div></div>
  </div>`;
}

function crumbsMarkup() {
  const parts = [`<button class="crumb" data-go="root" type="button">${esc(state.info?.host || "server")}</button>`];
  if (state.db) parts.push(`<span class="crumb-sep">/</span><button class="crumb" data-go="db" type="button">${esc(state.db)}</button>`);
  if (state.coll) parts.push(`<span class="crumb-sep">/</span><span class="crumb">${esc(state.coll)}</span>`);
  return `<div class="fm-crumbs">${parts.join("")}</div>`;
}

function documentsMarkup() {
  if (!state.items.length) return ui.emptyState("No documents match this filter", "search");
  return state.items.map((doc, i) => {
    const text = JSON.stringify(doc, null, 2);
    const id = doc._id === undefined ? "" : JSON.stringify(doc._id);
    return `<div class="card" style="margin-top:10px;padding:12px">
      <div class="row between"><span class="mono faint" style="font-size:12px">_id ${esc(id)}</span>
        <span class="row" style="gap:4px">
          <button class="icon-btn" data-copy="${i}" title="Copy JSON" aria-label="Copy">${icon("copy")}</button>
          ${state.info?.allow_writes && id ? `<button class="icon-btn" data-del="${i}" title="Delete document" aria-label="Delete" style="color:var(--danger)">${icon("trash")}</button>` : ""}
        </span></div>
      <pre class="code-out mono" style="white-space:pre-wrap;max-height:260px;overflow:auto;margin-top:8px">${esc(text)}</pre>
    </div>`;
  }).join("");
}

function browser() {
  const writable = state.info?.allow_writes;
  const from = state.total ? state.skip + 1 : 0;
  const to = Math.min(state.skip + state.items.length, state.total);
  return `<div class="card stack">
    <div class="row between" style="flex-wrap:wrap;gap:10px">${crumbsMarkup()}
      <span class="badge ${writable ? "warn" : ""}">${writable ? "writes allowed" : "read-only"}</span></div>
    ${state.db && !state.coll ? collectionsMarkup() : ""}
    ${state.coll ? `
      <form id="mongo-find" class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end">
        <label class="field" style="flex:1;min-width:240px">Filter (JSON)<input class="input mono" name="filter" value="${esc(state.filter)}" placeholder='{"status":"active"}' maxlength="65536"></label>
        <button class="btn" type="submit">${icon("search")}Find</button>
      </form>
      <div class="row between" style="font-size:12px"><span class="faint">${state.total ? `${from}–${to} of ${state.total}` : "0 documents"}</span>
        <span class="row" style="gap:6px">
          <button class="btn btn-sm" data-page="prev" ${state.skip <= 0 ? "disabled" : ""}>Previous</button>
          <button class="btn btn-sm" data-page="next" ${state.skip + PAGE >= state.total ? "disabled" : ""}>Next</button>
        </span></div>
      <div id="mongo-docs">${documentsMarkup()}</div>
      ${writable ? insertMarkup() : ""}
      ${writable ? `<div class="row" style="justify-content:flex-end"><button class="btn" data-drop="1" style="color:var(--danger)">${icon("trash")}Drop this collection</button></div>` : ""}
    ` : ""}
  </div>`;
}

function collectionsMarkup() {
  if (!state.colls.length) return ui.emptyState("No collections in this database", "folder");
  return `<div class="list">${state.colls.map((c) => `<button class="list-row" data-coll="${esc(c.name)}" type="button">
    <span class="lead">${icon("folder")}</span><span class="grow"><span class="title">${esc(c.name)}</span>
    <span class="meta">${c.documents} documents (estimate)</span></span>${icon("chevronRight")}</button>`).join("")}</div>`;
}

function insertMarkup() {
  return `<form id="mongo-insert" class="stack" style="margin-top:10px">
    <label class="field">Insert a document (JSON)<textarea class="input mono" name="doc" rows="5" maxlength="65536" placeholder='{"name":"example"}'></textarea></label>
    <div><button class="btn" type="submit">${icon("plus")}Insert</button></div></form>`;
}

function databasesMarkup() {
  if (!state.dbs.length) return ui.emptyState("No databases visible to this user", "layers");
  return `<div class="list">${state.dbs.map((d) => `<button class="list-row" data-db="${esc(d.name)}" type="button">
    <span class="lead">${icon("layers")}</span><span class="grow"><span class="title">${esc(d.name)}</span>
    <span class="meta">${bytes(d.size)} · ${d.collections} collections</span></span>${icon("chevronRight")}</button>`).join("")}</div>`;
}

function shell() {
  if (!state.session) return connectForm();
  return `<div class="view-enter stack">
    <div class="card"><div class="row between" style="flex-wrap:wrap;gap:10px">
      <div><b>${esc(state.info?.host || "")}</b> <span class="faint" style="font-size:12px">server ${esc(state.info?.version || "")}</span></div>
      <button class="btn btn-sm" id="mongo-disconnect">${icon("power")}Disconnect</button></div></div>
    ${state.db ? browser() : `<div class="card stack">${crumbsMarkup()}${databasesMarkup()}</div>`}
  </div>`;
}

async function render(container) {
  container.innerHTML = shell();
}

async function loadDocs(container) {
  const res = await api.post("/api/mongo/find", {
    session: state.session, db: state.db, coll: state.coll,
    filter: state.filter, limit: state.limit, skip: state.skip,
  });
  state.items = res.items;
  state.total = res.total;
  await render(container);
}

async function openDb(container, name) {
  state.db = name;
  state.coll = null;
  const r = await api.get("/api/mongo/collections", { session: state.session, db: name });
  state.colls = r.items;
  await render(container);
}

async function openColl(container, name) {
  state.coll = name;
  state.skip = 0;
  state.filter = "";
  await loadDocs(container);
}

export default {
  title: "MongoDB studio",
  crumb: "browse databases and documents",
  async mount(container) {
    await render(container);
    container.addEventListener("submit", async (event) => {
      const form = event.target;
      event.preventDefault();
      try {
        if (form.id === "mongo-connect") {
          const f = new FormData(form);
          const res = await api.post("/api/mongo/connect", {
            uri: String(f.get("uri") || "").trim(),
            allow_writes: f.get("allow_writes") === "on",
          });
          state.session = res.id;
          state.info = res;
          state.dbs = res.databases;
          state.db = null;
          state.coll = null;
          ui.notifyOk("Connected", res.host);
          await render(container);
        } else if (form.id === "mongo-find") {
          state.filter = String(new FormData(form).get("filter") || "");
          state.skip = 0;
          await loadDocs(container);
        } else if (form.id === "mongo-insert") {
          const text = String(new FormData(form).get("doc") || "");
          await api.post("/api/mongo/insert", { session: state.session, db: state.db, coll: state.coll, document: text });
          ui.notifyOk("Document inserted", "");
          await loadDocs(container);
        }
      } catch (err) {
        ui.showError(err, "MongoDB request failed");
      }
    });
    container.addEventListener("click", async (event) => {
      const t = event.target;
      try {
        if (t.closest("#mongo-disconnect")) {
          if (state.session) await api.post("/api/mongo/disconnect", { session: state.session });
          Object.assign(state, { session: null, info: null, db: null, coll: null, items: [], dbs: [], colls: [] });
          await render(container);
          return;
        }
        const go = t.closest("[data-go]");
        if (go) {
          if (go.dataset.go === "root") { state.db = null; state.coll = null; }
          if (go.dataset.go === "db") { state.coll = null; }
          if (!state.db) {
            const r = await api.get("/api/mongo/databases", { session: state.session });
            state.dbs = r.items;
          }
          await render(container);
          return;
        }
        const dbBtn = t.closest("[data-db]");
        if (dbBtn) return openDb(container, dbBtn.dataset.db);
        const collBtn = t.closest("[data-coll]");
        if (collBtn) return openColl(container, collBtn.dataset.coll);
        const page = t.closest("[data-page]");
        if (page) {
          state.skip = Math.max(0, state.skip + (page.dataset.page === "next" ? PAGE : -PAGE));
          return loadDocs(container);
        }
        const copy = t.closest("[data-copy]");
        if (copy) {
          const doc = state.items[Number(copy.dataset.copy)];
          return ui.copyText(JSON.stringify(doc, null, 2)).then(() => ui.notifyOk("Copied", "Document JSON"));
        }
        const del = t.closest("[data-del]");
        if (del) {
          const doc = state.items[Number(del.dataset.del)];
          if (!(await ui.confirmDialog({ title: "Delete this document?", message: "The document is removed permanently.", confirmLabel: "Delete", danger: true, detail: JSON.stringify(doc._id) }))) return;
          await api.post("/api/mongo/delete", { session: state.session, db: state.db, coll: state.coll, id: JSON.stringify(doc._id) });
          ui.notifyOk("Deleted", "");
          return loadDocs(container);
        }
        if (t.closest("[data-drop]")) {
          const name = await ui.promptDialog({ title: "Drop collection", label: "Type the collection name to confirm: " + state.coll, hint: "All documents will be permanently removed." });
          if (name === null || name === undefined) return;
          await api.post("/api/mongo/drop", { session: state.session, db: state.db, coll: state.coll, confirm: String(name).trim() });
          ui.notifyOk("Collection dropped", state.coll);
          state.coll = null;
          return openDb(container, state.db);
        }
      } catch (err) {
        ui.showError(err, "MongoDB request failed");
      }
    });
  },
  unmount() {
    // Connections stay open on the server until the admin disconnects or they go idle.
  },
};
