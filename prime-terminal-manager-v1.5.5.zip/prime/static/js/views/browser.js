/**
 * Embedded browser: tabs, address bar, history and bookmarks for web pages that
 * open inside the panel. Pages are fetched by the server (/api/browser/fetch) and
 * shown in a sandboxed frame; see browser_proxy.py for the security model.
 */
import { icon } from "../icons.js";
import { esc } from "../ui.js";
import * as ui from "../ui.js";
import { state as appearance, DEFAULTS } from "../uisettings.js";

const BOOKMARKS_KEY = "prime-browser-bookmarks";
const MAX_TABS = 8;
const QUICK_LINKS = [
  ["Wikipedia", "https://en.wikipedia.org/"],
  ["GitHub", "https://github.com/"],
  ["Hacker News", "https://news.ycombinator.com/"],
  ["MDN Web Docs", "https://developer.mozilla.org/"],
];

// Survives leaving and re-entering the view; the frame itself is rebuilt on mount.
const session = {
  tabs: [],
  activeId: null,
  nextId: 1,
  frame: null,
  refs: null,
  bookmarks: [],
  onMessage: null,
  onKey: null,
  onFullscreenChange: null,
};

/* ---------------------------------------------------------------- helpers */
function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "") || "New tab";
  } catch {
    return "New tab";
  }
}

/** Mirror of the server rule: plain words search, host-like input gets a scheme. */
function toAddress(raw) {
  const text = String(raw || "").trim();
  if (!text) return null;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  if (!/\s/.test(text) && /^(localhost|\d{1,3}(\.\d{1,3}){3}|[\w-]+(\.[\w-]+)+)(:\d+)?([/?#].*)?$/i.test(text)) {
    const local = /^(localhost|127\.|0\.0\.0\.0)/i.test(text);
    return `${local ? "http" : "https"}://${text}`;
  }
  return `https://duckduckgo.com/html/?q=${encodeURIComponent(text).replace(/%20/g, "+")}`;
}

function proxyUrl(url) {
  return `/api/browser/fetch?url=${encodeURIComponent(url)}`;
}

function loadBookmarks() {
  try {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    return Array.isArray(list)
      ? list.filter((b) => b && typeof b.url === "string" && /^https?:\/\//.test(b.url)).slice(0, 60)
      : [];
  } catch {
    return [];
  }
}

function saveBookmarks() {
  try {
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(session.bookmarks));
  } catch { /* private mode: bookmarks last for this visit only */ }
}

function activeTab() {
  return session.tabs.find((t) => t.id === session.activeId) || null;
}

function enabled() {
  return appearance.settings.browser_enabled !== false;
}

function homeUrl() {
  return appearance.settings.browser_home || DEFAULTS.browser_home;
}

function makeTab(url = null) {
  return { id: session.nextId++, url, title: url ? hostOf(url) : "New tab", history: url ? [url] : [], index: url ? 0 : -1, loading: false };
}

/* ---------------------------------------------------------------- render */
function shellMarkup() {
  return `<div class="br">
    <div class="br-tab-bar" role="tablist" data-br="tabs"></div>
    <div class="br-bar">
      <button class="icon-btn" type="button" data-br="back" aria-label="Back">${icon("arrowLeft")}</button>
      <button class="icon-btn" type="button" data-br="forward" aria-label="Forward">${icon("arrowRight")}</button>
      <button class="icon-btn" type="button" data-br="reload" aria-label="Reload">${icon("refresh")}</button>
      <button class="icon-btn br-hide-sm" type="button" data-br="home" aria-label="Home page">${icon("home")}</button>
      <div class="br-url-wrap">
        ${icon("search")}
        <input class="br-url" data-br="url" type="text" inputmode="url" autocomplete="off"
          spellcheck="false" placeholder="Search or enter an address" aria-label="Address">
      </div>
      <button class="icon-btn" type="button" data-br="bookmark" aria-label="Bookmark this page">${icon("bookmark")}</button>
      <button class="icon-btn br-hide-sm" type="button" data-br="external" aria-label="Open in a new tab">${icon("external")}</button>
      <button class="icon-btn" type="button" data-br="fullscreen" aria-label="Fullscreen browser" title="Fullscreen browser">${icon("maximize")}</button>
    </div>
    <div class="br-stage" data-br="stage">
      <div class="br-progress" data-br="progress"></div>
      <div class="br-start" data-br="start"></div>
    </div>
  </div>`;
}

function renderTabs() {
  const bar = session.refs?.tabs;
  if (!bar) return;
  const tabs = session.tabs.map((t) => `<button class="br-tab" type="button" role="tab"
      aria-selected="${t.id === session.activeId}" data-br-tab="${t.id}">
      ${icon("globe")}<span class="br-tab-title">${esc(t.title || "New tab")}</span>
      <span class="br-tab-close" data-br-close="${t.id}" role="button" aria-label="Close tab">${icon("x")}</span>
    </button>`).join("");
  const add = session.tabs.length < MAX_TABS
    ? `<button class="br-tab-new" type="button" data-br="new" aria-label="New tab">${icon("plus")}</button>`
    : "";
  bar.innerHTML = tabs + add;
}

function renderStart() {
  const start = session.refs?.start;
  if (!start) return;
  const bookmarks = session.bookmarks.map((b) => `<button class="br-tile" type="button" data-br-go="${esc(b.url)}">
      <span class="br-tile-ico">${icon("bookmark")}</span><b>${esc(b.title || hostOf(b.url))}</b><span>${esc(hostOf(b.url))}</span>
    </button>`).join("");
  const quick = QUICK_LINKS.map(([name, url]) => `<button class="br-tile" type="button" data-br-go="${esc(url)}">
      <span class="br-tile-ico">${icon("globe")}</span><b>${esc(name)}</b><span>${esc(hostOf(url))}</span>
    </button>`).join("");
  start.innerHTML = `
    <div>
      <h3>Browse inside PRIME</h3>
      <p>Pages open here in a sandbox that cannot reach this panel. Sites that need sign-in or
      heavy scripts may not work fully; use “Open in a new tab” for those.</p>
    </div>
    <div class="br-tiles">
      <button class="br-tile" type="button" data-br-go="${esc(homeUrl())}">
        <span class="br-tile-ico">${icon("home")}</span><b>Home page</b><span>${esc(hostOf(homeUrl()))}</span>
      </button>
      ${bookmarks}
    </div>
    <div>
      <p style="margin:0 0 10px;font-weight:600;color:var(--text-dim)">Quick links</p>
      <div class="br-tiles">${quick}</div>
    </div>`;
}

function renderChrome() {
  const refs = session.refs;
  if (!refs) return;
  const tab = activeTab();
  const on = enabled();
  const hasUrl = Boolean(tab?.url);
  refs.back.disabled = !on || !tab || tab.index <= 0;
  refs.forward.disabled = !on || !tab || tab.index >= tab.history.length - 1;
  refs.reload.disabled = !on || !hasUrl;
  refs.external.disabled = !hasUrl;
  refs.bookmark.disabled = !hasUrl;
  const saved = hasUrl && session.bookmarks.some((b) => b.url === tab.url);
  refs.bookmark.classList.toggle("active", saved);
  refs.bookmark.style.color = saved ? "var(--warn)" : "";
  refs.bookmark.setAttribute("aria-pressed", String(saved));
  refs.url.disabled = !on;
  if (document.activeElement !== refs.url) refs.url.value = tab?.url || "";
  refs.progress.classList.toggle("on", Boolean(tab?.loading));
  refs.frame.classList.toggle("active", hasUrl);
  refs.start.hidden = hasUrl;
  if (!on) {
    refs.start.hidden = false;
    refs.start.innerHTML = `<div class="empty">${icon("lock")}<div><b>The embedded browser is turned off.</b>
      <div class="faint" style="margin-top:6px">An administrator can enable it in Settings → Appearance.</div></div></div>`;
  } else if (!hasUrl) {
    renderStart();
  }
}

function refreshAll() {
  renderTabs();
  renderChrome();
}

/* ---------------------------------------------------------- navigation */
function navigate(tab, url, { push = true, reload = false } = {}) {
  if (!tab || !url || !enabled()) return;
  if (push) {
    tab.history = tab.history.slice(0, tab.index + 1);
    tab.history.push(url);
    tab.index = tab.history.length - 1;
  }
  tab.url = url;
  tab.loading = true;
  tab.title = hostOf(url);
  const frame = session.frame;
  const src = reload ? `${proxyUrl(url)}&_=${Date.now()}` : proxyUrl(url);
  if (frame) frame.src = src;
  refreshAll();
}

function goTo(raw) {
  const tab = activeTab() || openTab(null);
  const url = toAddress(raw);
  if (url) navigate(tab, url);
}

function openTab(url) {
  if (session.tabs.length >= MAX_TABS) {
    ui.notifyWarn("Too many tabs", `Close a tab first (limit ${MAX_TABS}).`);
    return activeTab();
  }
  const tab = makeTab(null);
  session.tabs.push(tab);
  session.activeId = tab.id;
  if (url) navigate(tab, url);
  else refreshAll();
  return tab;
}

function activate(id) {
  const tab = session.tabs.find((t) => t.id === id);
  if (!tab) return;
  session.activeId = id;
  if (tab.url && session.frame) session.frame.src = proxyUrl(tab.url);
  refreshAll();
}

function closeTab(id) {
  const index = session.tabs.findIndex((t) => t.id === id);
  if (index < 0) return;
  session.tabs.splice(index, 1);
  if (!session.tabs.length) {
    openTab(null);
    return;
  }
  if (session.activeId === id) {
    const next = session.tabs[Math.max(0, index - 1)];
    session.activeId = next.id;
    if (next.url && session.frame) session.frame.src = proxyUrl(next.url);
    else if (session.frame) session.frame.removeAttribute("src");
  }
  refreshAll();
}

function toggleBookmark() {
  const tab = activeTab();
  if (!tab?.url) return;
  const at = session.bookmarks.findIndex((b) => b.url === tab.url);
  if (at >= 0) {
    session.bookmarks.splice(at, 1);
    ui.notifyInfo("Bookmark removed", hostOf(tab.url));
  } else {
    session.bookmarks.unshift({ url: tab.url, title: tab.title || hostOf(tab.url) });
    session.bookmarks = session.bookmarks.slice(0, 60);
    ui.notifyOk("Bookmarked", hostOf(tab.url));
  }
  saveBookmarks();
  refreshAll();
}

/* ------------------------------------------------------------- events */
function onFrameMessage(event) {
  const frame = session.frame;
  if (!frame || event.source !== frame.contentWindow) return;
  const data = event.data;
  if (!data || data.source !== "prime-browser") return;
  const tab = activeTab();
  if (!tab) return;
  if (data.type === "nav" && typeof data.url === "string" && /^https?:\/\//i.test(data.url)
      && data.url.length <= 2048) {
    navigate(tab, data.url);
  } else if (data.type === "title") {
    tab.title = String(data.title || "").replace(/\s+/g, " ").trim().slice(0, 120) || hostOf(tab.url);
    renderTabs();
  }
}

function onKey(event) {
  if (!(event.ctrlKey || event.metaKey) || event.altKey) return;
  const key = event.key.toLowerCase();
  const urlInput = session.refs?.url;
  if (key === "l" && urlInput) {
    event.preventDefault();
    urlInput.focus();
    urlInput.select();
  } else if (key === "t") {
    event.preventDefault();
    openTab(null);
  } else if (key === "w" && session.activeId != null) {
    event.preventDefault();
    closeTab(session.activeId);
  }
}

/* -------------------------------------------------------------- view */
export default {
  title: "Browser",
  crumb: "web pages inside the panel",
  noPad: true,

  mount(container) {
    container.innerHTML = shellMarkup();
    session.bookmarks = loadBookmarks();
    const stage = container.querySelector('[data-br="stage"]');
    const frame = document.createElement("iframe");
    frame.className = "br-frame";
    frame.setAttribute("sandbox", "allow-scripts allow-forms allow-popups");
    frame.setAttribute("referrerpolicy", "no-referrer");
    frame.setAttribute("title", "Web page");
    stage.insertBefore(frame, stage.firstChild);

    session.frame = frame;
    session.refs = {
      tabs: container.querySelector('[data-br="tabs"]'),
      back: container.querySelector('[data-br="back"]'),
      forward: container.querySelector('[data-br="forward"]'),
      reload: container.querySelector('[data-br="reload"]'),
      url: container.querySelector('[data-br="url"]'),
      bookmark: container.querySelector('[data-br="bookmark"]'),
      external: container.querySelector('[data-br="external"]'),
      progress: container.querySelector('[data-br="progress"]'),
      start: container.querySelector('[data-br="start"]'),
      frame,
    };

    frame.addEventListener("load", () => {
      const tab = activeTab();
      if (!tab) return;
      tab.loading = false;
      renderChrome();
    });

    const root = container.querySelector(".br");
    const setFullscreen = (on) => {
      root.classList.toggle("is-fullscreen", on);
      document.body.classList.toggle("browser-immersive", on);
      const button = root.querySelector('[data-br="fullscreen"]');
      if (button) {
        button.innerHTML = icon(on ? "minimize" : "maximize");
        button.setAttribute("aria-label", on ? "Exit browser fullscreen" : "Fullscreen browser");
      }
    };
    session.onFullscreenChange = () => {
      if (!document.fullscreenElement && root.classList.contains("is-fullscreen")) setFullscreen(false);
    };
    document.addEventListener("fullscreenchange", session.onFullscreenChange);
    root.addEventListener("click", (event) => {
      const tabBtn = event.target.closest("[data-br-tab]");
      const closeBtn = event.target.closest("[data-br-close]");
      if (closeBtn) {
        event.stopPropagation();
        closeTab(Number(closeBtn.dataset.brClose));
        return;
      }
      if (tabBtn) {
        activate(Number(tabBtn.dataset.brTab));
        return;
      }
      const go = event.target.closest("[data-br-go]");
      if (go) {
        const tab = activeTab() || openTab(null);
        navigate(tab, go.dataset.brGo);
        return;
      }
      const action = event.target.closest("[data-br]");
      if (!action) return;
      const name = action.dataset.br;
      const tab = activeTab();
      if (name === "fullscreen") {
        const on = !root.classList.contains("is-fullscreen");
        setFullscreen(on);
        try {
          if (on && root.requestFullscreen) root.requestFullscreen().catch(() => {});
          else if (!on && document.fullscreenElement === root) document.exitFullscreen().catch(() => {});
        } catch { /* CSS fullscreen remains available */ }
      } else if (name === "back" && tab && tab.index > 0) {
        tab.index -= 1;
        navigate(tab, tab.history[tab.index], { push: false });
      } else if (name === "forward" && tab && tab.index < tab.history.length - 1) {
        tab.index += 1;
        navigate(tab, tab.history[tab.index], { push: false });
      } else if (name === "reload" && tab?.url) {
        navigate(tab, tab.url, { push: false, reload: true });
      } else if (name === "home") {
        navigate(activeTab() || openTab(null), homeUrl());
      } else if (name === "bookmark") {
        toggleBookmark();
      } else if (name === "external" && tab?.url) {
        window.open(tab.url, "_blank", "noopener,noreferrer");
      } else if (name === "new") {
        openTab(null);
      }
    });

    session.refs.url.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        goTo(session.refs.url.value);
        session.refs.url.blur();
      } else if (event.key === "Escape") {
        session.refs.url.value = activeTab()?.url || "";
        session.refs.url.blur();
      }
    });

    // Re-entering the view: rebuild the tab state from the session, reload the active page.
    if (!session.tabs.length) openTab(null);
    const current = activeTab();
    if (current?.url) {
      current.loading = true;
      frame.src = proxyUrl(current.url);
    }
    refreshAll();

    session.onMessage = onFrameMessage;
    session.onKey = onKey;
    window.addEventListener("message", session.onMessage);
    document.addEventListener("keydown", session.onKey);
  },

  unmount() {
    document.body.classList.remove("browser-immersive");
    if (session.onFullscreenChange) document.removeEventListener("fullscreenchange", session.onFullscreenChange);
    if (document.fullscreenElement?.classList.contains("br")) document.exitFullscreen?.().catch(() => {});
    session.onFullscreenChange = null;
    if (session.onMessage) window.removeEventListener("message", session.onMessage);
    if (session.onKey) document.removeEventListener("keydown", session.onKey);
    session.onMessage = null;
    session.onKey = null;
    session.frame = null;
    session.refs = null;
  },
};
