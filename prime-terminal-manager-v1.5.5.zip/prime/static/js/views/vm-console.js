import { api } from '../api.js';
import * as ui from '../ui.js';

export async function showConsole(vm) {
  const {default:RFB} = await import('/static/vendor/novnc/core/rfb.js');
  let rfb, connected = false, attempt = 0;
  const sheet = ui.sheet({title:'VM graphical console', subtitle:'Authenticated connection to this local QEMU guest', wide:true,
    content:`<div class="stack"><div class="row wrap"><button class="btn btn-sm" data-reconnect>Reconnect</button>
      <button class="btn btn-sm" data-cad>Ctrl + Alt + Del</button><button class="btn btn-sm" data-enter>Enter</button>
      <button class="btn btn-sm" data-fullscreen>Fullscreen</button></div>
      <div role="status" data-status>Connecting…</div>
      <div data-screen style="height:55dvh;min-height:180px;background:#000;overflow:hidden"></div>
      <form data-type class="row"><input class="input grow" aria-label="Text to send to VM" placeholder="Type text to send (mobile keyboard)" maxlength="512" autocomplete="off" autocapitalize="off" spellcheck="false"><button class="btn" type="submit">Send</button></form>
      <p class="faint">Text entry uses a US keyboard layout with Caps Lock off. Use the guest keyboard for other layouts.</p></div>`,
    onClose:() => { attempt++; connected = false; rfb?.disconnect(); }});
  const screen = sheet.body.querySelector('[data-screen]'), status = sheet.body.querySelector('[data-status]');
  const connect = async () => {
    const generation = ++attempt;
    connected = false;
    rfb?.disconnect();
    status.textContent = 'Connecting…';
    try {
      const {ticket} = await api.post('/api/auth/ws-ticket');
      if (sheet.closed || generation !== attempt) return;
      const url = new URL(`/api/vms/${vm}/vnc`, location.href);
      url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      url.searchParams.set('ticket', ticket);
      const client = new RFB(screen, url.href);
      rfb = client;
      client.scaleViewport = true;
      client.resizeSession = false;
      client.addEventListener('connect', () => { if (rfb === client) { connected = true; status.textContent = 'Connected'; } });
      client.addEventListener('disconnect', () => { if (rfb === client) { connected = false; status.textContent = 'Disconnected. Check that the VM and your panel session are still running.'; } });
      client.addEventListener('securityfailure', () => { if (rfb === client) status.textContent = 'Console authentication failed.'; });
    } catch (err) { if (!sheet.closed) status.textContent = ui.errorText(err); }
  };
  sheet.body.querySelector('[data-reconnect]').onclick = connect;
  sheet.body.querySelector('[data-cad]').onclick = () => rfb?.sendCtrlAltDel();
  sheet.body.querySelector('[data-enter]').onclick = () => rfb?.sendKey(0xff0d);
  sheet.body.querySelector('[data-fullscreen]').onclick = async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await screen.requestFullscreen(); }
    catch (err) { ui.showError(err, 'Fullscreen unavailable'); }
  };
  sheet.body.querySelector('[data-type]').onsubmit = async event => {
    event.preventDefault();
    const input = event.target.querySelector('input');
    if (!connected) { ui.notifyWarn('Console disconnected', 'Wait for the console to connect before sending text.'); return; }
    if (/[^\x20-\x7e]/.test(input.value)) {
      ui.notifyWarn('Unsupported text', 'Use the guest keyboard for characters outside the US ASCII layout.');
      return;
    }
    const button = event.target.querySelector('button'), text = input.value, client = rfb;
    button.disabled = input.disabled = true;
    try {
      for (const char of text) {
        if (sheet.closed || rfb !== client) break;
        const shift = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()_+{}|:"<>?'.includes(char);
        if (shift) client?.sendKey(0xffe1, 'ShiftLeft', true);
        client?.sendKey(char.codePointAt(0));
        if (shift) client?.sendKey(0xffe1, 'ShiftLeft', false);
        // Pace key events so a software-emulated guest can service its keyboard.
        await new Promise(resolve => setTimeout(resolve, 30));
      }
      input.value = '';
    } finally { button.disabled = input.disabled = false; }
  };
  await connect();
  return sheet;
}
