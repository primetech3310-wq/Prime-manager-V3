/** Distributed nodes: enrollment, health and allow-listed commands. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, ago } from "../ui.js";

const state = { items: [], enrollment: null, timer: null, container: null };

function nodeRows() {
  if (!state.items.length) return ui.emptyState("No nodes enrolled yet. Create an enrollment command above.", "network");
  return `<div class="list">${state.items.map((n) => {
    const m = n.metrics || {};
    const memUsed = m.mem_total ? Math.round(((m.mem_total - m.mem_available) / m.mem_total) * 100) : 0;
    const diskUsed = m.disk_total ? Math.round(((m.disk_total - m.disk_free) / m.disk_total) * 100) : 0;
    return `<div class="list-row">
      <span class="lead">${icon("server")}</span>
      <span class="grow">
        <span class="title">${esc(n.name)} <span class="badge ${n.online ? "ok" : "danger"}"><span class="dot"></span>${n.online ? "online" : "offline"}</span></span>
        <span class="meta mono">${esc(m.hostname || "no heartbeat yet")} · ${esc(m.arch || "")} · ${esc(m.kernel || "")} · agent ${esc(m.agent_version || "?")}</span>
        <span class="meta">${m.cpu_count ? `${m.cpu_count} CPUs · load ${esc(String(m.load1))}` : ""}
          ${m.mem_total ? ` · memory ${memUsed}% · ${bytes(m.mem_total)}` : ""}
          ${m.disk_total ? ` · disk ${diskUsed}%` : ""}</span>
        <span class="meta">${n.last_seen ? "last seen " + ago(n.last_seen) : "never seen"}${n.queued?.length ? " · queued: " + esc(n.queued.join(", ")) : ""}</span>
      </span>
      <span class="row" style="gap:2px">
        <button class="icon-btn" data-cmd="refresh" data-node="${esc(n.id)}" title="Send metrics now" aria-label="Refresh node">${icon("refresh")}</button>
        <button class="icon-btn" data-cmd="update" data-node="${esc(n.id)}" title="Update agent from panel" aria-label="Update agent">${icon("download")}</button>
        <button class="icon-btn" data-cmd="restart" data-node="${esc(n.id)}" title="Restart agent" aria-label="Restart agent">${icon("restart")}</button>
        <button class="icon-btn" data-remove="${esc(n.id)}" title="Remove node" aria-label="Remove node" style="color:var(--danger)">${icon("trash")}</button>
      </span>
    </div>`;
  }).join("")}</div>`;
}

function enrollmentMarkup() {
  if (!state.enrollment) return "";
  const left = Math.max(0, Math.round(state.enrollment.expires_at - Date.now() / 1000));
  return `<div class="notice">${icon("info")}<div class="stack" style="gap:8px;width:100%">
    <div>Run this on the new server (Linux, Python 3). The token works once and expires in ${Math.round(left / 60)} minutes.</div>
    <pre class="code-out mono" id="node-install" style="white-space:pre-wrap;word-break:break-all">${esc(state.enrollment.install_command)}</pre>
    <div class="row"><button class="btn btn-sm" id="node-copy">${icon("copy")}Copy command</button>
      <button class="btn btn-sm" id="node-hide">Hide</button></div></div></div>`;
}

function shell() {
  return `<div class="view-enter stack">
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("network")}</div>
        <div><h3>Nodes</h3><div class="sub">Agents push heartbeats to this panel. Nodes behind NAT need no inbound ports.</div></div>
        <span class="right"></span>
        <button class="btn btn-primary" id="node-new">${icon("plus")}Add node</button></div>
      <div id="node-enroll">${enrollmentMarkup()}</div>
      <div id="node-list">${nodeRows()}</div>
      <div class="faint" style="font-size:12px">Commands are limited to refresh, update and restart. The panel cannot run arbitrary commands on nodes.</div>
    </div>
  </div>`;
}

async function refresh(container) {
  try {
    state.items = (await api.get("/api/nodes")).items;
  } catch (err) {
    ui.showError(err, "Cannot load nodes");
  }
  if (container.isConnected) container.innerHTML = shell();
}

export default {
  title: "Nodes",
  crumb: "distributed agents",
  async mount(container) {
    state.container = container;
    container.innerHTML = ui.skeletonRows(3, 80);
    await refresh(container);
    state.timer = setInterval(() => {
      if (!container.isConnected) return;
      if (!document.querySelector("#node-enroll .code-out")) refresh(container);
    }, 15000);
    container.addEventListener("click", async (event) => {
      const t = event.target;
      try {
        if (t.closest("#node-new")) {
          state.enrollment = await api.post("/api/nodes/enrollment", {});
          return refresh(container);
        }
        if (t.closest("#node-hide")) {
          state.enrollment = null;
          return refresh(container);
        }
        if (t.closest("#node-copy")) {
          const text = document.getElementById("node-install")?.textContent || "";
          return ui.copyText(text).then(() => ui.notifyOk("Copied", "Install command"));
        }
        const cmd = t.closest("[data-cmd]");
        if (cmd) {
          await api.post(`/api/nodes/${encodeURIComponent(cmd.dataset.node)}/command`, { action: cmd.dataset.cmd });
          ui.notifyOk("Queued", cmd.dataset.cmd + " will run at the node's next heartbeat");
          return refresh(container);
        }
        const rm = t.closest("[data-remove]");
        if (rm) {
          if (!(await ui.confirmDialog({ title: "Remove this node?", message: "The node must enroll again to reconnect.", confirmLabel: "Remove", danger: true }))) return;
          await api.del(`/api/nodes/${encodeURIComponent(rm.dataset.remove)}`);
          return refresh(container);
        }
      } catch (err) {
        ui.showError(err, "Node action failed");
      }
    });
  },
  unmount() {
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
  },
};
