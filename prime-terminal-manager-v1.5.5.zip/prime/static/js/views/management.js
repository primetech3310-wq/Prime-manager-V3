/** Account delegation and a billing ledger using the panel's existing components. */
import {manageFactors} from '../factors.js';
import {api} from '../api.js';
import * as ui from '../ui.js';
import {esc} from '../ui.js';
const field=(label,name,type='text',value='',extra='')=>`<label class="field">${label}<input class="input" name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const options=(items,label='name',key='id')=>items.map(i=>`<option value="${esc(i[key])}">${esc(i[label])}</option>`).join('');
const form=(kind,title,fields)=>`<details class="card"><summary>${title}</summary><form class="stack" style="margin-top:16px" data-form="${kind}">${fields}<button class="btn btn-primary" type="submit">Save</button></form></details>`;
const money=i=>`${(i.cents/100).toFixed(2)} ${esc(i.currency)}`;
export default {
 title:'Accounts and billing',crumb:'delegation, plans, invoices and coupons',
 async mount(container){
  const refresh=async()=>{
   const [d,vm]=await Promise.all([api.get('/api/management'),api.get('/api/vms')]);
   if(!container.isConnected)return;
   const tenants=d.users.filter(u=>!u.is_admin), future=new Date(Date.now()+604800000).toISOString().slice(0,10);
   container.innerHTML=`<div class="stack">
    <div class="card"><h3>Account security</h3><button class="btn" data-factors>Manage two-factor authentication</button></div><div class="card"><h3>Accounts</h3><p class="faint">Administrators control this host. Invited tenants can access only their invoices and the VMs you share. New accounts are tenants; existing administrators keep their access.</p>
     ${d.users.map(u=>`<div class="list-row"><div class="grow">${esc(u.username)} · ${u.is_admin?'Administrator':'Tenant'}</div>${u.is_admin?'':`<button class="btn btn-sm btn-danger" data-user="${esc(u.username)}">Delete tenant</button>`}</div>`).join('')}</div>
    ${form('invitations','Invite tenant',field('Username','username','text','','required maxlength="64"')+field('Expires in hours','hours','number',24,'required min="1" max="168"'))}
    ${form('grants','Share a VM',`<label class="field">Tenant<select class="input" name="username" required>${options(tenants,'username','username')}</select></label><label class="field">VM<select class="input" name="vm_id" required>${options(vm.items)}</select></label><label><input name="view" type="checkbox" checked> View</label><label><input name="power" type="checkbox"> Start, stop and restart</label><label><input name="console" type="checkbox"> Graphical console (guest administrator authority)</label><p class="faint">Clear every permission to revoke access.</p>`)}
    <div class="card"><h3>VM shares</h3>${d.grants.map(g=>`<p>${esc(g.username)} → ${esc(vm.items.find(v=>v.id===g.vm_id)?.name||g.vm_id)} · ${esc(g.permissions.join(', '))}</p>`).join('')||'<p class="faint">No shared VMs.</p>'}</div>
    <div class="card"><h3>Billing ledger</h3><p class="faint">Amounts use integer cents. Payment status is recorded manually by the administrator after receiving payment. Plans describe resources; invoicing does not automatically create a VM.</p>
     <h4>Plans</h4>${d.plans.map(p=>`<div class="list-row"><div class="grow">${esc(p.name)} · ${money(p)} · ${p.cpus} CPU / ${p.memory} MiB / ${p.disk} GiB ${p.active?'':'(Archived)'}</div>${p.active?`<button class="btn btn-sm" data-delete="plans" data-id="${p.id}">Archive</button>`:''}</div>`).join('')||'<p class="faint">No plans.</p>'}
     <h4>Invoices</h4>${d.invoices.map(i=>`<div class="list-row" style="flex-wrap:wrap"><div class="grow">INV-${i.id} · ${esc(i.username)} · ${esc(i.description)}<br>${money(i)} · ${esc(i.status)}</div><div class="row wrap">${['pending','paid','cancelled'].filter(s=>s!==i.status).map(s=>`<button class="btn btn-sm" data-invoice="${i.id}" data-status="${s}">Mark ${s}</button>`).join('')}</div></div>`).join('')||'<p class="faint">No invoices.</p>'}
     <h4>Coupons</h4>${d.coupons.map(c=>`<div class="list-row"><div class="grow">${esc(c.code)} · ${c.value}${c.kind==='percentage'?'%':' cents'} · ${c.used}/${c.max_uses} used</div><button class="btn btn-sm" data-delete="coupons" data-id="${esc(c.code)}">Delete</button></div>`).join('')||'<p class="faint">No coupons.</p>'}</div>
    ${form('plans','Create resource plan',field('Plan name','name','text','','required maxlength="100"')+field('Monthly price (cents)','cents','number',500,'required min="0" step="1"')+field('Currency (ISO code)','currency','text','USD','required pattern="[A-Z]{3}"')+field('CPUs','cpus','number',1,'required min="1" max="64"')+field('Memory (MiB)','memory','number',1024,'required min="128" max="65536"')+field('Disk (GiB)','disk','number',20,'required min="1"'))}
    ${form('coupons','Create coupon',field('Code','code','text','','required pattern="[A-Za-z0-9_-]{1,32}"')+'<label class="field">Type<select class="input" name="kind"><option value="percentage">Percentage</option><option value="fixed">Fixed cents</option></select></label>'+field('Discount value','value','number',10,'required min="1"')+field('Maximum uses','max_uses','number',100,'required min="1"')+field('Expires (UTC)','expires','date',future,'required'))}
    ${form('invoices','Issue invoice',`<label class="field">Account<select class="input" name="username" required>${options(d.users,'username','username')}</select></label><label class="field">Plan<select class="input" name="plan_id" required>${options(d.plans.filter(p=>p.active))}</select></label>`+field('Due date (UTC)','due','date',future,'required')+field('Coupon (optional)','coupon'))}
   </div>`;
  };
  container.innerHTML=ui.skeletonRows(3,100);
  try{await refresh();}catch(e){ui.showError(e);return;}
  container.addEventListener('submit',async e=>{
   const form=e.target.closest('[data-form]');if(!form)return;e.preventDefault();
   const button=form.querySelector('[type=submit]'), kind=form.dataset.form, values=Object.fromEntries(new FormData(form));
   if(kind==='grants')values.permissions=['view','power','console'].filter(p=>values[p]);
   for(const key of ['hours','cents','cpus','memory','disk','value','max_uses'])if(key in values)values[key]=Number(values[key]);
   for(const key of ['due','expires'])if(key in values)values[key]=Date.parse(values[key]+'T23:59:59Z')/1000;
   button.disabled=true;
   try{
    const result=await api.post('/api/management/'+kind,values);
    if(kind==='invitations'){
     const url=new URL(location.href);url.hash='invite='+result.token;
     ui.sheet({title:'Tenant invitation',content:`<p>Send this private, single-use link to ${esc(result.username)}. They choose their password.</p><textarea class="input mono" readonly>${esc(url.href)}</textarea>`});
    }
    await refresh();ui.notifyOk('Saved');
   }catch(err){ui.showError(err);}finally{button.disabled=false;}
  });
  container.addEventListener('click',async e=>{
   if(e.target.closest('[data-factors]')) { await manageFactors(); return; }
   const b=e.target.closest('[data-user],[data-delete],[data-invoice]');if(!b)return;
   if(!await ui.confirmDialog({title:'Apply this change?',message:b.dataset.user?'This removes the tenant account, its sessions and VM shares. Invoices remain in the ledger.':'Confirm this record change.',danger:true}))return;
   b.disabled=true;
   try{
    if(b.dataset.user)await api.del('/api/management/users/'+encodeURIComponent(b.dataset.user));
    else if(b.dataset.delete)await api.del('/api/management/'+b.dataset.delete+'/'+encodeURIComponent(b.dataset.id));
    else await api.post('/api/management/invoices/'+b.dataset.invoice+'/status',{status:b.dataset.status});
    await refresh();
   }catch(err){ui.showError(err);b.disabled=false;}
  });
 }
};
