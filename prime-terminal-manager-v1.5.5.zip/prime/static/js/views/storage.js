/** Storage pools and ISO administration. */
import { api, getCsrf } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, timestamp } from "../ui.js";

const state = { pools: [], maxIso: 0, selected: null, isos: [], busy: false };

function poolRows() {
  if (!state.pools.length) return ui.emptyState("No storage pools", "hardDrive");
  return state.pools.map((p) => {
    const used = p.total ? Math.round((p.used / p.total) * 100) : 0;
    const selected = state.selected === p.id;
    return `<div class="list-row ${selected ? "active" : ""}" data-pool="${esc(p.id)}" role="button" tabindex="0">
      <span class="lead">${icon("hardDrive")}</span>
      <span class="grow"><span class="title">${esc(p.name)}${p.builtin ? ` <span class="badge">built in</span>` : ""}</span>
        <span class="meta mono">${esc(p.path)}</span>
        <span style="display:block;height:6px;border-radius:6px;background:var(--surface-2,rgba(128,128,128,.2));margin-top:6px;overflow:hidden">
          <span style="display:block;height:100%;width:${used}%;background:var(--accent)"></span></span>
        <span class="meta">${p.available ? `${bytes(p.used)} of ${bytes(p.total)} used · ${bytes(p.free)} free · ${p.iso_count} ISO` : "Path unavailable"}</span>
      </span>
      ${p.builtin ? "" : `<button class="icon-btn" data-remove-pool="${esc(p.id)}" title="Unregister pool (files kept)" aria-label="Remove pool">${icon("trash")}</button>`}
    </div>`;
  }).join("");
}

function isoRows() {
  if (!state.selected) return ui.emptyState("Choose a pool to see its ISO images", "folderOpen");
  if (!state.isos.length) return ui.emptyState("No ISO images in this pool yet", "download");
  return `<div class="list">${state.isos.map((iso) => `<div class="list-row">
      <span class="lead">${icon("box")}</span>
      <span class="grow"><span class="title mono">${esc(iso.name)}</span>
        <span class="meta">${bytes(iso.size)} · ${timestamp(iso.modified)}</span>
        <span class="meta mono" data-sum="${esc(iso.name)}"></span></span>
      <button class="icon-btn" data-sum-btn="${esc(iso.name)}" title="Checksum (SHA-256)" aria-label="Checksum">${icon("key")}</button>
      <button class="icon-btn" data-del-iso="${esc(iso.name)}" title="Delete ISO" aria-label="Delete ISO" style="color:var(--danger)">${icon("trash")}</button>
    </div>`).join("")}</div>`;
}

function shell() {
  const pool = state.pools.find((p) => p.id === state.selected);
  return `<div class="view-enter stack">
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("hardDrive")}</div>
        <div><h3>Storage pools</h3><div class="sub">Directories the panel can store disks and ISO images in.</div></div></div>
      <div class="list">${poolRows()}</div>
      <form id="pool-form" class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
        <label class="field">Name<input class="input" name="name" maxlength="40" required placeholder="Fast SSD"></label>
        <label class="field" style="flex:1;min-width:220px">Absolute path<input class="input mono" name="path" maxlength="1024" required placeholder="/srv/isos-pool"></label>
        <button class="btn" type="submit">${icon("plus")}Add pool</button>
      </form>
    </div>
    <div class="card stack">
      <div class="card-head"><div class="card-title-icon">${icon("box")}</div>
        <div><h3>ISO images${pool ? ": " + esc(pool.name) : ""}</h3>
        <div class="sub">Upload .iso files up to ${bytes(state.maxIso)}. The ISO 9660 signature is checked before it is stored.</div></div></div>
      ${pool ? `<div class="row" style="gap:10px;flex-wrap:wrap">
        <input class="input" id="iso-name" placeholder="debian-12.iso" maxlength="125" style="max-width:260px">
        <input type="file" id="iso-file" accept=".iso,application/x-iso9660-image" hidden>
        <button class="btn btn-primary" id="iso-pick">${icon("upload")}Choose and upload</button>
        <div class="faint" id="iso-progress" style="font-size:12px"></div></div>` : ""}
      <div id="iso-list">${isoRows()}</div>
    </div>
  </div>`;
}

async function refresh(container) {
  try {
    const data = await api.get("/api/storage/pools");
    state.pools = data.items;
    state.maxIso = data.max_iso_bytes;
    if (state.selected && !state.pools.some((p) => p.id === state.selected)) state.selected = null;
    if (!state.selected && state.pools.length) state.selected = state.pools[0].id;
    state.isos = state.selected ? (await api.get(`/api/storage/pools/${encodeURIComponent(state.selected)}/isos`)).items : [];
  } catch (err) {
    ui.showError(err, "Cannot load storage");
  }
  if (container.isConnected) container.innerHTML = shell();
}

function uploadIso(container, file, name) {
  const progress = document.getElementById("iso-progress");
  const pool = state.selected;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/storage/pools/${encodeURIComponent(pool)}/isos?name=${encodeURIComponent(name)}`);
    xhr.withCredentials = true;
    xhr.setRequestHeader("Content-Type", "application/octet-stream");
    if (getCsrf()) xhr.setRequestHeader("X-PRIME-CSRF", getCsrf());
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && progress) progress.textContent = `Uploading ${Math.round((e.loaded / e.total) * 100)}%`;
    };
    xhr.onload = () => {
      let body = {};
      try { body = JSON.parse(xhr.responseText || "{}"); } catch { /* not JSON */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(body);
      else reject(new Error(body.detail || `Upload failed (HTTP ${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error("Upload interrupted. Check your connection and try again."));
    xhr.send(file);
  });
}

export default {
  title: "Storage",
  crumb: "pools and ISO images",
  async mount(container) {
    container.innerHTML = ui.skeletonRows(3, 90);
    await refresh(container);
    container.addEventListener("click", async (event) => {
      const poolBtn = event.target.closest("[data-pool]");
      const removePool = event.target.closest("[data-remove-pool]");
      const del = event.target.closest("[data-del-iso]");
      const sum = event.target.closest("[data-sum-btn]");
      const pick = event.target.closest("#iso-pick");
      try {
        if (removePool) {
          event.stopPropagation();
          const id = removePool.dataset.removePool;
          if (!(await ui.confirmDialog({ title: "Unregister this pool?", message: "The directory and its files are kept on disk.", confirmLabel: "Unregister", danger: true }))) return;
          await api.del(`/api/storage/pools/${encodeURIComponent(id)}`);
          if (state.selected === id) state.selected = null;
          await refresh(container);
        } else if (poolBtn) {
          state.selected = poolBtn.dataset.pool;
          await refresh(container);
        } else if (del) {
          const name = del.dataset.delIso;
          if (!(await ui.confirmDialog({ title: "Delete " + name + "?", message: "This permanently removes the ISO file.", confirmLabel: "Delete", danger: true }))) return;
          await api.del(`/api/storage/pools/${encodeURIComponent(state.selected)}/isos/${encodeURIComponent(name)}`);
          ui.notifyOk("ISO deleted", name);
          await refresh(container);
        } else if (sum) {
          const name = sum.dataset.sumBtn;
          const out = container.querySelector(`[data-sum="${CSS.escape(name)}"]`);
          if (out) out.textContent = "Computing…";
          const r = await api.get(`/api/storage/pools/${encodeURIComponent(state.selected)}/isos/${encodeURIComponent(name)}/checksum`);
          if (out) out.textContent = "sha256 " + r.sha256;
        } else if (pick) {
          document.getElementById("iso-file")?.click();
        }
      } catch (err) {
        ui.showError(err, "Storage action failed");
      }
    });
    container.addEventListener("change", async (event) => {
      if (event.target.id !== "iso-file") return;
      const file = event.target.files?.[0];
      if (!file || state.busy) return;
      const name = (document.getElementById("iso-name")?.value || file.name || "").trim();
      state.busy = true;
      try {
        await uploadIso(container, file, name);
        ui.notifyOk("ISO uploaded", name);
        await refresh(container);
      } catch (err) {
        ui.showError(err, "ISO upload failed");
      } finally {
        state.busy = false;
        event.target.value = "";
      }
    });
    container.addEventListener("submit", async (event) => {
      if (event.target.id !== "pool-form") return;
      event.preventDefault();
      const f = new FormData(event.target);
      try {
        await api.post("/api/storage/pools", { name: String(f.get("name")).trim(), path: String(f.get("path")).trim() });
        ui.notifyOk("Pool added", "");
        await refresh(container);
      } catch (err) {
        ui.showError(err, "Could not add the pool");
      }
    });
  },
  unmount() {
    state.busy = false;
  },
};
