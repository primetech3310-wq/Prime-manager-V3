/** Settings → Appearance & performance: the admin's controls for the whole panel. */
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";
import {
  DEFAULTS, state, previewUiSettings, saveUiSettings, resetUiSettings, isDirty, resolve,
} from "../uisettings.js";

const SWATCHES = [
  ["#0a84ff", "Blue"], ["#bf5af2", "Purple"], ["#ff375f", "Pink"], ["#ff9f0a", "Orange"],
  ["#30d158", "Green"], ["#64d2ff", "Teal"], ["#ff453a", "Red"],
];
const THEMES = [["dark", "Dark"], ["light", "Light"], ["auto", "System"]];
const MOTION = [["full", "Full"], ["reduced", "Reduced"], ["off", "Off"]];
const PERF = [["auto", "Auto"], ["quality", "Quality"], ["performance", "Performance"]];

const RANGES = {
  glass_blur: { min: 0, max: 40, step: 1, unit: (v) => `${v}px` },
  radius: { min: 0.6, max: 1.5, step: 0.05, unit: (v) => `${Number(v).toFixed(2)}×` },
  ambient_opacity: { min: 0, max: 200, step: 5, unit: (v) => `${v}%` },
  ambient_speed: { min: 25, max: 300, step: 5, unit: (v) => `${v}%` },
  ambient_size: { min: 50, max: 200, step: 5, unit: (v) => `${v}%` },
  glass_saturation: { min: 0, max: 300, step: 5, unit: (v) => `${v}%` },
  sidebar_width: { min: 180, max: 360, step: 2, unit: (v) => `${v}px` },
  topbar_height: { min: 48, max: 100, step: 2, unit: (v) => `${v}px` },
  mobilebar_height: { min: 52, max: 100, step: 2, unit: (v) => `${v}px` },
  font_size: { min: 12, max: 22, step: 1, unit: (v) => `${v}px` },
  button_radius: { min: 0, max: 30, step: 1, unit: (v) => `${v}px` },
};

function seg(key, options) {
  return `<div class="ui-seg" role="group" aria-label="${esc(key)}">${options
    .map(([value, label]) => `<button type="button" data-ui-seg="${key}" data-val="${value}"
      aria-pressed="false">${esc(label)}</button>`)
    .join("")}</div>`;
}

function row(label, hint, control) {
  return `<div class="ui-row">
    <div class="ui-row-label"><b>${esc(label)}</b><span>${esc(hint)}</span></div>
    <div class="ui-row-control">${control}</div>
  </div>`;
}

function range(key) {
  const r = RANGES[key];
  return `<div class="ui-range-wrap">
    <input class="ui-range" type="range" data-ui-range="${key}" aria-label="${esc(key.replaceAll('_', ' '))}" min="${r.min}" max="${r.max}" step="${r.step}">
    <span class="ui-value" data-ui-out="${key}"></span>
  </div>`;
}

function toggle(key) {
  return `<button class="switch" type="button" role="switch" data-ui-switch="${key}"
    aria-checked="false" aria-label="${esc(key)}"></button>`;
}

export function appearanceCardHtml() {
  const swatches = SWATCHES.map(([hex, name]) => `<button class="ui-swatch" type="button"
      data-ui-swatch="${hex}" style="--c:${hex}" aria-label="${esc(name)}" aria-pressed="false"></button>`)
    .join("");
  return `<div class="card span-2" id="appearance-card">
    <div class="card-head">
      <div class="card-title-icon">${icon("sun")}</div>
      <div><h3>Appearance &amp; performance</h3>
        <div class="sub">Set by the administrator. Applies to every browser that opens this panel.</div></div>
      <div class="spacer"></div>
      <span class="ui-dirty" data-ui-dirty hidden>Unsaved preview</span>
    </div>

    <div class="ui-preview" data-ui-preview>
      <span class="logo-mark">${icon("terminal")}</span>
      <div class="grow" style="min-width:0">
        <div style="font-weight:650">Live preview</div>
        <div class="faint" style="font-size:12.5px">Changes show here first. Save to make them permanent.</div>
      </div>
      <button class="btn btn-primary btn-sm" type="button" tabindex="-1">Primary</button>
      <button class="btn btn-sm" type="button" tabindex="-1">Secondary</button>
    </div>

    ${row("Theme", "Dark is the default. System follows the device setting.", seg("theme", THEMES))}
    ${row("Accent colour", "Used for buttons, selection and the liquid highlights.",
      `<div class="ui-swatches">${swatches}<input class="ui-color" type="color" data-ui-color
        aria-label="Custom accent colour"></div>`)}
    ${row("Glass blur", "How strongly surfaces blur what is behind them. Zero is solid.", range("glass_blur"))}
    ${row("Corner radius", "Scales the roundness of cards, buttons and fields.", range("radius"))}
    ${row("Motion", "Reduced keeps feedback but removes drifting and sweeping effects.", seg("motion", MOTION))}
    ${row("Liquid background", "Slow colour orbs behind the interface.", toggle("ambient"))}
    ${row("Performance profile",
      "Auto turns blur off on low-power devices (4 cores or fewer, or 4 GB RAM or less).",
      seg("performance", PERF) + `<span class="ui-value" data-ui-perf-note style="min-width:0"></span>`)}
    ${row("Embedded browser", "Lets users open websites inside the panel from the Browser page.", toggle("browser_enabled"))}
    ${row("Browser home page", "Opened first in a new browser session.",
      `<input class="input" style="width:min(320px,100%)" type="url" data-ui-home maxlength="512"
        placeholder="https://duckduckgo.com/" spellcheck="false">`)}
    ${row("Secondary accent", "Colour of the second ambient orb and accents.", '<input class="ui-color" type="color" data-ui-secondary aria-label="Secondary accent colour">')}
    ${row("Background intensity", "Adjust the opacity of the ambient colours.", range("ambient_opacity"))}
    ${row("Background speed", "Change how quickly the ambient colours move.", range("ambient_speed"))}
    ${row("Background size", "Scale all ambient colour orbs.", range("ambient_size"))}
    ${row("First background orb", "Show or hide the first colour.", toggle("orb_one"))}
    ${row("Second background orb", "Show or hide the second colour.", toggle("orb_two"))}
    ${row("Third background orb", "Show or hide the third colour.", toggle("orb_three"))}
    ${row("Glass saturation", "Adjust colour saturation behind glass panels.", range("glass_saturation"))}
    ${row("Sidebar width", "Adjust the desktop navigation width.", range("sidebar_width"))}
    ${row("Top bar height", "Adjust the header height.", range("topbar_height"))}
    ${row("Mobile bar height", "Adjust the bottom navigation height.", range("mobilebar_height"))}
    ${row("Base font size", "Adjust text that uses the base font size.", range("font_size"))}
    ${row("Button radius", "Adjust button corners independently of cards.", range("button_radius"))}
    ${row("Custom CSS", "Styles apply to every browser, including the login page. Save to publish.",
      `<div style="width:min(560px,100%)"><textarea class="input" data-ui-css maxlength="65536" rows="8" spellcheck="false" aria-label="Custom CSS" style="width:100%;font-family:var(--mono)"></textarea><a href="/static/CSS.md" download="CSS.md">Download CSS guide</a></div>`)}

    <div class="ui-actions" style="margin-top:18px">
      <button class="btn btn-ghost btn-sm" type="button" data-ui-reset>${icon("refresh")}Reset to defaults</button>
      <span class="grow"></span>
      <button class="btn btn-sm" type="button" data-ui-discard>Discard</button>
      <button class="btn btn-primary" type="button" data-ui-save>${icon("save")}Save for everyone</button>
    </div>
  </div>`;
}

function sync(root) {
  const s = state.settings;
  const r = resolve(s);
  root.querySelectorAll("[data-ui-seg]").forEach((node) => {
    const value = s[node.dataset.uiSeg];
    node.setAttribute("aria-pressed", String(node.dataset.val === String(value)));
  });
  root.querySelectorAll("[data-ui-swatch]").forEach((node) => {
    node.setAttribute("aria-pressed", String(node.dataset.uiSwatch === s.accent));
  });
  root.querySelectorAll("[data-ui-range]").forEach((node) => {
    const key = node.dataset.uiRange;
    const cfg = RANGES[key];
    const value = s[key];
    if (document.activeElement !== node) node.value = String(value);
    node.style.setProperty("--fill", `${((value - cfg.min) / (cfg.max - cfg.min)) * 100}%`);
    const out = root.querySelector(`[data-ui-out="${key}"]`);
    if (out) out.textContent = cfg.unit(value);
  });
  root.querySelectorAll("[data-ui-switch]").forEach((node) => {
    node.setAttribute("aria-checked", String(Boolean(s[node.dataset.uiSwitch])));
  });
  const color = root.querySelector("[data-ui-color]");
  if (color && document.activeElement !== color) color.value = s.accent;
  const home = root.querySelector("[data-ui-home]");
  if (home && document.activeElement !== home) home.value = s.browser_home;
  const secondary = root.querySelector("[data-ui-secondary]");
  if (secondary && document.activeElement !== secondary) secondary.value = s.secondary_accent || "#bf5af2";
  const css = root.querySelector("[data-ui-css]");
  if (css && document.activeElement !== css) css.value = s.custom_css;
  const note = root.querySelector("[data-ui-perf-note]");
  if (note) {
    note.textContent = s.performance === "auto" ? `Now: ${r.perf}` : "";
    note.style.minWidth = "0";
  }
  const dirty = isDirty();
  const dirtyBadge = root.querySelector("[data-ui-dirty]");
  if (dirtyBadge) dirtyBadge.hidden = !dirty;
  root.querySelectorAll("[data-ui-discard], [data-ui-save]").forEach((node) => {
    node.disabled = !dirty;
  });
  const preview = root.querySelector("[data-ui-preview]");
  if (preview) preview.dataset.blur = String(r.blur);
}

export function bindAppearance(container) {
  const root = container.querySelector("#appearance-card");
  if (!root) return;
  sync(root);

  const change = (patch) => {
    previewUiSettings(patch);
    sync(root);
  };

  root.addEventListener("click", async (event) => {
    const seg = event.target.closest("[data-ui-seg]");
    if (seg) {
      const key = seg.dataset.uiSeg;
      const value = seg.dataset.val;
      change({ [key]: value });
      return;
    }
    const swatch = event.target.closest("[data-ui-swatch]");
    if (swatch) {
      change({ accent: swatch.dataset.uiSwatch });
      return;
    }
    const sw = event.target.closest("[data-ui-switch]");
    if (sw) {
      const key = sw.dataset.uiSwitch;
      change({ [key]: !state.settings[key] });
      return;
    }
    if (event.target.closest("[data-ui-discard]")) {
      previewUiSettings(state.saved);
      sync(root);
      return;
    }
    if (event.target.closest("[data-ui-reset]")) {
      const ok = await ui.confirmDialog({
        title: "Reset appearance?",
        message: "Every setting returns to the factory look for all users immediately.",
        confirmLabel: "Reset",
        danger: true,
      });
      if (!ok) return;
      try {
        await resetUiSettings();
        sync(root);
        ui.notifyOk("Reset", "Factory appearance restored.");
      } catch (err) {
        ui.showError(err, "Could not reset the appearance");
      }
      return;
    }
    if (event.target.closest("[data-ui-save]")) {
      const btn = event.target.closest("[data-ui-save]");
      btn.disabled = true;
      try {
        const patch = { ...state.settings };
        patch.browser_home = patch.browser_home?.trim() || DEFAULTS.browser_home;
        await saveUiSettings(patch);
        sync(root);
        ui.notifyOk("Saved", "The appearance is now active for everyone.");
      } catch (err) {
        ui.showError(err, "Could not save the appearance");
        sync(root);
      }
    }
  });

  root.addEventListener("input", (event) => {
    const range = event.target.closest("[data-ui-range]");
    if (range) {
      const key = range.dataset.uiRange;
      const cfg = RANGES[key];
      const raw = Number(range.value);
      change({ [key]: key === "radius" ? Math.round(raw * 100) / 100 : Math.round(raw) });
      return;
    }
    if (event.target.matches("[data-ui-color]")) {
      change({ accent: event.target.value });
    }
    if (event.target.matches("[data-ui-secondary]")) change({ secondary_accent: event.target.value });
    if (event.target.matches("[data-ui-css]")) change({ custom_css: event.target.value });
  });

  root.addEventListener("change", (event) => {
    if (event.target.matches("[data-ui-home]")) {
      const value = event.target.value.trim();
      change({ browser_home: value || DEFAULTS.browser_home });
    }
  });
}

/** Drop unsaved previews (used when leaving the Settings page). */
export function discardAppearancePreview() {
  if (isDirty()) previewUiSettings(state.saved);
}
