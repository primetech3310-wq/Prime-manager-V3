/**
 * Terminal view — xterm.js attached to a real PTY over an authenticated
 * WebSocket. Sessions live on the server, so navigating away keeps the shell
 * running and coming back re-attaches with scrollback replay.
 *
 * v1.1: fullscreen mode, a tab bar that never overlaps its actions, rename on
 * double-tap / long-press, font size steps, snippet inserter, keyboard
 * shortcuts, jump-to-bottom, copy selection and a clean re-attach (the replay
 * no longer doubles the prompt on reconnect).
 */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc } from "../ui.js";

const TERM_FONT = 'ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace';
const FONT_STEPS = [11.5, 13, 13.5, 15, 17];
const FONT_KEY = "prime-term-font";
const HAPTIC_KEY = "prime-haptics";

function readStore(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : value;
  } catch {
    return fallback;
  }
}

function writeStore(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch { /* private mode */ }
}

const state = {
  sessions: [],
  activeSid: null,
  term: null,
  fit: null,
  ws: null,
  hostEl: null,
  statusEl: null,
  tabsEl: null,
  overlayEl: null,
  resizeObs: null,
  retry: 0,
  reconnectTimer: null,
  ctrlSticky: false,
  altSticky: false,
  pingTimer: null,
  destroyed: false,
  listeners: [],
  mounted: false,
  fullscreen: false,
  fontIndex: 2,
  jumpEl: null,
  pendingSid: null,
};

const THEMES = {
  dark: {
    background: "#0b0d11",
    foreground: "#e7ebf3",
    cursor: "#5b9bff",
    cursorAccent: "#0b0d11",
    selectionBackground: "rgba(91,155,255,0.32)",
    black: "#12141a", red: "#ff6b6b", green: "#4ade80", yellow: "#fbbf24",
    blue: "#5b9bff", magenta: "#c084fc", cyan: "#4dd6e8", white: "#e7ebf3",
    brightBlack: "#6b7280", brightRed: "#ff8787", brightGreen: "#6ee7a0",
    brightYellow: "#fcd34d", brightBlue: "#7fb3ff", brightMagenta: "#d8b4fe",
    brightCyan: "#7ce7f5", brightWhite: "#ffffff",
  },
  light: {
    background: "#ffffff",
    foreground: "#111827",
    cursor: "#0a6cff",
    cursorAccent: "#ffffff",
    selectionBackground: "rgba(10,108,255,0.2)",
    black: "#111827", red: "#c02646", green: "#15803d", yellow: "#a16207",
    blue: "#0a6cff", magenta: "#7c3aed", cyan: "#0e7490", white: "#e5e7eb",
    brightBlack: "#6b7280", brightRed: "#dc2626", brightGreen: "#16a34a",
    brightYellow: "#ca8a04", brightBlue: "#2563eb", brightMagenta: "#9333ea",
    brightCyan: "#0891b2", brightWhite: "#f9fafb",
  },
};

function currentTheme() {
  return document.documentElement.dataset.theme === "light" ? "light" : "dark";
}

function statusPill(kind, text) {
  if (!state.statusEl) return;
  const colors = { live: "var(--ok)", busy: "var(--warn)", down: "var(--danger)", idle: "var(--text-faint)" };
  state.statusEl.innerHTML = `<span class="dot" style="color:${colors[kind] || colors.idle}"></span>
    <span>${esc(text)}</span>`;
}

function termShellHtml() {
  return `
  <div class="term-shell" id="term-shell">
    <div class="term-bar">
      <div class="term-tabs-wrap">
        <div class="term-tabs" id="term-tabs"></div>
      </div>
      <div class="term-actions">
        <button class="icon-btn" id="term-new" title="New session (Ctrl+Shift+T)" aria-label="New session">${icon("plus")}</button>
        <button class="icon-btn" id="term-list" title="Sessions" aria-label="Session manager">${icon("layers")}</button>
        <button class="icon-btn" id="term-snippets" title="Insert snippet" aria-label="Snippets">${icon("bookmark")}</button>
        <button class="icon-btn" id="term-font" title="Text size" aria-label="Text size">${icon("type")}</button>
        <button class="icon-btn" id="term-clear" title="Clear screen" aria-label="Clear screen">${icon("trash")}</button>
        <button class="icon-btn" id="term-keys-toggle" title="Toggle key bar" aria-label="Toggle key bar">${icon("keyboard")}</button>
        <button class="icon-btn" id="term-fullscreen" title="Fullscreen (Ctrl+Shift+F)" aria-label="Fullscreen">${icon("maximize")}</button>
      </div>
    </div>
    <div class="term-stage">
      <div class="term-host" id="term-host"></div>
      <button class="term-jump" id="term-jump" aria-label="Jump to latest output" title="Jump to latest output">${icon("chevronDown")}</button>
      <div class="term-empty" id="term-overlay"></div>
    </div>
    <div class="term-status">
      <span class="row" style="gap:6px" id="term-status"><span class="dot"></span><span>connecting…</span></span>
      <span class="right mono faint" id="term-meta"></span>
    </div>
    <div class="term-keys" id="term-keys"></div>
  </div>`;
}

const KEYS = [
  { id: "esc", label: "Esc", seq: "\u001b" },
  { id: "tab", label: "Tab", seq: "\t" },
  { id: "ctrl", label: "Ctrl", sticky: "ctrl" },
  { id: "alt", label: "Alt", sticky: "alt" },
  { id: "left", label: icon("arrowLeft"), seq: "\u001b[D", raw: true },
  { id: "up", label: icon("arrowUp"), seq: "\u001b[A", raw: true },
  { id: "down", label: icon("arrowDown"), seq: "\u001b[B", raw: true },
  { id: "right", label: icon("arrowRight"), seq: "\u001b[C", raw: true },
  { id: "home", label: "Home", seq: "\u001b[H" },
  { id: "end", label: "End", seq: "\u001b[F" },
  { id: "pgup", label: "PgUp", seq: "\u001b[5~" },
  { id: "pgdn", label: "PgDn", seq: "\u001b[6~" },
  { id: "cc", label: "⌃C", seq: "\u0003" },
  { id: "cd", label: "⌃D", seq: "\u0004" },
  { id: "cz", label: "⌃Z", seq: "\u001a" },
  { id: "cl", label: "⌃L", seq: "\u000c" },
  { id: "pipe", label: "|", seq: "|" },
  { id: "dash", label: "-", seq: "-" },
  { id: "slash", label: "/", seq: "/" },
  { id: "tilde", label: "~", seq: "~" },
  { id: "paste", label: "Paste", paste: true },
  { id: "copysel", label: icon("copy"), raw: true, copy: true },
  { id: "keyboard", label: icon("keyboard"), raw: true, keyboard: true },
];

function renderKeys() {
  const host = document.getElementById("term-keys");
  if (!host) return;
  host.innerHTML = KEYS.map(
    (k) => `<button class="key ${(k.sticky === "ctrl" && state.ctrlSticky) || (k.sticky === "alt" && state.altSticky) ? "on" : ""}"
      data-key="${k.id}" type="button" aria-label="${k.id}">${k.raw ? k.label : esc(k.label)}</button>`,
  ).join("");
}

function haptic(ms = 6) {
  if (readStore(HAPTIC_KEY, "1") !== "1") return;
  try {
    navigator.vibrate?.(ms);
  } catch { /* unsupported */ }
}

function send(data) {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return false;
  state.ws.send(JSON.stringify({ type: "input", data }));
  return true;
}

function sendResize() {
  if (!state.term || !state.ws || state.ws.readyState !== WebSocket.OPEN) return;
  if (state.term.cols < 2 || state.term.rows < 2) return;
  state.ws.send(JSON.stringify({ type: "resize", cols: state.term.cols, rows: state.term.rows }));
  const meta = document.getElementById("term-meta");
  if (meta) meta.textContent = `${state.term.cols}×${state.term.rows}`;
}

function createTerm() {
  const host = state.hostEl;
  if (!host) return null;
  const term = new window.Terminal({
    fontFamily: TERM_FONT,
    fontSize: FONT_STEPS[state.fontIndex],
    lineHeight: 1.25,
    letterSpacing: 0,
    cursorBlink: true,
    cursorStyle: "bar",
    scrollback: 8000,
    allowProposedApi: true,
    theme: THEMES[currentTheme()],
    convertEol: false,
    macOptionIsMeta: true,
    rightClickSelectsWord: true,
    smoothScrollDuration: 0,
    scrollOnUserInput: true,
  });
  const fit = new window.FitAddon.FitAddon();
  term.loadAddon(fit);
  try {
    const unicode = new window.Unicode11Addon.Unicode11Addon();
    term.loadAddon(unicode);
    term.unicode.activeVersion = "11";
  } catch { /* optional */ }
  try {
    term.loadAddon(new window.WebLinksAddon.WebLinksAddon((event, uri) => {
      if (confirm(`Open ${uri} in a new tab?`)) window.open(uri, "_blank", "noopener,noreferrer");
    }));
  } catch { /* optional */ }

  term.open(host);
  term.onData((data) => send(data));
  term.onResize(() => sendResize());
  term.onScroll(() => updateJump());

  // sticky Ctrl/Alt intercept for on-screen keyboards
  const textarea = term.textarea;
  if (textarea) {
    const handler = (event) => {
      if (!state.ctrlSticky && !state.altSticky) return;
      if (event.key.length !== 1) return;
      event.preventDefault();
      event.stopPropagation();
      let payload = event.key;
      if (state.ctrlSticky) {
        const code = event.key.toUpperCase().charCodeAt(0);
        payload = String.fromCharCode(code < 64 ? code & 31 : code);
        state.ctrlSticky = false;
      }
      if (state.altSticky) {
        payload = `\u001b${payload}`;
        state.altSticky = false;
      }
      renderKeys();
      send(payload);
    };
    textarea.addEventListener("keydown", handler, true);
    state.listeners.push(() => textarea.removeEventListener("keydown", handler, true));
  }

  const fitNow = () => {
    try {
      fit.fit();
      sendResize();
    } catch { /* element hidden */ }
  };
  state.resizeObs = new ResizeObserver(() => {
    window.requestAnimationFrame(fitNow);
  });
  state.resizeObs.observe(host);
  setTimeout(fitNow, 30);
  state.fit = fit;
  state.term = term;
  return term;
}

function disposeTerm() {
  if (state.resizeObs) {
    state.resizeObs.disconnect();
    state.resizeObs = null;
  }
  state.listeners.forEach((fn) => {
    try {
      fn();
    } catch { /* ignore */ }
  });
  state.listeners = [];
  if (state.term) {
    try {
      state.term.dispose();
    } catch { /* ignore */ }
    state.term = null;
  }
}

function closeSocket() {
  if (state.reconnectTimer) {
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = null;
  }
  if (state.pingTimer) {
    clearInterval(state.pingTimer);
    state.pingTimer = null;
  }
  if (state.ws) {
    const ws = state.ws;
    state.ws = null;
    try {
      ws.onclose = null;
      ws.onmessage = null;
      ws.onerror = null;
      ws.close();
    } catch { /* ignore */ }
  }
}

function updateJump() {
  const term = state.term;
  const btn = state.jumpEl;
  if (!term || !btn) return;
  const buffer = term.buffer.active;
  btn.classList.toggle("show", buffer.viewportY < buffer.baseY);
}

async function attach(sid) {
  closeSocket();
  state.activeSid = sid;
  state.destroyed = false;
  renderTabs();
  const overlay = document.getElementById("term-overlay");
  if (overlay) {
    overlay.innerHTML = `<div class="inner">
      <div class="spinner"></div>
      <h3>Attaching to session…</h3>
      <p>Connecting to the PTY on the server.</p>
    </div>`;
    overlay.style.display = "grid";
  }
  statusPill("busy", "connecting…");

  let ticket;
  try {
    ticket = (await api.post("/api/auth/ws-ticket")).ticket;
  } catch (err) {
    showOverlayError(ui.errorText(err), true);
    return;
  }
  if (state.destroyed) return;

  const proto = location.protocol === "https:" ? "wss" : "ws";
  const url = `${proto}://${location.host}/api/ws/terminal/${encodeURIComponent(sid)}?ticket=${encodeURIComponent(ticket)}`;
  let ws;
  try {
    ws = new WebSocket(url);
  } catch {
    showOverlayError("Could not open the WebSocket connection.", true);
    return;
  }
  ws.binaryType = "arraybuffer";
  state.ws = ws;

  ws.onopen = () => {
    state.retry = 0;
    statusPill("live", "connected");
    const overlayEl = document.getElementById("term-overlay");
    if (overlayEl) overlayEl.style.display = "none";
    if (state.term) {
      // The server replays the whole buffer right after attaching. Clearing first
      // stops the replay from stacking on top of what is already on screen.
      state.term.reset();
      state.term.focus();
      try {
        state.fit.fit();
      } catch { /* ignore */ }
      sendResize();
    }
    state.pingTimer = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping", t: Date.now() }));
    }, 25000);
  };

  ws.onmessage = (event) => {
    if (typeof event.data === "string") {
      let payload = null;
      try {
        payload = JSON.parse(event.data);
      } catch { /* not JSON, ignore */ }
      if (payload?.type === "error") {
        showOverlayError(payload.message || "Session error", true);
      } else if (payload?.type === "exit") {
        showOverlayError("The shell exited" + (payload.code !== null && payload.code !== undefined
          ? ` (exit code ${payload.code})` : ""), false);
        statusPill("down", `shell exited${payload.code != null ? ` (${payload.code})` : ""}`);
        closeSocket();
      }
      return;
    }
    if (state.term) {
      state.term.write(new Uint8Array(event.data));
      updateJump();
    }
  };

  ws.onclose = (event) => {
    if (state.destroyed) return;
    if (event.code === 4401 || event.code === 4403) {
      showOverlayError("The WebSocket ticket was rejected. Reload the panel to sign in again.", false);
      statusPill("down", "unauthorized");
      return;
    }
    statusPill("down", "disconnected");
    scheduleReconnect(sid);
  };

  ws.onerror = () => {
    statusPill("down", "connection error");
  };
}

function scheduleReconnect(sid) {
  if (state.destroyed) return;
  if (state.retry >= 6) {
    showOverlayError("Could not reconnect to this session.", true);
    return;
  }
  const delay = Math.min(8000, 700 * 2 ** state.retry);
  state.retry += 1;
  statusPill("busy", `reconnecting in ${Math.round(delay / 1000)}s (${state.retry}/6)`);
  const overlay = document.getElementById("term-overlay");
  if (overlay && state.term) overlay.style.display = "none";
  state.reconnectTimer = setTimeout(() => {
    if (!state.destroyed) attach(sid);
  }, delay);
}

function showOverlayError(message, retryable) {
  const overlay = document.getElementById("term-overlay");
  if (!overlay) return;
  overlay.style.display = "grid";
  overlay.innerHTML = `<div class="inner">
    ${icon("alert", 28)}
    <h3>Terminal disconnected</h3>
    <p>${esc(message)}</p>
    <div class="row" style="gap:10px;justify-content:center;flex-wrap:wrap">
      ${retryable ? `<button class="btn btn-sm" id="term-retry">${icon("refresh")}Retry</button>` : ""}
      <button class="btn btn-sm btn-primary" id="term-new-overlay">${icon("plus")}New session</button>
    </div>
  </div>`;
  const retryBtn = document.getElementById("term-retry");
  if (retryBtn) {
    retryBtn.addEventListener("click", () => {
      state.retry = 0;
      attach(state.activeSid);
    });
  }
  const newBtn = document.getElementById("term-new-overlay");
  if (newBtn) newBtn.addEventListener("click", newSession);
}

function renderTabs() {
  const host = document.getElementById("term-tabs");
  if (!host) return;
  host.innerHTML = state.sessions
    .map(
      (s, index) => `<button class="term-tab ${s.id === state.activeSid ? "active" : ""} ${s.alive ? "alive" : ""}"
        data-sid="${esc(s.id)}" type="button" title="${esc(s.title)} — ${esc(s.cwd)} (Alt+${index + 1})">
        <span class="dot"></span><span class="truncate">${esc(s.title)}</span>
      </button>`,
    )
    .join("");
  const active = host.querySelector(".term-tab.active");
  if (active) active.scrollIntoView({ block: "nearest", inline: "nearest" });
  const meta = document.getElementById("term-meta");
  if (meta) {
    const current = state.sessions.find((s) => s.id === state.activeSid);
    if (current) meta.textContent = `${current.cols}×${current.rows} · pid ${current.pid}`;
  }
}

async function loadSessions() {
  const data = await api.get("/api/terminal/sessions");
  state.sessions = data.items;
  renderTabs();
  return data;
}

async function newSession() {
  try {
    const term = state.term;
    // xterm can briefly report 0/1 cols while the host is still laying out
    // (common on phones); the server requires >= 2, so fall back to defaults.
    const cols = term && term.cols >= 2 ? term.cols : 80;
    const rows = term && term.rows >= 2 ? term.rows : 24;
    const created = await api.post("/api/terminal/sessions", { cols, rows });
    await loadSessions();
    await attach(created.id);
    ui.notifyOk("Session started", `${created.shell} · pid ${created.pid}`);
  } catch (err) {
    ui.showError(err, "Could not start a session");
  }
}

async function closeSession(sid) {
  if (!sid) return;
  try {
    await api.del(`/api/terminal/sessions/${encodeURIComponent(sid)}`);
    if (sid === state.activeSid) {
      closeSocket();
      state.activeSid = null;
    }
    await loadSessions();
    if (!state.sessions.length) {
      newSession();
    } else if (!state.activeSid) {
      attach(state.sessions[0].id);
    } else {
      renderTabs();
    }
  } catch (err) {
    ui.showError(err, "Could not close the session");
  }
}

async function renameSession(sid) {
  const current = state.sessions.find((s) => s.id === sid);
  if (!current) return;
  const title = await ui.promptDialog({
    title: "Rename session",
    subtitle: current.cwd,
    label: "Session name",
    value: current.title,
    placeholder: "e.g. deploy, logs, db",
    confirmLabel: "Rename",
  });
  if (!title || !title.trim() || title.trim() === current.title) return;
  try {
    await api.post(`/api/terminal/sessions/${encodeURIComponent(sid)}/rename`, {}, { title: title.trim().slice(0, 60) });
    await loadSessions();
  } catch (err) {
    ui.showError(err, "Could not rename the session");
  }
}

function openSessionManager() {
  const rows = state.sessions
    .map(
      (s) => `<div class="list-row" data-attach="${esc(s.id)}" role="button" tabindex="0">
        <span class="lead">${icon("terminalSquare")}</span>
        <span class="grow truncate">
          <span class="title truncate">${esc(s.title)} ${s.id === state.activeSid ? '<span class="badge accent">attached</span>' : ""}</span>
          <span class="meta"><span class="mono">${esc(s.id)}</span><span>pid ${s.pid}</span><span>${esc(s.cwd)}</span>
          <span>${s.alive ? "running" : "exited"}</span></span>
        </span>
        <button class="icon-btn" data-rename-sid="${esc(s.id)}" aria-label="Rename session" title="Rename">${icon("edit")}</button>
        <button class="icon-btn" data-close-sid="${esc(s.id)}" aria-label="Close session"
          title="Close session">${icon("x")}</button>
      </div>`,
    )
    .join("");
  const content = `<div class="stack">
      <div class="list">${rows || ui.emptyState("No sessions yet", "terminalSquare")}</div>
      <div class="notice info">${icon("info")}<div>Sessions stay alive on the server for a while after you
      disconnect, so you can re-attach from another device or browser tab.</div></div>
    </div>`;
  const s = ui.sheet({
    title: "Terminal sessions",
    subtitle: `${state.sessions.length} active on this server`,
    content,
    actions: [{ label: "New session", kind: "primary", icon: "plus", onClick: () => newSession() }],
  });
  s.card.addEventListener("click", (event) => {
    const closeBtn = event.target.closest("[data-close-sid]");
    if (closeBtn) {
      event.stopPropagation();
      closeSession(closeBtn.dataset.closeSid);
      ui.closeSheet(s);
      return;
    }
    const renameBtn = event.target.closest("[data-rename-sid]");
    if (renameBtn) {
      event.stopPropagation();
      renameSession(renameBtn.dataset.renameSid);
      return;
    }
    const row = event.target.closest("[data-attach]");
    if (row) {
      ui.closeSheet(s);
      attach(row.dataset.attach);
    }
  });
}

async function openSnippets() {
  let items = [];
  try {
    items = (await api.get("/api/toolkit/snippets")).items || [];
  } catch (err) {
    ui.showError(err, "Could not load snippets");
    return;
  }
  const rows = items
    .map(
      (snip, index) => `<div class="list-row snippet-row">
        <span class="lead">${icon("bookmark")}</span>
        <span class="grow" style="min-width:0">
          <span class="title truncate">${esc(snip.title)}</span>
          <span class="meta"><span class="mono truncate">${esc(snip.command)}</span></span>
        </span>
        <button class="btn btn-sm" data-snip-insert="${index}" title="Type it without pressing Enter">Insert</button>
        <button class="btn btn-sm btn-primary" data-snip-run="${index}" title="Type it and press Enter">${icon("play")}Run</button>
      </div>`,
    )
    .join("");
  const s = ui.sheet({
    title: "Snippets",
    subtitle: items.length ? "Insert or run a saved command in the active shell" : "Your saved commands",
    content: `<div class="stack">${rows || ui.emptyState("No snippets yet. Save commands in Toolkit and they appear here.", "bookmark")}</div>`,
  });
  s.card.addEventListener("click", (event) => {
    const insert = event.target.closest("[data-snip-insert]");
    const run = event.target.closest("[data-snip-run]");
    const target = insert || run;
    if (!target) return;
    const snip = items[Number(target.dataset.snipInsert ?? target.dataset.snipRun)];
    if (!snip) return;
    const text = snip.command.replace(/\r?\n+$/, "");
    send(run ? `${text}\r` : text);
    haptic(run ? 12 : 6);
    ui.closeSheet(s);
    state.term?.focus();
  });
}

function cycleFont() {
  state.fontIndex = (state.fontIndex + 1) % FONT_STEPS.length;
  writeStore(FONT_KEY, String(state.fontIndex));
  applyFont();
  ui.notifyInfo("Text size", `${FONT_STEPS[state.fontIndex]} px`);
}

function applyFont() {
  if (!state.term) return;
  state.term.options.fontSize = FONT_STEPS[state.fontIndex];
  const button = document.getElementById("term-font");
  if (button) button.title = `Text size ${FONT_STEPS[state.fontIndex]} px (tap to change)`;
  setTimeout(() => {
    try {
      state.fit?.fit();
      sendResize();
    } catch { /* ignore */ }
  }, 20);
}

function copySelection() {
  const text = state.term?.getSelection?.() || "";
  if (!text) {
    ui.notifyWarn("Nothing selected", "Select text in the terminal first (long-press on touch screens).");
    return;
  }
  navigator.clipboard.writeText(text)
    .then(() => ui.notifyOk("Copied", `${text.length} characters`))
    .catch(() => ui.notifyWarn("Clipboard blocked", "Your browser did not allow clipboard access."));
}

function setFullscreen(on, native = true) {
  state.fullscreen = on;
  const shell = document.getElementById("term-shell");
  if (shell) shell.classList.toggle("is-fullscreen", on);
  document.body.classList.toggle("immersive", on);
  const button = document.getElementById("term-fullscreen");
  if (button) {
    button.innerHTML = icon(on ? "minimize" : "maximize");
    button.title = on ? "Exit fullscreen" : "Fullscreen (Ctrl+Shift+F)";
    button.setAttribute("aria-label", on ? "Exit fullscreen" : "Fullscreen");
  }
  try {
    if (native && on && shell && !document.fullscreenElement) {
      const request = shell.requestFullscreen || shell.webkitRequestFullscreen;
      const result = request ? request.call(shell) : null;
      if (result && typeof result.catch === "function") result.catch(() => {});
    } else if (!on && document.fullscreenElement) {
      const result = document.exitFullscreen?.();
      if (result && typeof result.catch === "function") result.catch(() => {});
    }
  } catch { /* the CSS fullscreen still applies */ }
  setTimeout(() => {
    try {
      state.fit?.fit();
      sendResize();
      state.term?.focus();
    } catch { /* ignore */ }
  }, 150);
}

function onFullscreenChange() {
  // the user left native fullscreen with a system gesture: keep the UI in sync
  if (!document.fullscreenElement && state.fullscreen) setFullscreen(false);
}

function onShortcut(event) {
  if (!state.mounted) return;
  const key = (event.key || "").toLowerCase();
  if (event.ctrlKey && event.shiftKey && !event.altKey) {
    if (key === "t") {
      event.preventDefault();
      event.stopPropagation();
      newSession();
    } else if (key === "w") {
      event.preventDefault();
      event.stopPropagation();
      closeSession(state.activeSid);
    } else if (key === "f") {
      event.preventDefault();
      event.stopPropagation();
      setFullscreen(!state.fullscreen);
    } else if (key === "c" && state.term?.hasSelection()) {
      event.preventDefault();
      event.stopPropagation();
      copySelection();
    }
    return;
  }
  if (event.altKey && !event.ctrlKey && /^[1-9]$/.test(event.key)) {
    const target = state.sessions[Number(event.key) - 1];
    if (target) {
      event.preventDefault();
      event.stopPropagation();
      if (target.id !== state.activeSid) attach(target.id);
    }
  }
}

function wireTabs() {
  const host = document.getElementById("term-tabs");
  if (!host) return;
  let pressTimer = null;
  let suppressClick = false;
  const clearPress = () => {
    if (pressTimer) clearTimeout(pressTimer);
    pressTimer = null;
  };
  host.addEventListener("click", (event) => {
    if (suppressClick) {
      suppressClick = false;
      return;
    }
    const tab = event.target.closest("[data-sid]");
    if (tab && tab.dataset.sid !== state.activeSid) attach(tab.dataset.sid);
  });
  host.addEventListener("dblclick", (event) => {
    const tab = event.target.closest("[data-sid]");
    if (tab) renameSession(tab.dataset.sid);
  });
  host.addEventListener("pointerdown", (event) => {
    const tab = event.target.closest("[data-sid]");
    if (!tab || event.pointerType === "mouse") return;
    clearPress();
    pressTimer = setTimeout(() => {
      suppressClick = true;
      haptic(15);
      renameSession(tab.dataset.sid);
    }, 550);
  });
  ["pointerup", "pointerleave", "pointercancel", "pointermove"].forEach((name) => {
    host.addEventListener(name, clearPress);
  });
}

function applyTermTheme() {
  if (!state.term) return;
  state.term.options.theme = THEMES[currentTheme()];
  const stage = document.querySelector(".term-stage");
  if (stage) stage.style.setProperty("--term-bg", THEMES[currentTheme()].background);
}

function wireKeyBar() {
  const host = document.getElementById("term-keys");
  if (!host) return;
  host.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-key]");
    if (!button) return;
    const spec = KEYS.find((k) => k.id === button.dataset.key);
    if (!spec) return;
    haptic();
    if (spec.sticky === "ctrl") {
      state.ctrlSticky = !state.ctrlSticky;
      state.altSticky = false;
      renderKeys();
      state.term?.focus();
      return;
    }
    if (spec.sticky === "alt") {
      state.altSticky = !state.altSticky;
      state.ctrlSticky = false;
      renderKeys();
      state.term?.focus();
      return;
    }
    if (spec.copy) {
      copySelection();
      return;
    }
    if (spec.paste) {
      try {
        const text = await navigator.clipboard.readText();
        if (text) send(text);
      } catch {
        ui.notifyWarn("Clipboard blocked", "Long-press the terminal and paste instead.");
      }
      return;
    }
    if (spec.keyboard) {
      state.term?.focus();
      state.term?.textarea?.focus();
      return;
    }
    if (spec.seq) {
      send(spec.seq);
      state.term?.focus();
    }
  });
}

export default {
  title: "Terminal",
  crumb: "real PTY over WebSocket",
  noPad: true,
  async mount(container, ctx) {
    state.destroyed = false;
    state.mounted = true;
    state.fontIndex = Math.min(FONT_STEPS.length - 1, Math.max(0, Number(readStore(FONT_KEY, "2")) || 2));
    state.pendingSid = ctx?.params?.get?.("sid") || null;
    container.innerHTML = `<div class="view-enter" style="height:100%">${termShellHtml()}</div>`;
    state.hostEl = document.getElementById("term-host");
    state.statusEl = document.getElementById("term-status");
    state.jumpEl = document.getElementById("term-jump");

    if (!window.Terminal) {
      container.innerHTML = `<div class="card" style="margin:20px">${ui.emptyState(
        "xterm.js failed to load from /static/vendor.", "alert")}</div>`;
      return;
    }
    renderKeys();
    wireKeyBar();
    wireTabs();
    const term = createTerm();
    if (term) {
      applyTermTheme();
      applyFont();
      term.writeln("\x1b[38;5;244mPRIME TERMINAL MANAGER — connecting to the server…\x1b[0m");
    }

    document.getElementById("term-new").addEventListener("click", newSession);
    document.getElementById("term-list").addEventListener("click", openSessionManager);
    document.getElementById("term-snippets").addEventListener("click", openSnippets);
    document.getElementById("term-font").addEventListener("click", cycleFont);
    document.getElementById("term-fullscreen").addEventListener("click", () => setFullscreen(!state.fullscreen));
    document.getElementById("term-jump").addEventListener("click", () => {
      state.term?.scrollToBottom();
      state.term?.focus();
      updateJump();
    });
    document.getElementById("term-clear").addEventListener("click", () => {
      if (state.term) {
        state.term.clear();
        state.term.write("\x1b[2J\x1b[H");
      }
    });
    document.getElementById("term-keys-toggle").addEventListener("click", () => {
      const keys = document.getElementById("term-keys");
      keys.style.display = keys.style.display === "none" ? "flex" : "none";
      setTimeout(() => {
        try {
          state.fit?.fit();
        } catch { /* ignore */ }
      }, 60);
    });

    this._themeObserver = new MutationObserver(applyTermTheme);
    this._themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    this._onShortcut = onShortcut;
    this._onFsChange = onFullscreenChange;
    window.addEventListener("keydown", this._onShortcut, true);
    document.addEventListener("fullscreenchange", this._onFsChange);
    if (window.__PRIME_WORKSPACE__) setFullscreen(true, false);

    try {
      const data = await loadSessions();
      if (state.destroyed) return;
      if (data.items.length) {
        const wanted = data.items.find((s) => s.id === state.pendingSid);
        const preferred = wanted || data.items.find((s) => s.alive) || data.items[0];
        await attach(preferred.id);
      } else {
        await newSession();
      }
    } catch (err) {
      showOverlayError(ui.errorText(err), true);
    }
  },
  onParams(params) {
    const sid = params?.get?.("sid");
    if (sid && sid !== state.activeSid && state.sessions.some((s) => s.id === sid)) attach(sid);
  },
  unmount() {
    state.destroyed = true;
    state.mounted = false;
    if (this._themeObserver) this._themeObserver.disconnect();
    if (this._onShortcut) window.removeEventListener("keydown", this._onShortcut, true);
    if (this._onFsChange) document.removeEventListener("fullscreenchange", this._onFsChange);
    if (state.fullscreen) setFullscreen(false);
    document.body.classList.remove("immersive");
    closeSocket();
    disposeTerm();
    state.sessions = [];
    state.activeSid = null;
    state.jumpEl = null;
  },
};
