/**
 * Public — expose local ports through Cloudflare quick tunnels and keep every
 * link (ports and terminal sessions) in one place: copy, share, open in the
 * browser, or open inside the PRIME viewer.
 */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, copyText, timestamp, duration } from "../ui.js";
import { openViewer } from "../viewer.js";

const REFRESH_MS = 4000;

const state = {
  tab: "ports",
  status: null,
  sessions: [],
  timer: null,
  root: null,
  busy: new Set(),
  onChanged: null,
};

/* --------------------------------------------------------------- helpers ---
 * Shared with the Processes view: publish a port with a progress sheet. */
export async function publishPort(port, { label = "" } = {}) {
  const sheet = ui.sheet({
    title: `Making port ${port} public`,
    subtitle: "Cloudflare quick tunnel",
    content: `<div class="publish-progress">
        <div class="pp-spin"><span class="spinner"></span></div>
        <ol class="pp-steps">
          <li>Checking for cloudflared (installs it on first use)</li>
          <li>Starting the tunnel to 127.0.0.1:${Number(port)}</li>
          <li>Waiting for a public address (usually 5–30 seconds)</li>
        </ol>
      </div>`,
  });
  try {
    const res = await api.post("/api/public/links", { port: Number(port), label });
    ui.closeSheet(sheet);
    ui.notifyOk(`Port ${port} is public`, res.item.url);
    window.dispatchEvent(new CustomEvent("prime:public-changed"));
    return res.item;
  } catch (err) {
    ui.closeSheet(sheet);
    ui.showError(err, `Port ${port} could not be published`);
    return null;
  }
}

async function withBusy(key, button, label, fn) {
  if (state.busy.has(key)) return null;
  state.busy.add(key);
  const original = button ? button.innerHTML : "";
  if (button) {
    button.disabled = true;
    button.innerHTML = `<span class="spinner"></span>${esc(label)}`;
  }
  try {
    return await fn();
  } catch (err) {
    ui.showError(err, "Action failed");
    return null;
  } finally {
    state.busy.delete(key);
    if (button && button.isConnected) {
      button.disabled = false;
      button.innerHTML = original;
    }
  }
}

function liveLinks() {
  return (state.status?.items || [])
    .filter((item) => item.status === "live" && item.url)
    .map((item) => ({ url: item.url, label: item.label || `Port ${item.port}` }));
}

function statusMeta(item) {
  switch (item.status) {
    case "live": return { text: "Live", tone: "ok" };
    case "starting": return { text: "Starting…", tone: "warn" };
    case "error": return { text: "Error", tone: "danger" };
    default: return { text: "Stopped", tone: "idle" };
  }
}

/* ------------------------------------------------------------- renderers --- */
function installBanner() {
  const s = state.status;
  if (!s) return "";
  if (s.installed) {
    return `<div class="pub-meta">
      <span class="chip ok">${icon("check")}cloudflared ${esc((s.version || "ready").replace(/^cloudflared\s*(version\s*)?/i, ""))}</span>
      <span class="faint" style="font-size:12px">Quick tunnels need no account. Links are random and change when a tunnel restarts.</span>
    </div>`;
  }
  return `<div class="notice info">${icon("info")}<div>
      <b>cloudflared is not installed yet.</b> It downloads automatically the first time you publish a port.
      <div style="margin-top:8px"><button class="btn btn-sm" id="pub-install">${icon("download")}Install now</button></div>
    </div></div>`;
}

function linkCard(item) {
  const meta = statusMeta(item);
  const label = item.label || `Port ${item.port}`;
  const live = item.status === "live" && item.url;
  const running = item.status === "live";
  const closedWarn = running && !item.port_open
    ? `<div class="notice warn" style="margin-top:10px">${icon("alert")}<div>Nothing is listening on port ${item.port} right now. Start your service again.</div></div>`
    : "";
  const errorLine = item.status === "error" && item.error
    ? `<div class="notice danger" style="margin-top:10px">${icon("alert")}<div>${esc(item.error)}</div></div>`
    : "";
  const starting = item.status === "starting"
    ? `<div class="faint" style="font-size:12.5px;margin-top:6px"><span class="spinner" style="width:12px;height:12px;vertical-align:-2px"></span>&nbsp;${esc(item.error || "Asking Cloudflare for an address…")}</div>`
    : "";
  return `<article class="plink tone-${meta.tone}" data-id="${esc(item.id)}">
    <header class="plink-head">
      <span class="plink-dot"></span>
      <div class="grow" style="min-width:0">
        <div class="plink-title truncate">${esc(label)}</div>
        <div class="plink-sub"><span class="mono">:${item.port}</span><span>${meta.text}</span>
          ${running && item.uptime ? `<span>up ${duration(item.uptime)}</span>` : ""}
          ${item.restarts ? `<span>${item.restarts} auto-restart${item.restarts > 1 ? "s" : ""}</span>` : ""}
          <span>${item.created ? timestamp(item.created) : ""}</span></div>
      </div>
      <span class="plink-state tone-${meta.tone}">${meta.text}</span>
    </header>
    ${live ? `<div class="plink-url mono truncate" title="${esc(item.url)}">${esc(item.url)}</div>` : starting}
    ${closedWarn}${errorLine}
    <footer class="plink-actions">
      ${live ? `
        <button class="pbtn" data-act="copy" data-url="${esc(item.url)}" title="Copy link">${icon("copy")}<span>Copy</span></button>
        <button class="pbtn" data-act="share" data-url="${esc(item.url)}" title="Share">${icon("share")}<span>Share</span></button>
        <button class="pbtn" data-act="open" data-url="${esc(item.url)}" title="Open in browser">${icon("external")}<span>Browser</span></button>
        <button class="pbtn primary" data-act="viewer" data-id="${esc(item.id)}" title="Open inside PRIME">${icon("maximize")}<span>Open in PRIME</span></button>` : ""}
      ${running && !live ? "" : ""}
      ${item.status === "stopped" || item.status === "error" ? `
        <button class="pbtn primary" data-act="restart" data-id="${esc(item.id)}">${icon("refresh")}<span>Start again</span></button>` : ""}
      ${item.status === "live" || item.status === "starting" ? `
        <button class="pbtn" data-act="restart" data-id="${esc(item.id)}" title="New address">${icon("refresh")}<span>Restart</span></button>
        <button class="pbtn danger" data-act="stop" data-id="${esc(item.id)}">${icon("power")}<span>Stop</span></button>` : ""}
      <button class="pbtn ghost" data-act="remove" data-id="${esc(item.id)}" title="Remove from list">${icon("trash")}</button>
    </footer>
  </article>`;
}

function portsList() {
  const items = state.status?.items || [];
  if (!state.status) return `<div class="skeleton" style="height:120px"></div>`;
  if (!items.length) {
    return `<div class="pub-empty">
      ${icon("globe", 34)}
      <h3>No public links yet</h3>
      <p>Tap <b>Make public</b> next to a listening port in <b>Processes → Listening ports</b>, or publish a port below.</p>
    </div>`;
  }
  return items.map(linkCard).join("");
}

function sessionsList() {
  if (!state.sessions.length) {
    return `<div class="pub-empty">${icon("terminalSquare", 34)}<h3>No terminal sessions</h3>
      <p>Start a session in the Terminal and it appears here with a link you can open or copy.</p></div>`;
  }
  return state.sessions.map((s) => `<article class="plink tone-${s.alive ? "ok" : "idle"}">
    <header class="plink-head">
      <span class="plink-dot"></span>
      <div class="grow" style="min-width:0">
        <div class="plink-title truncate">${esc(s.title)}</div>
        <div class="plink-sub"><span class="mono">pid ${s.pid}</span><span class="truncate">${esc(s.cwd)}</span></div>
      </div>
      <span class="plink-state tone-${s.alive ? "ok" : "idle"}">${s.alive ? "Running" : "Exited"}</span>
    </header>
    <div class="plink-url mono truncate">${esc(`${location.origin}/#/terminal?sid=${s.id}`)}</div>
    <footer class="plink-actions">
      <button class="pbtn primary" data-act="open-session" data-sid="${esc(s.id)}">${icon("terminalSquare")}<span>Open session</span></button>
      <button class="pbtn" data-act="copy-session" data-sid="${esc(s.id)}">${icon("copy")}<span>Copy link</span></button>
      <button class="pbtn" data-act="share-session" data-sid="${esc(s.id)}">${icon("share")}<span>Share</span></button>
    </footer>
  </article>`).join("");
}

function publishForm() {
  return `<form class="pub-form" id="pub-form" autocomplete="off">
    <input class="input" id="pub-port" type="number" inputmode="numeric" min="1" max="65535"
      placeholder="Port, e.g. 3000" required>
    <input class="input" id="pub-label" maxlength="60" placeholder="Name (optional)">
    <button class="btn btn-primary" type="submit">${icon("globe")}Publish port</button>
  </form>`;
}

function shell() {
  const count = state.status?.items?.length ?? 0;
  const sessionCount = state.sessions.length;
  return `<div class="view-enter public-root">
    <div class="card pub-hero">
      <div class="pub-hero-head">
        <div>
          <h2>Public links</h2>
          <p>Publish a local port with one tap and share it, or open it inside PRIME.</p>
          <p class="pub-warn">Anyone with a link can reach that port. Only publish services that have their own login.</p>
        </div>
        <span class="pub-hero-orb">${icon("globe", 26)}</span>
      </div>
      <div id="pub-banner">${installBanner()}</div>
      ${publishForm()}
    </div>
    <div class="tabs pub-tabs" id="pub-tabs">
      <button class="tab ${state.tab === "ports" ? "active" : ""}" data-tab="ports">Public ports (${count})</button>
      <button class="tab ${state.tab === "sessions" ? "active" : ""}" data-tab="sessions">Sessions (${sessionCount})</button>
    </div>
    <div id="pub-list" class="pub-list">${state.tab === "ports" ? portsList() : sessionsList()}</div>
  </div>`;
}

function paintList() {
  const list = document.getElementById("pub-list");
  if (!list) return;
  list.innerHTML = state.tab === "ports" ? portsList() : sessionsList();
  const tabs = document.getElementById("pub-tabs");
  if (tabs) {
    tabs.innerHTML = `
      <button class="tab ${state.tab === "ports" ? "active" : ""}" data-tab="ports">Public ports (${state.status?.items?.length ?? 0})</button>
      <button class="tab ${state.tab === "sessions" ? "active" : ""}" data-tab="sessions">Sessions (${state.sessions.length})</button>`;
  }
  const banner = document.getElementById("pub-banner");
  if (banner) banner.innerHTML = installBanner();
}

/* ------------------------------------------------------------ data flow --- */
async function refresh() {
  try {
    const [status, sessions] = await Promise.all([
      api.get("/api/public/status"),
      api.get("/api/terminal/sessions").catch(() => ({ items: state.sessions })),
    ]);
    state.status = status;
    state.sessions = sessions.items || [];
    paintList();
  } catch (err) {
    if (!state.status) {
      const list = document.getElementById("pub-list");
      if (list) list.innerHTML = `<div class="pub-empty">${icon("alert", 30)}<h3>Could not load links</h3><p>${esc(ui.errorText(err))}</p></div>`;
    }
  }
}

async function install(button) {
  await withBusy("install", button, "Installing…", async () => {
    await api.post("/api/public/install");
    ui.notifyOk("cloudflared ready", "Public links can now be created.");
    await refresh();
  });
}

async function act(name, id, button, dataset) {
  if (name === "copy") {
    await copyText(dataset.url);
    ui.notifyOk("Link copied", dataset.url);
    return;
  }
  if (name === "share") {
    if (navigator.share) {
      try {
        await navigator.share({ title: "PRIME public link", url: dataset.url });
      } catch { /* cancelled */ }
    } else {
      await copyText(dataset.url);
      ui.notifyOk("Link copied", "Sharing is not available here, so the link was copied.");
    }
    return;
  }
  if (name === "open") {
    window.open(dataset.url, "_blank", "noopener,noreferrer");
    return;
  }
  if (name === "viewer") {
    const item = (state.status?.items || []).find((i) => i.id === id);
    if (!item?.url) return;
    openViewer({ url: item.url, label: item.label || `Port ${item.port}`, list: liveLinks });
    return;
  }
  if (name === "open-session") {
    location.hash = `#/terminal?sid=${encodeURIComponent(dataset.sid)}`;
    return;
  }
  if (name === "copy-session" || name === "share-session") {
    const link = `${location.origin}/#/terminal?sid=${dataset.sid}`;
    if (name === "share-session" && navigator.share) {
      try {
        await navigator.share({ title: "PRIME terminal session", url: link });
      } catch { /* cancelled */ }
    } else {
      await copyText(link);
      ui.notifyOk("Panel link copied", "Opening it signs you in first, then attaches to the session.");
    }
    return;
  }
  if (name === "restart") {
    await withBusy(`restart-${id}`, button, "Restarting…", async () => {
      const res = await api.post(`/api/public/links/${encodeURIComponent(id)}/restart`);
      ui.notifyOk("Link restarted", res.item?.url || "");
      await refresh();
    });
    return;
  }
  if (name === "stop") {
    const ok = await ui.confirmDialog({
      title: "Stop this public link?",
      message: "The address stops working straight away. You can start it again later and it will get a new address.",
      confirmLabel: "Stop link",
      danger: true,
    });
    if (!ok) return;
    await withBusy(`stop-${id}`, button, "Stopping…", async () => {
      await api.post(`/api/public/links/${encodeURIComponent(id)}/stop`);
      ui.notifyOk("Public link stopped", "The port is no longer reachable from the internet.");
      await refresh();
    });
    return;
  }
  if (name === "remove") {
    const ok = await ui.confirmDialog({
      title: "Remove from the list?",
      message: "Any running tunnel for this link is stopped too.",
      confirmLabel: "Remove",
      danger: true,
    });
    if (!ok) return;
    await withBusy(`remove-${id}`, button, "Removing…", async () => {
      await api.del(`/api/public/links/${encodeURIComponent(id)}`);
      await refresh();
    });
  }
}

export default {
  title: "Public",
  crumb: "share local ports and sessions",
  mount(container, ctx) {
    state.ctx = ctx;
    state.tab = "ports";
    container.innerHTML = shell();
    const root = container.querySelector(".public-root");
    state.root = root;

    root.addEventListener("click", async (event) => {
      const tab = event.target.closest("[data-tab]");
      if (tab) {
        state.tab = tab.dataset.tab;
        paintList();
        return;
      }
      if (event.target.closest("#pub-install")) {
        await install(event.target.closest("#pub-install"));
        return;
      }
      const btn = event.target.closest("[data-act]");
      if (!btn) return;
      await act(btn.dataset.act, btn.dataset.id, btn, btn.dataset);
    });

    root.addEventListener("submit", async (event) => {
      if (event.target.id !== "pub-form") return;
      event.preventDefault();
      const port = Number(root.querySelector("#pub-port").value);
      const label = root.querySelector("#pub-label").value.trim();
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        ui.notifyWarn("Enter a port", "Use a number between 1 and 65535.");
        return;
      }
      const item = await publishPort(port, { label });
      if (item) {
        root.querySelector("#pub-port").value = "";
        root.querySelector("#pub-label").value = "";
        state.tab = "ports";
        await refresh();
      }
    });

    state.onChanged = () => refresh();
    window.addEventListener("prime:public-changed", state.onChanged);
    refresh();
    state.timer = setInterval(refresh, REFRESH_MS);
  },
  unmount() {
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
    if (state.onChanged) window.removeEventListener("prime:public-changed", state.onChanged);
    state.onChanged = null;
    state.status = null;
    state.root = null;
  },
};
