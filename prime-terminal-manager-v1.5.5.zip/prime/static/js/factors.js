import {api} from './api.js';
import * as ui from './ui.js';
import {esc} from './ui.js';
export async function manageFactors(){
 try{
  const status=await api.get('/api/auth/totp');
  const password=await ui.promptDialog({title:status.enabled?'Disable two-factor authentication':'Enable two-factor authentication',label:'Current password',type:'password'});
  if(!password)return;
  if(status.enabled){
   const code=await ui.promptDialog({title:'Confirm removal',label:'Authenticator or recovery code'});if(!code)return;
   await api.post('/api/auth/totp/disable',{password,code});ui.notifyOk('Two-factor authentication disabled');return;
  }
  const result=await api.post('/api/auth/totp/begin',{password});
  ui.sheet({title:'Add to your authenticator',content:`<p>Enter this secret in your authenticator app (TOTP, 6 digits, 30 seconds). Then enter its code below.</p><textarea class="input mono" readonly>${esc(result.secret)}</textarea><label class="field">Authenticator code<input class="input" data-code inputmode="numeric" autocomplete="one-time-code"></label>`,actions:[{label:'Verify',kind:'primary',close:false,onClick:async({sheet,close})=>{
   try{const confirmed=await api.post('/api/auth/totp/confirm',{password,code:sheet.body.querySelector('[data-code]').value});close();ui.sheet({title:'Save your recovery codes',content:`<p>Two-factor authentication is enabled. Each recovery code works once. Keep these offline; they will not be shown again.</p><textarea class="input mono" readonly rows="10">${confirmed.codes.map(esc).join('\n')}</textarea>`});}catch(e){ui.showError(e);}
  }}]});
 }catch(e){ui.showError(e);}
}
