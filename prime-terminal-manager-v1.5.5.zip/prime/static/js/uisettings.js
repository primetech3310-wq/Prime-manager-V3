/**
 * Appearance settings: the admin's values from the server, a local cache for an
 * instant first paint, and one function that applies them to <html>.
 *
 * Everything visual reads the result through CSS custom properties and data-*
 * attributes, so this module is the only place that maps settings to the page.
 */
import { api } from "./api.js";

export const DEFAULTS = Object.freeze({
  theme: "dark",
  accent: "#0a84ff",
  glass_blur: 30,
  radius: 1,
  motion: "full",
  ambient: true,
  performance: "auto",
  browser_enabled: true,
  browser_home: "https://duckduckgo.com/",
  secondary_accent: "",
  ambient_opacity: 100, ambient_speed: 100, ambient_size: 100,
  glass_saturation: 175, sidebar_width: 248, topbar_height: 62,
  mobilebar_height: 64, font_size: 15, button_radius: 14,
  orb_one: true, orb_two: true, orb_three: true, custom_css: "",
});

const CACHE_KEY = "prime-ui-cache-v2";
const META_COLORS = { dark: "#050608", light: "#eef1f8" };

/** `settings` is what the page shows (may include unsaved preview values); `saved` is the server copy. */
export const state = {
  settings: { ...DEFAULTS },
  saved: { ...DEFAULTS },
  listeners: new Set(),
};

function clean(raw) {
  const out = { ...DEFAULTS };
  if (!raw || typeof raw !== "object") return out;
  Object.keys(DEFAULTS).forEach((key) => {
    if (raw[key] !== undefined && typeof raw[key] === typeof DEFAULTS[key]) out[key] = raw[key];
  });
  return out;
}

function readCache() {
  try {
    return clean(JSON.parse(localStorage.getItem(CACHE_KEY) || "null"));
  } catch {
    return { ...DEFAULTS };
  }
}

function writeCache(settings) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(settings));
  } catch { /* private mode: the server copy still applies on the next load */ }
}

export function hexToRgb(hex) {
  const n = parseInt(String(hex).slice(1), 16);
  if (Number.isNaN(n)) return "10 132 255";
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

/** Low-power devices default to the performance profile (no blur). */
export function isLowEnd() {
  const cores = navigator.hardwareConcurrency || 8;
  const memory = navigator.deviceMemory || 8;
  return cores <= 4 || memory <= 4;
}

/** Resolve "auto" choices against the device so the page sees concrete values. */
export function resolve(settings) {
  const systemLight = window.matchMedia("(prefers-color-scheme: light)").matches;
  const systemReduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const theme = settings.theme === "auto" ? (systemLight ? "light" : "dark") : settings.theme;
  const perf = settings.performance === "auto"
    ? (isLowEnd() ? "performance" : "quality")
    : settings.performance;
  const motion = settings.motion === "full" && systemReduce ? "reduced" : settings.motion;
  return {
    theme,
    perf,
    motion,
    blur: perf === "performance" ? 0 : settings.glass_blur,
  };
}

/** Put the settings on the document. Safe to call as often as needed. */
export function applyUiSettings(settings = state.settings) {
  const root = document.documentElement;
  const r = resolve(settings);
  root.dataset.theme = r.theme;
  root.dataset.motion = r.motion;
  root.dataset.perf = r.perf;
  root.dataset.ambient = settings.ambient ? "on" : "off";
  root.style.setProperty("--accent", settings.accent);
  root.style.setProperty("--accent-rgb", hexToRgb(settings.accent));
  root.style.setProperty("--glass-blur", `${r.blur}px`);
  root.style.setProperty("--radius-k", String(settings.radius));
  if (settings.secondary_accent) {
    root.style.setProperty("--accent-2", settings.secondary_accent);
    root.style.setProperty("--accent-2-rgb", hexToRgb(settings.secondary_accent));
  } else {
    root.style.removeProperty("--accent-2");
    root.style.removeProperty("--accent-2-rgb");
  }
  root.style.setProperty("--ambient-opacity", String(settings.ambient_opacity / 100));
  root.style.setProperty("--ambient-speed", String(100 / settings.ambient_speed));
  root.style.setProperty("--ambient-size", String(settings.ambient_size / 100));
  root.style.setProperty("--glass-saturation", `${settings.glass_saturation}%`);
  root.style.setProperty("--sidebar-w", `${settings.sidebar_width}px`);
  root.style.setProperty("--topbar-h", `${settings.topbar_height}px`);
  root.style.setProperty("--tabbar-h", `${settings.mobilebar_height}px`);
  root.style.setProperty("--ui-font-size", `${settings.font_size}px`);
  root.style.setProperty("--button-radius", `${settings.button_radius}px`);
  ["one", "two", "three"].forEach((name) => { root.dataset[`orb${name}`] = settings[`orb_${name}`] ? "on" : "off"; });
  let custom = document.getElementById("prime-custom-css");
  if (!custom) { custom = document.createElement("style"); custom.id = "prime-custom-css"; document.head.appendChild(custom); }
  custom.textContent = settings.custom_css;
  document.querySelectorAll('meta[name="theme-color"]').forEach((meta) => {
    meta.setAttribute("content", META_COLORS[r.theme] || META_COLORS.dark);
  });
  state.listeners.forEach((fn) => {
    try {
      fn(settings, r);
    } catch (err) {
      console.error("appearance listener failed", err);
    }
  });
}

/** Called before anything else renders: paint with the cached values right away. */
export function initAppearance() {
  state.settings = readCache();
  state.saved = { ...state.settings };
  applyUiSettings(state.settings);
  const media = [
    window.matchMedia("(prefers-color-scheme: light)"),
    window.matchMedia("(prefers-reduced-motion: reduce)"),
  ];
  media.forEach((query) => {
    if (query.addEventListener) query.addEventListener("change", () => applyUiSettings());
  });
}

/** Fetch the server copy (public read) and apply it. Never throws. */
export async function loadUiSettings() {
  try {
    const res = await fetch("/api/ui/settings", { credentials: "same-origin", cache: "no-store" });
    if (!res.ok) return state.settings;
    const body = await res.json();
    state.saved = clean(body.settings);
    state.settings = { ...state.saved };
    writeCache(state.saved);
    applyUiSettings(state.settings);
  } catch {
    /* offline: keep the cached values */
  }
  return state.settings;
}

/** Show values immediately without saving them. */
export function previewUiSettings(patch) {
  state.settings = { ...state.settings, ...patch };
  applyUiSettings(state.settings);
  return state.settings;
}

/** Persist values for everyone who opens this panel. Admin only; CSRF handled by the API client. */
export async function saveUiSettings(patch) {
  const body = await api.put("/api/ui/settings", patch);
  state.saved = clean(body.settings);
  state.settings = { ...state.saved };
  writeCache(state.saved);
  applyUiSettings(state.settings);
  return state.saved;
}

export async function resetUiSettings() {
  const body = await api.post("/api/ui/settings/reset");
  state.saved = clean(body.settings);
  state.settings = { ...state.saved };
  writeCache(state.saved);
  applyUiSettings(state.settings);
  return state.saved;
}

export function isDirty() {
  return Object.keys(DEFAULTS).some((key) => state.settings[key] !== state.saved[key]);
}

export function currentTheme() {
  return resolve(state.settings).theme;
}

/** Subscribe to changes; returns an unsubscribe function. */
export function onAppearance(fn) {
  state.listeners.add(fn);
  return () => state.listeners.delete(fn);
}
