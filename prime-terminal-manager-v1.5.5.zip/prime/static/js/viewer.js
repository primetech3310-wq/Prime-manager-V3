/**
 * Embedded full-screen viewer for public links.
 *
 * The public page fills the screen in an iframe. A draggable glass orb floats
 * over it: tap it for controls (back to PRIME, reload, copy, share, switch
 * link, open in browser). Drag it to any edge; its position is remembered.
 */
import { icon } from "./icons.js";
import { esc, copyText, notifyOk, notifyWarn } from "./ui.js";

const ORB_KEY = "prime-viewer-orb";
let current = null;

function readPos() {
  try {
    const raw = localStorage.getItem(ORB_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function writePos(pos) {
  try {
    localStorage.setItem(ORB_KEY, JSON.stringify(pos));
  } catch { /* private mode */ }
}

function clampOrb(orb, pos) {
  const size = 56;
  const maxX = Math.max(8, window.innerWidth - size - 8);
  const maxY = Math.max(8, window.innerHeight - size - 8);
  return {
    x: Math.min(maxX, Math.max(8, pos.x)),
    y: Math.min(maxY, Math.max(8, pos.y)),
  };
}

function placeOrb(orb, pos) {
  orb.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
}

export function closeViewer({ notify = true } = {}) {
  if (!current) return;
  const { root, cleanup } = current;
  cleanup();
  root.classList.add("out");
  setTimeout(() => root.remove(), 220);
  current = null;
  if (notify) document.body.classList.remove("pv-open");
}

/**
 * @param {object} opts
 * @param {string} opts.url      public https URL to show
 * @param {string} [opts.label]  friendly name
 * @param {() => Array<{url:string,label:string}>} [opts.list] other links to switch between
 */
export function openViewer({ url, label = "", list = () => [] } = {}) {
  if (!url) return;
  closeViewer({ notify: false });
  const root = document.createElement("div");
  root.className = "pv-root";
  root.setAttribute("role", "dialog");
  root.setAttribute("aria-label", "Public page viewer");
  root.innerHTML = `
    <div class="pv-loading" id="pv-loading"><span class="spinner"></span><span>Loading ${esc(label || url)}…</span></div>
    <iframe class="pv-frame" id="pv-frame" title="${esc(label || "Public page")}" src="${esc(url)}"
      referrerpolicy="no-referrer" allow="clipboard-read; clipboard-write; fullscreen"></iframe>
    <div class="pv-hint" id="pv-hint">
      <span>Stays blank? Some sites refuse to be embedded.</span>
      <button class="pv-hint-btn" type="button" data-act="external">Open in browser</button>
    </div>
    <button class="pv-orb" id="pv-orb" type="button" aria-label="Viewer controls" aria-expanded="false">
      <span class="pv-orb-logo">${icon("terminal")}</span>
    </button>
    <div class="pv-menu" id="pv-menu" hidden>
      <div class="pv-menu-head">
        <span class="pv-menu-dot"></span>
        <div class="grow" style="min-width:0">
          <b class="truncate">${esc(label || "Public page")}</b>
          <span class="truncate mono">${esc(url)}</span>
        </div>
      </div>
      <button class="pv-item primary" type="button" data-act="back">${icon("home")}<span>Back to PRIME terminal</span></button>
      <div class="pv-grid">
        <button class="pv-item" type="button" data-act="reload">${icon("refresh")}<span>Reload</span></button>
        <button class="pv-item" type="button" data-act="copy">${icon("copy")}<span>Copy link</span></button>
        <button class="pv-item" type="button" data-act="share">${icon("share")}<span>Share</span></button>
        <button class="pv-item" type="button" data-act="external">${icon("external")}<span>Open in browser</span></button>
        <button class="pv-item" type="button" data-act="switch">${icon("layers")}<span>Switch link</span></button>
        <button class="pv-item danger" type="button" data-act="close">${icon("x")}<span>Close viewer</span></button>
      </div>
    </div>`;
  document.body.appendChild(root);
  document.body.classList.add("pv-open");

  const orb = root.querySelector("#pv-orb");
  const menu = root.querySelector("#pv-menu");
  const frame = root.querySelector("#pv-frame");
  const loading = root.querySelector("#pv-loading");
  const hint = root.querySelector("#pv-hint");

  let pos = clampOrb(orb, readPos() || { x: window.innerWidth - 72, y: window.innerHeight - 150 });
  placeOrb(orb, pos);

  let drag = null;
  let moved = false;
  const onDown = (event) => {
    drag = { x: event.clientX, y: event.clientY, ox: pos.x, oy: pos.y };
    moved = false;
    orb.setPointerCapture?.(event.pointerId);
  };
  const onMove = (event) => {
    if (!drag) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!moved && Math.hypot(dx, dy) < 6) return;
    moved = true;
    orb.classList.add("dragging");
    pos = clampOrb(orb, { x: drag.ox + dx, y: drag.oy + dy });
    placeOrb(orb, pos);
  };
  const onUp = () => {
    if (!drag) return;
    drag = null;
    orb.classList.remove("dragging");
    if (moved) {
      // snap to the nearest side, like a floating iOS assistive touch button
      const snapX = pos.x + 28 < window.innerWidth / 2 ? 12 : window.innerWidth - 68;
      pos = clampOrb(orb, { x: snapX, y: pos.y });
      orb.classList.add("snapping");
      placeOrb(orb, pos);
      setTimeout(() => orb.classList.remove("snapping"), 320);
      writePos(pos);
    } else {
      toggleMenu();
    }
  };
  const toggleMenu = (force) => {
    const open = typeof force === "boolean" ? force : menu.hidden;
    menu.hidden = !open;
    orb.setAttribute("aria-expanded", String(open));
    orb.classList.toggle("open", open);
  };
  orb.addEventListener("pointerdown", onDown);
  orb.addEventListener("pointermove", onMove);
  orb.addEventListener("pointerup", onUp);
  orb.addEventListener("pointercancel", () => {
    drag = null;
    orb.classList.remove("dragging");
  });

  frame.addEventListener("load", () => {
    loading.classList.add("done");
  });
  const hintTimer = setTimeout(() => hint.classList.add("show"), 4500);
  const hideHintTimer = setTimeout(() => hint.classList.remove("show"), 16000);

  const onKey = (event) => {
    if (event.key === "Escape") {
      if (!menu.hidden) toggleMenu(false);
      else closeViewer();
    }
  };
  const onResize = () => {
    pos = clampOrb(orb, pos);
    placeOrb(orb, pos);
  };
  document.addEventListener("keydown", onKey);
  window.addEventListener("resize", onResize);

  root.addEventListener("click", async (event) => {
    const btn = event.target.closest("[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;
    if (act === "back") {
      closeViewer();
      return;
    }
    if (act === "close") {
      closeViewer();
      return;
    }
    if (act === "reload") {
      loading.classList.remove("done");
      frame.src = url;
      toggleMenu(false);
      return;
    }
    if (act === "copy") {
      await copyText(url);
      notifyOk("Link copied", url);
      return;
    }
    if (act === "share") {
      if (navigator.share) {
        try {
          await navigator.share({ title: label || "PRIME public link", url });
        } catch { /* user cancelled */ }
      } else {
        await copyText(url);
        notifyOk("Link copied", "Sharing is not available here, so the link was copied.");
      }
      return;
    }
    if (act === "external") {
      window.open(url, "_blank", "noopener,noreferrer");
      return;
    }
    if (act === "switch") {
      const links = list().filter((item) => item && item.url);
      if (links.length <= 1) {
        notifyWarn("Nothing to switch to", "Make another port public to switch between links.");
        return;
      }
      const index = links.findIndex((item) => item.url === url);
      const next = links[(index + 1) % links.length];
      openViewer({ url: next.url, label: next.label, list });
    }
  });

  const cleanup = () => {
    clearTimeout(hintTimer);
    clearTimeout(hideHintTimer);
    document.removeEventListener("keydown", onKey);
    window.removeEventListener("resize", onResize);
    if (drag) drag = null;
    frame.src = "about:blank";
  };
  current = { root, cleanup };
  return root;
}
