const status = document.querySelector('#workspace-status');
const token = location.hash.slice(1);
const ident = location.pathname.slice(1);
try {
  if (!/^[0-9a-f]{32}$/.test(ident) || !/^[A-Za-z0-9_-]{30,128}$/.test(token)) throw new Error('The workspace link is incomplete. Open the entire link, including the part after #.');
  const response = await fetch(`/api/workspaces/${ident}/open`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({token}), credentials:'omit', cache:'no-store'});
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || 'Workspace unavailable');
  const target = new URL(data.url);
  if (target.protocol !== 'https:' || !target.hostname.endsWith('.trycloudflare.com')) throw new Error('Invalid workspace endpoint');
  const frame = document.querySelector('#workspace-frame');
  frame.src = target.href;
  frame.style.display = 'block';
  status.remove();
} catch (err) {
  status.querySelector('h1').textContent = 'Cannot open workspace';
  status.querySelector('p').textContent = err.message;
  status.querySelector('.boot-spinner')?.remove();
}
