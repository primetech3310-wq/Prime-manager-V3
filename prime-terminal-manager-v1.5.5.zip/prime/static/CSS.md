<!-- coderabbit-ai-generated:v1 -->

# PRIME Terminal Manager CSS guide

Custom CSS in Settings → Appearance is applied to the whole panel, including the login page. Preview changes before saving them. Reset to defaults removes custom CSS and restores appearance settings.

## Variables

Use `:root` to override design tokens. Main tokens include `--accent`, `--accent-2`, `--bg`, `--text`, `--text-dim`, `--glass-blur`, `--glass-tint`, `--glass-solid`, `--glass-rim`, `--sidebar-w`, `--topbar-h`, `--tabbar-h`, `--radius-k` and `--font`. Dark and light modes use `html[data-theme="dark"]` and `html[data-theme="light"]`.

## Components

- `.sidebar`, `.topbar`, `.tabbar`, `.nav-item`, `.tab-item` — navigation.
- `.card`, `.card-head`, `.card-title-icon`, `.list-row` — panel content.
- `.btn`, `.btn-primary`, `.icon-btn`, `.input`, `.select` — controls.
- `.liquid-bg` and `.liquid-bg span` — animated background.
- `.term-shell`, `.term-bar`, `.term-stage`, `.term-host`, `.term-keys`, `#term-fullscreen` — terminal.
- `.fm-list`, `.fm-row-actions`, `.fm-crumbs`, `#fm-search` — file manager.
- `.br`, `.br-bar`, `.br-stage`, `.br-frame` — embedded browser.
- `#appearance-card` and `.ui-row` — appearance controls.

For example:

```css
:root { --accent: #ff453a; --accent-rgb: 255 69 58; }
.card { border-color: rgba(255, 69, 58, .5); }
@media (max-width: 700px) { .fm-row-actions { gap: 6px; } }
```

Custom CSS is powerful enough to hide controls or make login unusable. If that happens, remove the `custom_css` value from the `ui-settings.json` file in the panel data directory and reload. Browser content security policy can block external resources referenced by CSS.
