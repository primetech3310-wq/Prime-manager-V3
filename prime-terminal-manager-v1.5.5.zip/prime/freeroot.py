"""Named proot workspaces (FreeRoot-style), used by the panel tab and POST /API/freeroot.

A workspace is a proot environment built from an Ubuntu base image. Setup is:
  1. the Ubuntu base is extracted into a shared template (once);
  2. proot is taken from the host's package if installed (preferred), otherwise downloaded;
  3. curl and CA certificates are installed into the template with apt, inside proot;
  4. each workspace gets its own copy of the template, and sshx is installed and started inside it.

Isolation, stated exactly. proot changes the root directory the guest sees, using ptrace.
  * Filesystem: the guest sees only its own copy of the base image. Host files are
    not visible, except /dev, /proc and /sys, which basic tools need.
  * Processes: NOT isolated. proot has no PID namespace, so the guest can see and
    signal host processes that run as the same user (the panel usually runs as root).
  * Network: NOT isolated. The guest uses the host's network.
  * CPU and RAM are the host's.
For process and network isolation use the bubblewrap backend of /API/sandbox.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import freeroot_isolation as iso

DEFAULT_TTL = 3600
MIN_TTL = 300
MAX_TTL = 86400
MAX_PER_OWNER = 5
MAX_TOTAL = 30
OUT_DIR = "/run/prime-out"
_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$")
SSHX_LINK = re.compile(r"^https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}$")
_LINK_IN_LOG = re.compile(r"https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}")
_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
_LOCK = threading.RLock()  # guards the registry file only
_TEMPLATE_LOCK = threading.Lock()  # held for the whole base-image build, which can take minutes

UBUNTU_BASE = {
    "x86_64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-amd64.tar.gz",
    "aarch64": "http://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.4-base-arm64.tar.gz",
}
# Fallback only. This third-party binary is not checksum-pinned; the host package is preferred.
PROOT_FALLBACK_URL = {
    "x86_64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-x86_64",
    "aarch64": "https://raw.githubusercontent.com/foxytouxxx/freeroot/main/proot-aarch64",
}
BASE_TOOLS = ("apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y "
              "--no-install-recommends curl ca-certificates")

GUEST_SCRIPT = r"""
OUT=/run/prime-out
mkdir -p "$OUT" /root
echo starting > "$OUT/status"
export PATH="/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin"
export HOME=/root TERM=xterm-256color LANG=C.UTF-8
if ! command -v sshx >/dev/null 2>&1; then
  curl -sSf https://sshx.io/get 2>>"$OUT/install.log" | sh >>"$OUT/install.log" 2>&1 || {
    echo install-failed > "$OUT/status"; exit 1; }
fi
nohup sshx >"$OUT/sshx.log" 2>&1 &
i=0
while [ $i -lt 120 ]; do
  link=$(grep -oE 'https://sshx\.io/s/[A-Za-z0-9#_.=\-]{4,200}' "$OUT/sshx.log" 2>/dev/null | head -n 1)
  if [ -n "$link" ]; then
    printf '%s\n' "$link" > "$OUT/sshx.txt"
    echo ready > "$OUT/status"
    break
  fi
  i=$((i + 1))
  sleep 1
done
[ -f "$OUT/sshx.txt" ] || { echo no-link > "$OUT/status"; exit 1; }
wait
""".strip()


class FreeRootError(ValueError):
    """A request the host cannot satisfy (maps to HTTP 400)."""


def owner_ref(identity: str) -> str:
    """Only this hash is stored. API keys hash as themselves; panel users as 'panel:<name>'."""
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]


def panel_owner(username: str) -> str:
    return owner_ref("panel:" + username)


def key_owner(token: str) -> str:
    return owner_ref(token)


def _arch() -> str:
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "x86_64"
    if machine in ("aarch64", "arm64"):
        return "aarch64"
    raise FreeRootError(f"Unsupported architecture: {machine}")


def _download(url: str, dest: Path, timeout: int = 600) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "PrimeTerminal-FreeRoot/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(tmp, "wb") as out:
        shutil.copyfileobj(resp, out)
    tmp.replace(dest)


def _alive(pid: Optional[int]) -> bool:
    if not pid or pid <= 1:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as fh:
            parts = fh.read().rsplit(")", 1)[1].split()
            return not (parts and parts[0] == "Z")
    except (OSError, IndexError):
        return True


def proot_argv(proot: str, root: Path, extra: List[str], command: List[str], sys_bind: bool = True) -> List[str]:
    """Build a proot command line. Pure function, used for setup and for workspaces.

    sys_bind is False inside the bubblewrap namespaces, which do not mount /sys."""
    binds = ["-b", "/dev", "-b", "/proc"] + (["-b", "/sys"] if sys_bind else [])
    return [proot, "--rootfs=" + str(root), "-0", "-w", "/root", *binds, *extra, "--kill-on-exit", *command]


class FreeRootManager:
    def __init__(self, data_dir: str, backends: Optional[Dict[str, Any]] = None) -> None:
        self._backends_cache = backends  # None: probe the host once, on first use
        self.root = Path(data_dir) / "freeroot"
        self.template = self.root / "template"
        self.instances = self.root / "instances"
        self.registry = self.root / "registry.json"
        self.proot_bin = self.root / "bin" / "proot"
        self.root.mkdir(parents=True, exist_ok=True)
        self.instances.mkdir(parents=True, exist_ok=True)
        self._procs: Dict[str, subprocess.Popen] = {}
        if not self.registry.exists():
            self._save({"sandboxes": []})

    # ----------------------------------------------------------- storage
    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.registry.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"sandboxes": []}

    def _save(self, data: Dict[str, Any]) -> None:
        tmp = self.registry.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.registry)

    # ---------------------------------------------------------- template
    def template_ready(self) -> bool:
        t = self.template
        has_sh = (t / "bin" / "sh").exists() or (t / "usr" / "bin" / "sh").exists()
        has_curl = (t / "usr" / "bin" / "curl").exists() or (t / "bin" / "curl").exists()
        return has_sh and has_curl and (t / "root").is_dir() and self.proot_bin.is_file()

    def status_info(self) -> Dict[str, Any]:
        if shutil.which("proot"):
            proot_source = "host package"
        elif self.proot_bin.exists():
            proot_source = "downloaded"
        else:
            proot_source = "not installed"
        return {
            "template_ready": self.template_ready(),
            "proot": proot_source,
            "isolation": self.isolation(),
        }

    def isolation(self) -> str:
        """What a new workspace on this host would get. Never blocks on the host probe."""
        probe = self._backends_now()
        if probe is None:
            return "checking this host's isolation support (first use)"
        try:
            return iso.label(iso.plan(probe)["net"])
        except iso.IsolationError as exc:
            return "unavailable: " + str(exc)

    def _ensure_proot(self) -> None:
        host = shutil.which("proot")
        if host:
            self.proot_bin.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(host, self.proot_bin)
        elif not self.proot_bin.exists() or self.proot_bin.stat().st_size < 1000:
            _download(PROOT_FALLBACK_URL[_arch()], self.proot_bin)
        os.chmod(self.proot_bin, 0o755)
        try:
            check = subprocess.run([str(self.proot_bin), "--version"], capture_output=True, timeout=20)
        except (OSError, subprocess.SubprocessError) as exc:
            raise FreeRootError(f"proot cannot run on this host: {exc}") from exc
        if check.returncode != 0:
            raise FreeRootError("proot cannot run on this host (exit %d)" % check.returncode)

    def _install_base_tools(self, rootfs: Path) -> None:
        argv = proot_argv(str(self.proot_bin), rootfs, [], ["/bin/sh", "-c", BASE_TOOLS])
        done = subprocess.run(argv, capture_output=True, text=True, timeout=1500)
        if done.returncode != 0:
            tail = _ANSI.sub("", (done.stderr or done.stdout or "")[-400:])
            raise FreeRootError("Could not install curl into the base image: " + tail.strip())

    def ensure_template(self) -> None:
        """Build the shared template once. Concurrent callers wait for the same build."""
        with _TEMPLATE_LOCK:
            if self.template_ready():
                return
            arch = _arch()
            base_url = UBUNTU_BASE.get(arch)
            if not base_url:
                raise FreeRootError(f"No base image for architecture {arch}")
            new = self.root / "template.new"
            shutil.rmtree(new, ignore_errors=True)
            new.mkdir(parents=True)
            tar_path = self.root / "ubuntu-base.tar.gz"
            if not tar_path.exists() or tar_path.stat().st_size < 1_000_000:
                _download(base_url, tar_path)
            subprocess.run(["tar", "-xzf", str(tar_path), "--no-same-owner", "-C", str(new)],
                           check=True, timeout=600)
            for sub in ("root", "run/prime-out", "tmp", "proc", "dev", "etc"):
                (new / sub).mkdir(parents=True, exist_ok=True)
            (new / "etc" / "resolv.conf").write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
            self._ensure_proot()
            self._install_base_tools(new)
            host_sshx = shutil.which("sshx")
            if host_sshx:
                dest = new / "usr" / "local" / "bin"
                dest.mkdir(parents=True, exist_ok=True)
                shutil.copy2(host_sshx, dest / "sshx")
                os.chmod(dest / "sshx", 0o755)
            shutil.rmtree(self.template, ignore_errors=True)
            os.replace(new, self.template)
            if not self.template_ready():
                raise FreeRootError("The workspace base is incomplete after setup")

    # ----------------------------------------------------------- create
    def create(self, token: str, ttl: int = DEFAULT_TTL, name: Optional[str] = None) -> Dict[str, Any]:
        return self.create_for(key_owner(token), ttl, name)

    def create_for(self, owner: str, ttl: int = DEFAULT_TTL, name: Optional[str] = None) -> Dict[str, Any]:
        if not MIN_TTL <= int(ttl) <= MAX_TTL:
            raise FreeRootError(f"ttl must be {MIN_TTL}-{MAX_TTL} seconds")
        if name is not None and not _NAME.fullmatch(name):
            raise FreeRootError("name: 1-40 letters, digits, dots, dashes or underscores")
        now = time.time()
        sid = "fr-" + secrets.token_hex(6)
        base = self.instances / sid
        # The isolation decision and the base image are made in the background (see
        # _prepare_and_launch), so this request never waits for the host probe or a build.
        record = {"id": sid, "owner": owner, "name": name or sid, "backend": "proot",
                  "mode": None, "network": None,
                  "created_at": now, "expires_at": now + int(ttl),
                  "pid": None, "dir": str(base), "error": "",
                  "phase": "launching" if self.template_ready() else "building-base"}
        with _LOCK:
            data = self._load()
            mine = [r for r in data["sandboxes"] if hmac.compare_digest(r["owner"], owner)]
            if len(mine) >= MAX_PER_OWNER:
                raise FreeRootError(f"Each owner may have up to {MAX_PER_OWNER} active workspaces")
            if len(data["sandboxes"]) >= MAX_TOTAL:
                raise FreeRootError("This host has no free workspace slots; try again later")
            data["sandboxes"].append(record)
            self._save(data)
        # Return at once. The base image build and the launch run in the background, so
        # the HTTP request never waits for a reverse proxy to time out.
        self._start_worker(sid)
        return self._public(dict(record))

    def _start_worker(self, sid: str) -> None:
        threading.Thread(target=self._prepare_and_launch, args=(sid,),
                         name="freeroot-" + sid, daemon=True).start()

    def _set(self, sid: str, **fields: Any) -> None:
        with _LOCK:
            data = self._load()
            for item in data["sandboxes"]:
                if item["id"] == sid:
                    item.update(fields)
            self._save(data)

    def _prepare_and_launch(self, sid: str) -> None:
        """Background: build the base image if needed, then start the workspace."""
        try:
            decision = self._decide()  # probes the host once per process; refusals are reported here
            self._set(sid, mode=decision["mode"], network=decision["net"])
            self.ensure_template()
            self._set(sid, phase="launching")
            record = next((r for r in self._load()["sandboxes"] if r["id"] == sid), None)
            if record is None:
                return  # deleted while it was being prepared
            pid = self._launch(record)
            self._set(sid, pid=pid, phase="running")
        except Exception as exc:  # noqa: BLE001 - reported on the workspace, never crashes the panel
            self._set(sid, phase="failed", error=str(exc)[:300])

    def _launch(self, record: Dict[str, Any]) -> int:
        base = Path(record["dir"]).absolute()
        root = base / "rootfs"
        out = base / "out"
        out.mkdir(parents=True, exist_ok=True)
        shutil.rmtree(root, ignore_errors=True)
        subprocess.run(["cp", "-a", "--reflink=auto", str(self.template), str(root)],
                       check=True, timeout=900)
        (root / "run" / "prime-out").mkdir(parents=True, exist_ok=True)
        (root / "root").mkdir(exist_ok=True)
        script = base / "guest.sh"
        script.write_text(GUEST_SCRIPT + "\n", encoding="utf-8")
        os.chmod(script, 0o755)
        namespaced = record.get("mode") == "bwrap"
        inner = proot_argv(str(self.proot_bin), root,
                           ["-b", f"{out}:{OUT_DIR}", "-b", f"{script}:/tmp/guest.sh"],
                           ["/bin/sh", "/tmp/guest.sh"], sys_bind=not namespaced)
        argv = inner
        net = record.get("network", "shared-host")
        backends = self._backends()
        if namespaced:
            argv = iso.bwrap_prefix(bwrap=backends["bwrap"], instance=base, proot_bin=self.proot_bin,
                                    hostname="pw-" + record["id"][-8:], net=net,
                                    pasta=backends.get("pasta")) + inner
        log = open(base / "console.log", "ab")
        try:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                    start_new_session=True, close_fds=True)
            self._procs[record["id"]] = proc
            if namespaced and net == "slirp4netns" and proc.pid:
                # Give the namespace outbound access only; the loopback gateway is disabled.
                time.sleep(0.2)
                if _alive(proc.pid):
                    sp = subprocess.Popen(iso.slirp_argv(backends["slirp4netns"], proc.pid),
                                          stdin=subprocess.DEVNULL, stdout=log, stderr=log, close_fds=True)
                    time.sleep(0.5)
                    if sp.poll() is None:
                        self._procs[record["id"] + ":slirp"] = sp
                    else:
                        raise FreeRootError("slirp4netns could not attach; see console.log")
                else:
                    raise FreeRootError("the workspace exited before networking was attached")
        except OSError as exc:
            raise FreeRootError(f"could not start the workspace: {exc}") from exc
        finally:
            log.close()
        return proc.pid

    def _backends(self) -> Dict[str, Any]:
        """Blocking: only used from background work, never from a request."""
        if self._backends_cache is not None:
            return self._backends_cache
        from .sandbox import cached_backends
        return cached_backends()

    def _backends_now(self) -> Optional[Dict[str, Any]]:
        """Non-blocking: the host probe if it is already known."""
        if self._backends_cache is not None:
            return self._backends_cache
        from .sandbox import peek_backends
        return peek_backends()

    def _decide(self) -> Dict[str, str]:
        try:
            return iso.plan(self._backends())
        except iso.IsolationError as exc:
            raise FreeRootError(str(exc)) from exc

    # ------------------------------------------------------------ reading
    def _owned(self, owner: str, sid: str) -> Dict[str, Any]:
        for record in self._load()["sandboxes"]:
            if record["id"] == sid and hmac.compare_digest(record["owner"], owner):
                return record
        raise LookupError(sid)

    def _read(self, record: Dict[str, Any], name: str) -> str:
        try:
            return (Path(record["dir"]) / "out" / name).read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            return ""

    def _link(self, record: Dict[str, Any]) -> Optional[str]:
        raw = _ANSI.sub("", self._read(record, "sshx.txt"))
        if not raw:
            raw = next(iter(_LINK_IN_LOG.findall(_ANSI.sub("", self._read(record, "sshx.log")))), "")
        raw = raw.strip()
        return raw if raw and SSHX_LINK.fullmatch(raw) else None

    def _state(self, record: Dict[str, Any]) -> Dict[str, Any]:
        link = self._link(record)
        if link:
            return {"status": "ready", "sshx": link}
        if record.get("phase") == "failed":
            return {"status": "failed", "sshx": None}
        if record.get("phase") in ("building-base", "launching"):
            return {"status": "preparing", "sshx": None}
        phase = self._read(record, "status")
        if phase in ("install-failed", "no-link"):
            return {"status": "failed", "sshx": None}
        if _alive(record.get("pid")):
            return {"status": "starting", "sshx": None}
        return {"status": "failed" if phase else "stopped", "sshx": None}

    def _public(self, record: Dict[str, Any]) -> Dict[str, Any]:
        state = self._state(record)
        return {"id": record["id"], "name": record["name"], "status": state["status"],
                "error": record.get("error") or None,
                "running": _alive(record.get("pid")), "sshx": state["sshx"],
                "backend": "proot", "network": record.get("network", "shared-host"),
                "isolation": (iso.label(record["network"]) if record.get("network")
                              else "deciding isolation on this host…"),
                "expires_at": int(record["expires_at"]),
                "status_url": "/API/freeroot/" + record["id"]}

    def list_for(self, owner: str) -> List[Dict[str, Any]]:
        return [self._public(r) for r in self._load()["sandboxes"]
                if hmac.compare_digest(r["owner"], owner)]

    def status(self, token: str, sid: str, wait: int = 0) -> Dict[str, Any]:
        return self.status_for(key_owner(token), sid, wait)

    def status_for(self, owner: str, sid: str, wait: int = 0) -> Dict[str, Any]:
        deadline = time.time() + max(0, min(int(wait), 900))
        while True:
            record = self._owned(owner, sid)
            if self._state(record)["status"] not in ("starting", "preparing") or time.time() >= deadline:
                return self._public(record)
            time.sleep(2)

    # ------------------------------------------------------------ delete
    def delete(self, token: str, sid: str) -> Dict[str, Any]:
        return self.delete_for(key_owner(token), sid)

    def delete_for(self, owner: str, sid: str) -> Dict[str, Any]:
        record = self._owned(owner, sid)
        self._stop(record)
        with _LOCK:
            data = self._load()
            data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != sid]
            self._save(data)
        shutil.rmtree(record["dir"], ignore_errors=True)
        return {"ok": True, "id": sid}

    def _stop(self, record: Dict[str, Any]) -> None:
        slirp = self._procs.pop(record["id"] + ":slirp", None)
        if slirp is not None and slirp.poll() is None:
            slirp.terminate()
        proc = self._procs.pop(record["id"], None)
        pid = record.get("pid")
        if proc is not None:
            proc.poll()
        if not pid or pid <= 1 or not _alive(pid):
            return
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            pass
        for _ in range(30):
            if not _alive(pid):
                break
            time.sleep(0.1)
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                pass
        if proc is not None:
            try:
                proc.wait(timeout=5)
            except subprocess.SubprocessError:
                pass

    def expire_due(self) -> int:
        now = time.time()
        with _LOCK:
            due = [r for r in self._load()["sandboxes"] if r["expires_at"] <= now]
        for record in due:
            self._stop(record)
            with _LOCK:
                data = self._load()
                data["sandboxes"] = [r for r in data["sandboxes"] if r["id"] != record["id"]]
                self._save(data)
            shutil.rmtree(record["dir"], ignore_errors=True)
        return len(due)
