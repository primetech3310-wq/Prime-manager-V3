"""Isolation for proot workspaces: proot runs inside bubblewrap namespaces.

proot on its own only changes the filesystem view. Here proot runs inside a
bubblewrap sandbox with its own PID, IPC, UTS and network namespaces. A workspace
then cannot list, signal or connect to host processes, including services on
127.0.0.1 or the host's own addresses. Outbound internet only, through pasta or
slirp4netns. slirp runs with --disable-host-loopback, so the gateway address does
not reach the host's loopback.

Hosts that cannot create these namespaces are refused, unless the administrator
sets PRIME_FREEROOT_ALLOW_WEAK=1, which accepts shared processes and network.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

WEAK_ENV = "PRIME_FREEROOT_ALLOW_WEAK"
GUEST_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
HOST_RUNTIME = ("/usr", "/lib", "/lib64", "/bin", "/sbin")  # what the proot binary needs to start
LABELS = {
    "pasta": "namespaces: pid, ipc, uts, network (pasta, outbound only); host processes and "
             "loopback services are not visible; proot runs inside",
    "slirp4netns": "namespaces: pid, ipc, uts, network (slirp4netns, outbound only); host processes "
                   "and loopback services are not visible; proot runs inside",
    "shared-host": "WEAK: filesystem only (proot). Processes and network are shared with the host",
}


class IsolationError(RuntimeError):
    pass


def plan(backends: Optional[Mapping[str, Any]], env: Mapping[str, str] = os.environ) -> Dict[str, str]:
    """Decide how a workspace runs on this host. Pure: takes the probe result as input."""
    b = backends or {}
    if b.get("bwrap_works") and b.get("pasta_works"):
        return {"mode": "bwrap", "net": "pasta"}
    if b.get("bwrap_works") and b.get("slirp_works"):
        return {"mode": "bwrap", "net": "slirp4netns"}
    if env.get(WEAK_ENV) == "1":
        return {"mode": "proot-only", "net": "shared-host"}
    raise IsolationError(
        "Isolated proot workspaces need bubblewrap with pasta or slirp4netns on this host "
        "(for example: apt-get install -y bubblewrap slirp4netns). To accept shared processes "
        f"and network instead, set {WEAK_ENV}=1 on the panel.")


def label(net: str) -> str:
    return LABELS.get(net, LABELS["shared-host"])


def host_runtime_binds() -> List[str]:
    argv: List[str] = []
    for path in HOST_RUNTIME:
        p = Path(path)
        if p.is_symlink():
            argv += ["--symlink", os.readlink(path), path]
        elif p.is_dir():
            argv += ["--ro-bind", path, path]
    return argv


def bwrap_prefix(*, bwrap: str, instance: Path, proot_bin: Path, hostname: str, net: str,
                 pasta: Optional[str] = None) -> List[str]:
    """The namespace wrapper. The caller appends the proot command line after it."""
    if net not in ("pasta", "slirp4netns"):
        raise IsolationError("namespaced workspaces need pasta or slirp4netns")
    argv = [bwrap, "--die-with-parent", "--new-session", "--cap-drop", "ALL",
            "--unshare-pid", "--unshare-ipc", "--unshare-uts", "--unshare-cgroup-try",
            "--hostname", hostname, "--clearenv",
            "--setenv", "PATH", GUEST_PATH, "--setenv", "HOME", "/root",
            "--setenv", "TERM", "xterm-256color", "--setenv", "LANG", "C.UTF-8"]
    if net == "slirp4netns":
        argv += ["--unshare-net"]  # slirp4netns attaches to this namespace after start
    argv += host_runtime_binds()
    argv += ["--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
             "--bind", str(instance), str(instance),  # this workspace's rootfs, output and script
             "--ro-bind", str(proot_bin), str(proot_bin)]
    if net == "pasta":
        if not pasta:
            raise IsolationError("pasta is not available")
        # pasta owns the network namespace; forward no inbound ports.
        return [pasta, "--config-net", "-t", "none", "-u", "none", "--"] + argv
    return argv


def slirp_argv(slirp: str, pid: int) -> List[str]:
    return [slirp, "--configure", "--mtu=65520", "--disable-host-loopback", str(pid), "tap0"]


def probe_script(host_pid: int, host_port: int) -> str:
    """Shell run inside a workspace to check isolation (used by scripts/isolation_check.sh)."""
    return (
        "echo LOOPBACK=$(curl -m 4 -s -o /dev/null -w '%%{http_code}' http://127.0.0.1:%(p)d/ || true);"
        " echo GATEWAY=$(curl -m 4 -s -o /dev/null -w '%%{http_code}' http://10.0.2.2:%(p)d/ || true);"
        " echo HOSTPID_VISIBLE=$(kill -0 %(pid)d 2>/dev/null && echo yes || echo no);"
        " echo PROCESSES=$(ps -e 2>/dev/null | wc -l);"
        " echo INTERNET=$(curl -m 6 -s -o /dev/null -w '%%{http_code}' https://sshx.io/get || true)"
    ) % {"p": host_port, "pid": host_pid}
