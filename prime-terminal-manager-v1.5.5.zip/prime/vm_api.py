"""Provisioning API for virtual machines.

POST /API/vm (bearer provisioning key) creates a Debian VM that boots with three
access paths: a browser terminal (ttyd behind a Cloudflare quick tunnel), an SSHx
session, and a generated guest login. The guest reports its links back to the
panel through QEMU user networking (http://10.0.2.2:<panel port>), authenticated
by a per-VM callback token that is part of the URL and only stored as a hash.

Rules:
  * Each API VM records the hash of the key that created it. Only that key can
    read, wait for, or delete the VM.
  * Callback tokens and generated guest passwords are random. Only the hash of
    the callback token is stored in the VM record.
  * API VMs expire automatically (TTL). The VM scheduler calls expire_due().
"""
from __future__ import annotations

import hashlib
import logging
import re
import secrets
import shlex
import time
from typing import Any, Dict, List, Optional

from .vms import VMError, VMStore, capabilities

log = logging.getLogger("prime.vm_api")

API_VM_PREFIX = "api-"
DEFAULT_TTL = 3600
MIN_TTL = 300
MAX_TTL = 24 * 3600
MAX_ACTIVE_API_VMS = 5
DEFAULT_MEMORY = 2048
DEFAULT_CPUS = 2
# Every VM gets this login (requested by the owner). Change it here if the default must differ.
GUEST_USER = "root"
GUEST_PASSWORD = "$PrimeTerminal@user#"
TTYD_USER = "prime"

_TRY_URL = re.compile(r"^https://[a-z0-9-]{1,100}\.trycloudflare\.com$")
_SSHX_URL = re.compile(r"^https://sshx\.io/s/[A-Za-z0-9_/#-]{1,200}$")
_SECRET = re.compile(r"^[A-Za-z0-9_-]{8,128}$")


def key_reference(token: str) -> str:
    """Stable, non-reversible identifier for the provisioning key that owns a VM."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def bootstrap_script(callback_url: str, ttyd_password: str) -> str:
    """Shell script that cloud-init runs once inside the guest.

    It installs ttyd, cloudflared and sshx, starts them, waits for their public
    links and posts them to the panel. The callback is retried for about 20
    minutes so a slow first boot under software emulation still reports.
    """
    script = r'''#!/bin/bash
# Prime VM API bootstrap (generated). Runs once through cloud-init.
exec >> /var/log/prime-bootstrap.log 2>&1
set -u
CB=__CB__
TTYD_USER=__TTYD_USER__
TTYD_PASS=__TTYD_PASS__
export DEBIAN_FRONTEND=noninteractive
for attempt in 1 2 3 4 5 6; do
  apt-get update && apt-get install -y ttyd curl ca-certificates && break
  sleep 20
done
if ! command -v cloudflared >/dev/null 2>&1; then
  curl -fsSL -o /usr/local/bin/cloudflared \
    https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 \
    && chmod 0755 /usr/local/bin/cloudflared
fi
if ! command -v sshx >/dev/null 2>&1; then
  curl -sSf https://sshx.io/get | sh
fi
ttyd -p 7681 -i 127.0.0.1 -c "$TTYD_USER:$TTYD_PASS" -W bash > /var/log/ttyd.log 2>&1 &
cloudflared tunnel --no-autoupdate --url http://127.0.0.1:7681 > /var/log/cloudflared.log 2>&1 &
nohup sshx > /var/log/sshx.log 2>&1 &
TTYD_URL=""
SSHX_URL=""
for i in $(seq 1 120); do
  [ -z "$TTYD_URL" ] && TTYD_URL=$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /var/log/cloudflared.log | head -n 1)
  [ -z "$SSHX_URL" ] && SSHX_URL=$(grep -oE 'https://sshx\.io/s/[A-Za-z0-9_/#-]+' /var/log/sshx.log | head -n 1)
  [ -n "$TTYD_URL" ] && [ -n "$SSHX_URL" ] && break
  sleep 5
done
PAYLOAD=$(printf '{"ttyd":"%s","ttyd_user":"%s","ttyd_password":"%s","sshx":"%s"}' \
  "$TTYD_URL" "$TTYD_USER" "$TTYD_PASS" "$SSHX_URL")
for i in $(seq 1 60); do
  if curl -fsS -m 20 -X POST -H 'Content-Type: application/json' --data "$PAYLOAD" "$CB"; then
    echo "links reported"
    break
  fi
  sleep 20
done
'''
    return (script.replace("__CB__", shlex.quote(callback_url))
            .replace("__TTYD_USER__", shlex.quote(TTYD_USER))
            .replace("__TTYD_PASS__", shlex.quote(ttyd_password)))


def cloud_config(callback_url: str, ttyd_password: str) -> Dict[str, Any]:
    """cloud-init sections merged into the guest configuration."""
    return {
        "write_files": [{
            "path": "/usr/local/sbin/prime-bootstrap.sh",
            "permissions": "0700",
            "owner": "root:root",
            "content": bootstrap_script(callback_url, ttyd_password),
        }],
        "runcmd": [["/usr/local/sbin/prime-bootstrap.sh"]],
    }


class VMApi:
    """Creates, reports on and removes API-provisioned virtual machines."""

    def __init__(self, data_dir: str, panel_port: int):
        self.store = VMStore(data_dir)
        self.panel_port = int(panel_port)

    # ------------------------------------------------------------ records
    def _api_records(self) -> List[Dict[str, Any]]:
        return [vm for vm in self.store.list() if vm.get("api")]

    def _owned(self, vm_id: str, key_ref: str) -> Dict[str, Any]:
        """Return the VM only when it was created by this provisioning key."""
        try:
            vm = self.store._read(vm_id)
        except VMError as exc:
            raise LookupError("VM not found") from exc
        api = vm.get("api")
        if not api or not secrets.compare_digest(api.get("key_ref", ""), key_ref):
            raise LookupError("VM not found")
        return vm

    def _status(self, vm: Dict[str, Any]) -> Dict[str, Any]:
        api = vm["api"]
        running = bool(self.store._running(vm["id"]))
        links = api.get("links") or {}
        ready = bool(api.get("ready"))
        result: Dict[str, Any] = {
            "id": vm["id"],
            "name": vm["name"],
            "status": "ready" if ready else ("booting" if running else "stopped"),
            "running": running,
            "expires_at": api["expires_at"],
            "memory_mb": vm["memory"],
            "cpus": vm["cpus"],
            "acceleration": vm.get("active_acceleration", vm.get("acceleration")),
            "guest_login": {"user": GUEST_USER, "password": api.get("guest_password")},
        }
        if ready:
            result["sshx"] = links.get("sshx") or None
            result["ttyd"] = links.get("ttyd") or None
            result["ttyd_credentials"] = {"user": TTYD_USER, "password": api.get("ttyd_password")}
            result["reported_at"] = api.get("reported_at")
        return result

    # ----------------------------------------------------------- lifecycle
    def create(self, key_token: str, name: Optional[str] = None, memory: int = DEFAULT_MEMORY,
               cpus: int = DEFAULT_CPUS, ttl: int = DEFAULT_TTL, image: str = "debian",
               start: bool = True) -> Dict[str, Any]:
        if image != "debian":
            raise VMError("Only the 'debian' image is available through the API")
        if isinstance(ttl, bool) or not isinstance(ttl, int) or not MIN_TTL <= ttl <= MAX_TTL:
            raise VMError(f"ttl must be a whole number of seconds between {MIN_TTL} and {MAX_TTL}")
        caps = capabilities()
        if not caps["available"]:
            raise VMError("QEMU is not installed on this host")
        if not caps["cloud_init"]:
            raise VMError("cloud-localds and openssl are required for API VMs")
        key_ref = key_reference(key_token)
        now = time.time()
        active = [vm for vm in self._api_records()
                  if secrets.compare_digest(vm["api"].get("key_ref", ""), key_ref)
                  and vm["api"]["expires_at"] > now]
        if len(active) >= MAX_ACTIVE_API_VMS:
            raise VMError(f"This key already has {MAX_ACTIVE_API_VMS} active API VMs; delete one first")
        image_info = self.store.download_debian()
        vm_name = name.strip() if isinstance(name, str) and name.strip() else API_VM_PREFIX + secrets.token_hex(3)
        callback_token = secrets.token_urlsafe(32)
        ttyd_password = secrets.token_urlsafe(18)
        guest_password = GUEST_PASSWORD
        callback_url = "http://10.0.2.2:%d/API/vm-callback/%s" % (self.panel_port, callback_token)
        record = self.store.create(
            vm_name, image_info["path"], memory, cpus,
            username=GUEST_USER, password=guest_password, acceleration="auto",
            extra_config=cloud_config(callback_url, ttyd_password),
            extra_meta={"api": {
                "key_ref": key_ref,
                "callback_hash": _hash(callback_token),
                "created_at": now,
                "expires_at": now + ttl,
                "links": {},
                "ready": False,
                "guest_password": guest_password,
                "ttyd_password": ttyd_password,
            }},
        )
        if start:
            try:
                self.store.start(record["id"])
            except VMError:
                # Do not leave a half-created VM counting against the key's quota.
                log.exception("API VM %s failed to start; removing it", record["id"])
                try:
                    self._delete_record(record["id"])
                except VMError:
                    log.exception("could not clean up API VM %s", record["id"])
                raise
        return self._status(self.store._read(record["id"]))

    def status(self, key_token: str, vm_id: str, wait: int = 0) -> Dict[str, Any]:
        key_ref = key_reference(key_token)
        deadline = time.time() + max(0, min(int(wait), 900))
        while True:
            vm = self._owned(vm_id, key_ref)
            result = self._status(vm)
            if result["status"] == "ready" or time.time() >= deadline:
                return result
            time.sleep(5)

    def delete(self, key_token: str, vm_id: str) -> Dict[str, Any]:
        key_ref = key_reference(key_token)
        self._owned(vm_id, key_ref)
        return self._delete_record(vm_id)

    def _delete_record(self, vm_id: str) -> Dict[str, Any]:
        if self.store._running(vm_id):
            self.store.stop(vm_id)
        self.store.delete(vm_id)
        return {"ok": True, "id": vm_id, "deleted": True}

    def expire_due(self) -> List[str]:
        """Remove API VMs whose TTL has passed. Called by the VM scheduler."""
        removed: List[str] = []
        now = time.time()
        for vm in self._api_records():
            if vm["api"]["expires_at"] <= now:
                try:
                    self._delete_record(vm["id"])
                    removed.append(vm["id"])
                except VMError:
                    log.exception("could not remove expired API VM %s", vm["id"])
        return removed

    # ------------------------------------------------------------ callback
    def record_callback(self, callback_token: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Store links reported by the guest. The token in the URL is the only credential."""
        if not isinstance(callback_token, str) or not _SECRET.fullmatch(callback_token):
            raise LookupError("unknown callback")
        wanted = _hash(callback_token)
        match = None
        for vm in self._api_records():
            if secrets.compare_digest(vm["api"].get("callback_hash", ""), wanted):
                match = vm
                break
        if match is None:
            raise LookupError("unknown callback")
        ttyd = str(payload.get("ttyd") or "")
        sshx = str(payload.get("sshx") or "")
        ttyd_password = str(payload.get("ttyd_password") or "")
        if ttyd and not _TRY_URL.fullmatch(ttyd):
            raise ValueError("ttyd link must be a trycloudflare.com HTTPS address")
        if sshx and not _SSHX_URL.fullmatch(sshx):
            raise ValueError("sshx link must be an sshx.io HTTPS address")
        if ttyd_password and ttyd_password != match["api"].get("ttyd_password"):
            raise ValueError("ttyd credentials do not match this VM")
        from .vms import _LOCK
        with _LOCK:
            vm = self.store._read(match["id"])
            api = vm["api"]
            api["links"] = {"ttyd": ttyd, "sshx": sshx, "ttyd_user": TTYD_USER}
            api["ready"] = bool(ttyd and sshx)
            api["reported_at"] = time.time()
            vm["api"] = api
            self.store._write(vm)
        return {"ok": True, "ready": api["ready"]}
