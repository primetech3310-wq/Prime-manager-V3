"""MongoDB studio: browse databases, collections and documents on a MongoDB server.

Connections are opened by the administrator with a mongodb:// or mongodb+srv://
URI. The URI is kept only in server memory for the session; the browser receives an
opaque connection id. Writes are refused unless the connection was opened with
``allow_writes``. Requires the ``pymongo`` package, which is imported lazily so the
rest of the panel works without it.
"""
from __future__ import annotations

import secrets
import threading
import time
from typing import Any, Dict, Optional

IDLE_SECONDS = 15 * 60
MAX_CONNECTIONS = 5
MAX_DOCS = 100
MAX_URI = 2048
_LOCK = threading.RLock()


class MongoError(ValueError):
    pass


def _pymongo():
    try:
        import pymongo  # noqa: F401
        from bson import json_util
    except ImportError as exc:
        raise MongoError("MongoDB support needs the pymongo package: run `pip install pymongo` on the host") from exc
    return pymongo, json_util


def _name_ok(value: str, label: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 120 or "\x00" in value or value.startswith("$"):
        raise MongoError(f"{label} name is not valid")
    if any(ch in value for ch in '/\\. "$'):
        raise MongoError(f"{label} name contains characters MongoDB does not allow")
    return value


def _parse(text: str, json_util, label: str) -> Dict[str, Any]:
    if not text or not text.strip():
        return {}
    if len(text) > 65536:
        raise MongoError(f"{label} is too large")
    try:
        value = json_util.loads(text)
    except ValueError as exc:
        raise MongoError(f"{label} must be valid JSON (extended JSON such as ObjectId is allowed)") from exc
    if not isinstance(value, dict):
        raise MongoError(f"{label} must be a JSON object")
    return value


class MongoStudio:
    def __init__(self):
        self._sessions: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------- sessions
    def _sweep(self) -> None:
        now = time.time()
        for sid in list(self._sessions):
            if now - self._sessions[sid]["last_used"] > IDLE_SECONDS:
                self._close(sid)

    def _close(self, sid: str) -> None:
        session = self._sessions.pop(sid, None)
        if session:
            try:
                session["client"].close()
            except Exception:  # noqa: BLE001
                pass

    def _get(self, sid: str) -> Dict[str, Any]:
        with _LOCK:
            self._sweep()
            session = self._sessions.get(sid)
            if not session:
                raise MongoError("This MongoDB connection has expired or was closed. Connect again.")
            session["last_used"] = time.time()
            return session

    def connect(self, uri: str, allow_writes: bool = False) -> Dict[str, Any]:
        if not isinstance(uri, str) or len(uri) > MAX_URI:
            raise MongoError("Connection string is required")
        uri = uri.strip()
        if not (uri.startswith("mongodb://") or uri.startswith("mongodb+srv://")):
            raise MongoError("The connection string must start with mongodb:// or mongodb+srv://")
        pymongo, _ = _pymongo()
        with _LOCK:
            self._sweep()
            if len(self._sessions) >= MAX_CONNECTIONS:
                raise MongoError(f"At most {MAX_CONNECTIONS} MongoDB connections are open; close one first")
            try:
                client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=5000, connectTimeoutMS=5000,
                                             appname="prime-studio")
                client.admin.command("ping")
                info = client.admin.command("buildInfo")
            except Exception as exc:  # noqa: BLE001 - driver errors vary by version
                raise MongoError("Could not connect: " + _describe(exc)) from exc
            sid = secrets.token_urlsafe(18)
            host = _redact(uri)
            self._sessions[sid] = {"client": client, "allow_writes": bool(allow_writes),
                                   "host": host, "last_used": time.time()}
        return {"id": sid, "host": host, "version": info.get("version", ""),
                "allow_writes": bool(allow_writes), "databases": self.databases(sid)["items"]}

    def disconnect(self, sid: str) -> Dict[str, Any]:
        with _LOCK:
            self._close(sid)
        return {"ok": True}

    def status(self, sid: str) -> Dict[str, Any]:
        session = self._get(sid)
        return {"id": sid, "host": session["host"], "allow_writes": session["allow_writes"]}

    # ------------------------------------------------------------ reads
    def databases(self, sid: str) -> Dict[str, Any]:
        session = self._get(sid)
        try:
            names = session["client"].list_database_names()
            items = []
            for name in names:
                stats = session["client"][name].command("dbStats", scale=1)
                items.append({"name": name, "size": stats.get("storageSize", 0),
                              "collections": stats.get("collections", 0)})
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Could not list databases: " + _describe(exc)) from exc
        return {"items": items}

    def collections(self, sid: str, db: str) -> Dict[str, Any]:
        session = self._get(sid)
        db = _name_ok(db, "Database")
        try:
            names = sorted(session["client"][db].list_collection_names())
            items = []
            for name in names:
                count = session["client"][db][name].estimated_document_count()
                items.append({"name": name, "documents": count})
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Could not list collections: " + _describe(exc)) from exc
        return {"items": items}

    def find(self, sid: str, db: str, coll: str, filter_text: str = "", limit: int = 20,
             skip: int = 0) -> Dict[str, Any]:
        session = self._get(sid)
        pymongo, json_util = _pymongo()
        db = _name_ok(db, "Database")
        coll = _name_ok(coll, "Collection")
        limit = max(1, min(int(limit), MAX_DOCS))
        skip = max(0, int(skip))
        query = _parse(filter_text, json_util, "Filter")
        try:
            cursor = session["client"][db][coll].find(query).skip(skip).limit(limit)
            docs = [json_util.loads(json_util.dumps(doc)) for doc in cursor]
            total = session["client"][db][coll].count_documents(query, maxTimeMS=5000)
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Query failed: " + _describe(exc)) from exc
        return {"items": docs, "total": total, "limit": limit, "skip": skip}

    # ----------------------------------------------------------- writes
    def _writable(self, sid: str) -> Dict[str, Any]:
        session = self._get(sid)
        if not session["allow_writes"]:
            raise MongoError("This connection is read-only. Connect again with writes enabled.")
        return session

    def insert(self, sid: str, db: str, coll: str, document_text: str) -> Dict[str, Any]:
        session = self._writable(sid)
        _, json_util = _pymongo()
        db = _name_ok(db, "Database")
        coll = _name_ok(coll, "Collection")
        document = _parse(document_text, json_util, "Document")
        if not document:
            raise MongoError("Document cannot be empty")
        try:
            result = session["client"][db][coll].insert_one(document)
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Insert failed: " + _describe(exc)) from exc
        return {"ok": True, "id": json_util.loads(json_util.dumps({"_id": result.inserted_id}))["_id"]}

    def delete(self, sid: str, db: str, coll: str, id_text: str) -> Dict[str, Any]:
        session = self._writable(sid)
        _, json_util = _pymongo()
        db = _name_ok(db, "Database")
        coll = _name_ok(coll, "Collection")
        if not id_text or len(id_text) > 512:
            raise MongoError("Document _id is required")
        try:
            doc_id = json_util.loads(id_text)
        except ValueError:
            doc_id = id_text
        try:
            result = session["client"][db][coll].delete_one({"_id": doc_id})
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Delete failed: " + _describe(exc)) from exc
        return {"ok": True, "deleted": result.deleted_count}

    def drop_collection(self, sid: str, db: str, coll: str, confirm: str) -> Dict[str, Any]:
        session = self._writable(sid)
        db = _name_ok(db, "Database")
        coll = _name_ok(coll, "Collection")
        if confirm != coll:
            raise MongoError("Type the collection name exactly to confirm the drop")
        if coll.startswith("system."):
            raise MongoError("System collections cannot be dropped here")
        try:
            session["client"][db].drop_collection(coll)
        except Exception as exc:  # noqa: BLE001
            raise MongoError("Drop failed: " + _describe(exc)) from exc
        return {"ok": True}


def _redact(uri: str) -> str:
    """Show scheme, host and database but never credentials."""
    scheme, _, rest = uri.partition("://")
    if "@" in rest:
        rest = rest.split("@", 1)[1]
    return scheme + "://" + rest.split("?", 1)[0][:200]


def _describe(exc: Exception) -> str:
    text = str(exc).strip()
    return (text[:300] + "…") if len(text) > 300 else (text or exc.__class__.__name__)
