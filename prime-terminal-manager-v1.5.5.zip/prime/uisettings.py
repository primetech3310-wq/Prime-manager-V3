"""Panel-wide appearance and performance settings (controlled from Settings → Appearance).

The values are stored once on the server so every browser that opens the panel
gets the same look. Reads are public (the values contain no secrets and the
login screen needs them); writes require an authenticated, CSRF-checked
request and are written to the audit log.

Python 3.8 compatible.
"""
from __future__ import annotations

import json
import os
import re
import threading
from typing import Any, Dict

from .config import Config

HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")

DEFAULTS: Dict[str, Any] = {
    "theme": "dark",            # dark | light | auto (follow the OS)
    "accent": "#0a84ff",        # accent colour, #rrggbb
    "glass_blur": 30,           # backdrop blur radius in px, 0 disables blur
    "radius": 1.0,              # corner-radius multiplier, 0.6 – 1.5
    "motion": "full",           # full | reduced | off
    "ambient": True,            # animated liquid background
    "performance": "auto",      # auto | quality | performance
    "browser_enabled": True,    # embedded browser on/off
    "browser_home": "https://duckduckgo.com/",
    "secondary_accent": "",
    "ambient_opacity": 100,
    "ambient_speed": 100,
    "ambient_size": 100,
    "glass_saturation": 175,
    "sidebar_width": 248,
    "topbar_height": 62,
    "mobilebar_height": 64,
    "font_size": 15,
    "button_radius": 14,
    "orb_one": True,
    "orb_two": True,
    "orb_three": True,
    "custom_css": "",
}

RANGES = {
    "ambient_opacity": (0, 200), "ambient_speed": (25, 300),
    "ambient_size": (50, 200), "glass_saturation": (0, 300),
    "sidebar_width": (180, 360), "topbar_height": (48, 100),
    "mobilebar_height": (52, 100), "font_size": (12, 22),
    "button_radius": (0, 30),
}

CHOICES = {
    "theme": ("dark", "light", "auto"),
    "motion": ("full", "reduced", "off"),
    "performance": ("auto", "quality", "performance"),
}


class UISettingsError(ValueError):
    """Raised for a value the panel refuses to store."""


def _check(key: str, value: Any) -> Any:
    if key not in DEFAULTS:
        raise UISettingsError(f"unknown setting: {key}")
    if key in CHOICES:
        if value not in CHOICES[key]:
            raise UISettingsError(f"{key} must be one of {', '.join(CHOICES[key])}")
        return value
    if key in ("accent", "secondary_accent"):
        if key == "secondary_accent" and value == "":
            return value
        if not isinstance(value, str) or not HEX_RE.match(value):
            raise UISettingsError("accent must be a colour like #0a84ff")
        return value.lower()
    if key == "glass_blur":
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 40:
            raise UISettingsError("glass_blur must be a number between 0 and 40")
        return int(round(value))
    if key == "radius":
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0.6 <= value <= 1.5:
            raise UISettingsError("radius must be a number between 0.6 and 1.5")
        return round(float(value), 2)
    if key in RANGES:
        lo, hi = RANGES[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
            raise UISettingsError(f"{key} must be between {lo} and {hi}")
        return int(round(value))
    if key == "custom_css":
        if not isinstance(value, str) or len(value) > 65536 or "\x00" in value:
            raise UISettingsError("custom_css must be text of at most 65536 characters")
        return value
    if key in ("ambient", "browser_enabled", "orb_one", "orb_two", "orb_three"):
        if not isinstance(value, bool):
            raise UISettingsError(f"{key} must be true or false")
        return value
    if key == "browser_home":
        if not isinstance(value, str) or len(value) > 512:
            raise UISettingsError("browser_home must be a web address of at most 512 characters")
        value = value.strip()
        if value and not value.lower().startswith(("http://", "https://")):
            raise UISettingsError("browser_home must start with http:// or https://")
        return value or DEFAULTS["browser_home"]
    raise UISettingsError(f"unsupported setting: {key}")  # pragma: no cover


def validate(partial: Dict[str, Any]) -> Dict[str, Any]:
    """Return a cleaned copy of ``partial`` or raise UISettingsError."""
    if not isinstance(partial, dict):
        raise UISettingsError("expected an object of settings")
    return {key: _check(key, value) for key, value in partial.items()}


class UISettingsStore:
    """Atomic JSON file in the data directory (``ui-settings.json``)."""

    def __init__(self, cfg: Config) -> None:
        self.path = os.path.join(cfg.data_dir, "ui-settings.json")
        self._lock = threading.Lock()

    def _read_raw(self) -> Dict[str, Any]:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self) -> Dict[str, Any]:
        merged = dict(DEFAULTS)
        for key, value in self._read_raw().items():
            if key in DEFAULTS:
                try:
                    merged[key] = _check(key, value)
                except UISettingsError:
                    pass  # a corrupt value falls back to the default
        return merged

    def update(self, partial: Dict[str, Any]) -> Dict[str, Any]:
        clean = validate(partial)
        with self._lock:
            current = self.get()
            current.update(clean)
            self._write(current)
            return current

    def reset(self) -> Dict[str, Any]:
        with self._lock:
            self._write(dict(DEFAULTS))
            return dict(DEFAULTS)

    def _write(self, data: Dict[str, Any]) -> None:
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
            fh.write("\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)
