#!/bin/bash
# Live checks for Prime Terminal Manager sandbox (and smoke). Exits non-zero on failure.
set -euo pipefail
BASE="${PRIME_BASE:-http://127.0.0.1:8080}"
KEY_FILE="${PRIME_TEST_KEY_FILE:-/tmp/.prime_test_key}"
if [ ! -f "$KEY_FILE" ]; then
  echo "missing key file $KEY_FILE" >&2
  exit 1
fi
API_KEY=$(cat "$KEY_FILE")
hdr=(-H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" -H "Accept: application/json")

echo "== health =="
curl -sf "$BASE/api/health" | grep -q '"ok":true'

echo "== sandbox internet (SSHx) =="
START=$(date +%s)
RESP=$(curl -sf -X POST "$BASE/API/sandbox?wait=90" "${hdr[@]}" -d '{"network":"internet","ttl":300,"memory":512}')
END=$(date +%s)
echo "$RESP" | grep -q '"status":"ready"'
echo "$RESP" | grep -q 'sshx.io/s/'
echo "SSHx ready in $((END-START))s"

SID=$(echo "$RESP" | python3 -c 'import sys,json; print(json.load(sys.stdin)["id"])')

echo "== other key 401/404 =="
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X GET "$BASE/API/sandbox/$SID" -H "Authorization: Bearer invalid" -H "Accept: application/json")
[ "$CODE" = "401" ] || [ "$CODE" = "404" ]

echo "== delete =="
curl -sf -X DELETE "$BASE/API/sandbox/$SID" -H "Authorization: Bearer $API_KEY" | grep -q '"ok":true'

echo "== network none =="
RESP2=$(curl -sf -X POST "$BASE/API/sandbox?wait=15" "${hdr[@]}" -d '{"network":"none","ttl":300,"memory":256}')
echo "$RESP2" | grep -q 'network (none)'
SID2=$(echo "$RESP2" | python3 -c 'import sys,json; print(json.load(sys.stdin)["id"])')
curl -sf -X DELETE "$BASE/API/sandbox/$SID2" -H "Authorization: Bearer $API_KEY" >/dev/null

echo "ALL LIVE CHECKS PASSED"
