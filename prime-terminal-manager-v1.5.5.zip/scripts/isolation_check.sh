#!/bin/sh
# Live isolation check for proot workspaces. Run as root on the panel host, after the
# workspace base image exists (a first workspace request, or scripts/build_sandbox_rootfs.sh).
#
#   sh scripts/isolation_check.sh <panel data dir>
#
# It starts a "host service" on port 5555 and a host process, then starts a real
# workspace whose only job is to try to reach them. Expected: every probe fails.
set -eu
DATA="${1:?usage: isolation_check.sh <panel data dir>}"
PANEL="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'kill $SRV 2>/dev/null || true; rm -rf "$WORK"' EXIT INT TERM

mkdir -p "$WORK/www" && echo "HOST SECRET SERVICE" > "$WORK/www/index.html"
python3 -m http.server 5555 --bind 0.0.0.0 --directory "$WORK/www" >/dev/null 2>&1 &
SRV=$!
sleep 1

RESULT="$(PANEL="$PANEL" DATA="$DATA" HOSTPID="$SRV" python3 - <<'PY'
import os, sys, time, pathlib
sys.path.insert(0, os.environ["PANEL"])
from prime import freeroot, freeroot_isolation as iso
from prime.freeroot import FreeRootManager, panel_owner

host_pid = int(os.environ["HOSTPID"])
freeroot.GUEST_SCRIPT = iso.probe_script(host_pid, 5555) + "; sleep 1"
mgr = FreeRootManager(os.environ["DATA"])
record = mgr.create_for(panel_owner("isolation-check"), 300, "isolation-check")
log = pathlib.Path(os.environ["DATA"]) / "freeroot" / "instances" / record["id"] / "console.log"
for _ in range(60):
    if log.exists() and "PROCESSES=" in log.read_text(errors="replace"):
        break
    time.sleep(1)
time.sleep(2)
print(log.read_text(errors="replace"))
mgr.delete_for(panel_owner("isolation-check"), record["id"])
PY
)"
echo "$RESULT"
echo "$RESULT" | grep -q "LOOPBACK=000" && echo "PASS loopback: host service on 127.0.0.1:5555 is not reachable" || echo "FAIL loopback: host service reachable"
echo "$RESULT" | grep -q "GATEWAY=000" && echo "PASS gateway: host service via 10.0.2.2:5555 is not reachable" || echo "FAIL gateway: host service reachable"
echo "$RESULT" | grep -q "HOSTPID_VISIBLE=no" && echo "PASS pid: host process is not visible or signalable" || echo "FAIL pid: host process visible"
echo "$RESULT" | grep -q "INTERNET=200" && echo "PASS internet: outbound access works" || echo "NOTE internet: outbound access did not return 200 (check the helper and DNS)"
