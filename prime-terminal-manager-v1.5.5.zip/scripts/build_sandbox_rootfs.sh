#!/bin/sh
# Builds the shared, read-only root filesystem that every /API/sandbox sandbox overlays.
#
#   sudo sh scripts/build_sandbox_rootfs.sh <panel data dir> [suite]
#
# Needs debootstrap on the host, or set PRIME_SANDBOX_ROOTFS_SRC to an existing
# root filesystem directory (for example one exported from a container image).
# Run once; sandboxes then start without copying anything.
#
# Pre-installs the sshx binary into the template so boot does not depend on
# downloading it at request time. Download remains a fallback in the guest script.
set -eu
DATA="${1:?usage: build_sandbox_rootfs.sh <panel data dir> [suite]}"
SUITE="${2:-bookworm}"
MIRROR="${PRIME_SANDBOX_MIRROR:-}"
TARGET="$DATA/sandboxes/template"
NEW="$TARGET.new"
rm -rf "$NEW"
mkdir -p "$(dirname "$TARGET")"
if [ -n "${PRIME_SANDBOX_ROOTFS_SRC:-}" ]; then
  mkdir -p "$NEW"
  cp -a "$PRIME_SANDBOX_ROOTFS_SRC"/. "$NEW"/
else
  command -v debootstrap >/dev/null 2>&1 || { echo "install debootstrap first" >&2; exit 1; }
  if [ -z "$MIRROR" ]; then
    case "$SUITE" in
      focal|jammy|noble|bionic)
        MIRROR="http://archive.ubuntu.com/ubuntu"
        ;;
      *)
        MIRROR="http://deb.debian.org/debian"
        ;;
    esac
  fi
  debootstrap --variant=minbase --include=curl,ca-certificates "$SUITE" "$NEW" "$MIRROR"
fi
mkdir -p "$NEW/proc" "$NEW/dev" "$NEW/root" "$NEW/run/prime-out" "$NEW/tmp" "$NEW/usr/local/bin"

# Pre-install sshx into the template when a host binary is available.
if command -v sshx >/dev/null 2>&1; then
  cp "$(command -v sshx)" "$NEW/usr/local/bin/sshx"
  chmod 755 "$NEW/usr/local/bin/sshx"
  echo "preinstalled host sshx into template"
elif [ -x /usr/local/bin/sshx ]; then
  cp /usr/local/bin/sshx "$NEW/usr/local/bin/sshx"
  chmod 755 "$NEW/usr/local/bin/sshx"
  echo "preinstalled /usr/local/bin/sshx into template"
else
  echo "sshx not found on host; guest will download on first use" >&2
fi

rm -rf "$TARGET"
mv "$NEW" "$TARGET"
chmod 0755 "$TARGET"
echo "sandbox template ready: $TARGET"
