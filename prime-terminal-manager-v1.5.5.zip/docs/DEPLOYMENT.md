<!-- coderabbit-ai-generated:v1 -->

# Install and run

Extract the release ZIP and run `bash panel.sh`. Keep the extracted application folder intact. The existing installer creates the Python environment, account, data directory and an appropriate service or background launcher. It verifies HTTP health before reporting success. Use `bash panel.sh start|stop|restart|status|logs` for service control. The web panel has full administrative access to the account running it.

For a direct source launch, install FastAPI, Uvicorn and websockets into a Python virtual environment and run `python run.py`. Set `PRIME_HOST`, `PRIME_PORT`, and `PRIME_DATA_DIR` as required. The validated environment used Python 3.14.4, FastAPI 0.165.0, Uvicorn 0.54.0 and websockets 17.4. `panel.sh` selects older compatible packages for Python 3.8.

## VMs without KVM

Run `bash panel.sh vm-deps` to check/install QEMU and cloud-init tools on Debian/Ubuntu. Choose Virtual machines → Download Debian 12 cloud image. Enter a VM name, guest username and password. Select **Software emulation** to force QEMU TCG, or Automatic to try KVM and fall back to TCG. Create, then Start. The VM list shows a loopback SSH port. On this server, connect with `ssh -p PORT USER@127.0.0.1`. <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:7c942dd6b8898ef27556e25c27972911a7fa27ae63e2584deee34ef40b342567 -->

Boot log displays the real serial output. Graphical console opens the authenticated guest display without a public VNC listener. Recovery & schedules provides offline disk backups/snapshots and persistent automation; see VMS.md for consistency, retention and restore behavior.

<!-- /coderabbit-ai-generated:v1 --> A Debian cloud guest booted and accepted SSH under TCG during validation; KVM is not required. Software emulation is slower than hardware acceleration.

## Private terminal workspaces

Run `bash panel.sh workspace-deps`, then open Private workspaces and build the runtime. This needs Linux x86_64, a running local rootful Docker daemon, host iptables access, outbound HTTPS and sufficient storage. It works without KVM. The panel service needs root or passwordless sudo to perform its Docker/firewall operations. Docker control is host administrator authority; expose only the provisioning API keys to automation, not your admin account.

Default Limited mode applies memory, CPU and process limits and requires delegated cgroups. The task sandbox rejects those limits. The explicit Shared mode was tested here: it shares host resources while retaining separate filesystem, PID and filtered network namespaces. Shared mode has no per-workspace CPU/memory/PID limits and cannot prevent resource exhaustion. It is never selected as a silent fallback. Kernels that prohibit Docker namespaces or host firewall management cannot provide this feature; provisioning stops rather than issuing a host shell.

Configure `public_url` in the panel config to the actual HTTPS panel URL, particularly behind a reverse proxy. See WORKSPACES.md for APIs. Quick tunnel addresses require Cloudflare availability and can change after restart. A suspended or stopped host cannot keep terminals available.

## Updating

Open Panel updates, upload a trusted release ZIP, validate, then install. See UPDATES.md. Application updates preserve the configured data directory and virtual environment. Updates can replace executable code; only trusted administrators should have panel credentials.

## Checks

Run `python -m unittest discover -s tests -p 'test_*.py' -v` with the panel virtualenv. This includes real QEMU lifecycle checks when QEMU is installed, plus an actual update/restart/rollback test in disposable installs. Run `PYTHONPATH=. python tests/workspace_smoke.py` for real external workspace providers; add `--shared` only to explicitly test shared-resource mode. Build the runtime first. The smoke test creates synthetic workspaces and removes them afterward.
