<!-- coderabbit-ai-generated:v1 -->

# Private workspace APIs

The host admin panel and each workspace are separate processes and browser origins. Each workspace is a Docker container running UID 1000 with no Linux capabilities, no new privileges, a read-only system image, a private writable volume, its own PID/network/IPC namespaces and no mounted host paths, devices or Docker socket. Guests can operate their own processes and ports. They cannot address host processes through their PID namespace. The workspace panel has the original panel UI, scoped to that container. Host VM management, updates and provisioning controls are disabled inside it.

A dedicated bridge is created per workspace. Host INPUT and forwarding rules block new host connections, private LANs, loopback, link-local metadata, CGNAT, multicast and the host's local IPv4 addresses. New forwarded connections into a tenant are blocked. No host ports are published. IPv6 routing is not enabled. A real host-listener probe and rule checks run before a link is returned; missing required rules stop the affected container. Internet destinations remain available for outbound providers. Network policy covers the host interface addresses present at creation; changing the host network requires recreating workspaces. Docker shares the host kernel; it is not a hardware VM boundary.

## Setup

Build the workspace runtime from Private workspaces. The image includes the panel, SSHx 0.4.1, ttyd 1.7.7 and cloudflared 2026.11.1. Provider binaries are checksum checked during the build. The build copies the host public CA bundle so HTTPS interception using a locally trusted CA can work without disabling TLS verification. Only application source and runtime files enter the build context.

Set the panel's `public_url` to its actual external URL. Configure session lifetime, capacity, resource mode and the panel API name in Private workspaces. Defaults: `primeterminal`, 3600 seconds, ten workspaces, Limited mode with 1024 MiB/one CPU/256 processes. Shared mode intentionally omits those per-workspace quotas; it does not provide resource exhaustion protection. Host capacity displayed in the guest dashboard is a snapshot taken at creation; any workspace limits are described separately.

## API use

Create an API key in Private workspaces. Its value is displayed once and only its SHA-256 hash is saved. Keys can provision workspaces; admin credentials are required to list/delete workspaces, edit settings, build images or manage keys. Revocation rejects future calls with that key; existing workspaces continue until deleted or expired.

```sh
# Set these shell variables locally; do not put keys into URL query strings.
# PRIME_API_KEY=your-provisioning-key
# PANEL_URL=https://your-panel.example
curl --fail --header "Authorization: Bearer $PRIME_API_KEY" "$PANEL_URL/API/SSHx"
curl --fail --header "Authorization: Bearer $PRIME_API_KEY" "$PANEL_URL/API/primeterminal"
curl --fail --header "Authorization: Bearer $PRIME_API_KEY" "$PANEL_URL/API/ttyd"
```

Each authenticated GET or POST creates a NEW workspace. Do not prefetch or automatically retry a request with an unknown outcome; an interrupted request may have completed. By default the response is a plain link. Add `Accept: application/json` for ID, link, expiry and resource mode. No anonymous provisioning is enabled. Calls can take up to 90 seconds while providers connect; initial image building is an explicit admin operation.

SSHx returns its private provider link. ttyd returns a Cloudflare Quick Tunnel URL containing a random unguessable base path; the root path does not expose the shell. The panel API returns `https://your-panel.example/RANDOM_ID#SECRET`. Open the whole link including its fragment. The fixed host landing page validates the fragment and embeds the workspace from its separate Cloudflare HTTPS origin. It opens the real full-screen panel terminal; its toolbar can exit fullscreen to reach Files, Processes and other guest tools. Separate origins prevent guest content from using the host admin's cookies. Partitioned Secure cookies support the embedded session on current Chromium. Browsers without partitioned-cookie support may need to open the workspace origin as a top-level page.

The random link grants access to that workspace. Treat it as private. Only the creation response displays the link; the host stores a hash of the fragment. Guest provider state contains its own access information. The guest stops its processes at expiry even if the host panel is offline; the host reaper removes expired containers, networks and volumes while it is running. Delete permanently removes that workspace's data. Quick tunnels and SSHx require their external services and internet access.

## Validation observed

In explicit Shared mode, all three APIs issued real links. The private panel and ttyd ran commands through their browser terminals as UID 1000. SSHx created a browser terminal and executed a command verified by a file inside its container. Host gateway and peer-container connection attempts were blocked; peer files were not visible; signaling a host PID failed while the host process remained alive. Removing a required firewall rule caused that container to stop. Limited mode could not be run in this sandbox because of its threaded cgroup delegation. This does not establish compatibility with every VPS or restricted container kernel.
