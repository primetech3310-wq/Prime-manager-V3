<!-- coderabbit-ai-generated:v1 -->

# Release scope and verification

## Included

- Original responsive glass/liquid panel design, dashboard and terminal/file/process tools.
- Mobile file-row actions fit the viewport; loading and stale-navigation handling.
- Terminal fullscreen uses the existing toolbar control without a second floating exit button. Browser fullscreen control.
- 23 appearance/browser settings, including theme, primary/secondary accents, glass blur/saturation, corner scale, animation/motion/performance, background opacity/speed/size, three orb switches, sidebar/topbar/mobilebar sizes, font size, button radius, browser homepage/enabled and custom CSS. Preview, server persistence and reset; downloadable CSS.md guide.
- Real QEMU raw/QCOW2 VM creation, Debian image download/cache with SHA-512 manifest check, cloud-init non-root guest login, start/stop/delete, <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:2d97886a6c0dfc0124c6cbe101ccbcfe302d61386bdcf6b2eacd05761f82ca21 -->

real serial boot log and loopback SSH forwarding. Authenticated noVNC graphical console, offline disk backups with checksum-verified restoration, internal snapshots and persistent schedules with retention/status controls.

<!-- /coderabbit-ai-generated:v1 -->
- Explicit TCG software mode and automatic retry using TCG when KVM is inaccessible. No KVM required.
- Validated ZIP update with startup check, application backup, loading state, restart, failed-start rollback and preserved data.
- SSHx, private full panel and ttyd provisioning APIs with private links, hashed/revocable API keys, configurable panel endpoint name, configurable TTL/capacity and container isolation/network filtering.
- Explicit Limited and Shared resource modes with capability checks; expiry and deletion clean up tenant runtime resources. Current Chromium embedded panel sessions use partitioned cookies and a separate origin.

## Boundaries

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:581360b9630a11eb60c51f19a8b90a93470c3723c79b5bc7f0942ceed18a9424 -->

This release includes tenant invitations, explicit VM view/power/console delegation, a separate tenant workspace page, authenticator two-factor login with single-use recovery codes, and a billing ledger for plans, invoices and coupons. Existing accounts remain host administrators. See ACCOUNTS.md for permission and billing semantics.

Full vPanel Pro parity is still incomplete: distributed node/agent orchestration, SMTP email verification/password recovery, MongoDB studio, Discord/Telegram/webhook plugins, storage pools/ISO administration, advanced VM guest-agent/SSH file workflows, firewall management and some vPanel-specific appearance/automation tools have not been ported. The billing ledger does not process external payments. This build must not be described as 100% parity.

<!-- /coderabbit-ai-generated:v1 -->

Only x86_64 Docker workspace images are bundled. QEMU was tested with software emulation and Debian 12; KVM, other guest operating systems, other host distributions and arbitrary restricted kernels were not validated. Limited mode was blocked by this sandbox's cgroup delegation; Shared mode was explicitly tested and does not offer resource exhaustion protection. External terminal/tunnel providers can fail or interrupt sessions. These limits are visible rather than simulated.

See DEPLOYMENT.md, VMS.md, WORKSPACES.md and UPDATES.md for operation and validation. The original project README and archive remain intact in the source repository.

## Added in build 1.3.0

- VM provisioning API: `POST /API/vm` creates a Debian VM whose guest reports SSHx and ttyd links back to the panel. See docs/API.md.
- Firewall management (nftables or iptables) with staged apply, 90-second confirmation and automatic rollback.
- Storage pools and ISO administration with ISO 9660 signature checks, SHA-256 checksums and safe deletion.
- MongoDB studio: connect, browse databases, collections and documents, read-only by default, drop with typed confirmation.
- Distributed node orchestration: single-use enrollment tokens, agent heartbeats, and allow-listed commands (refresh, update, restart).
- Fixes: UDP sockets show UNCONN instead of CLOSE in listening ports; file list rows keep their action buttons on phones; Files view resets its state on each visit and has an animation safety net.
- Still not ported from vPanel: custom vPanel appearance and automation tools (list needed), SMTP recovery, Discord/Telegram/webhook plugins, VM guest-agent file workflows.

## Build 1.3.1

- Every VM (panel-created and API-created) uses the login `root` with the password `$PrimeTerminal@user#` by default. The VM form pre-fills these values and has a Show/Hide button.
- Guest credentials work without `cloud-localds`: the seed image is built with genisoimage, mkisofs or xorriso when those are installed.
- `panel.sh -p <port>` serves on that port. Run from a terminal, the script asks for the port; `--auto` picks the first free port from 8080.


## Build 1.3.3

- Sandbox API: `POST /API/sandbox` (plus `GET` and `DELETE` by id). Creates an isolated, owner-only environment that installs SSHx and returns the link.
- Backends: bubblewrap namespaces with overlay root and pasta networking (preferred); proot fallback with filesystem-only isolation, reported honestly in the response.
- `scripts/build_sandbox_rootfs.sh` builds the shared template.
- Tests: `tests/test_sandbox.py` (28 tests). Live bubblewrap, pasta and SSHx runs are not verified in the build environment; test them on the target host.

## Build 1.5.1

- New panel tab **Named proot workspace** (after Private workspaces): create a named workspace, see its SSHx link, copy it, delete it.
- Session endpoints `GET/POST /api/freeroot`, `GET /api/freeroot/status`, `GET/DELETE /api/freeroot/<id>` (CSRF on writes), owned by the signed-in user.
- `/API/freeroot` (bearer key) now prints the SSHx link by default, like `/API/sandbox`.
- Fixed: the base image had no curl, so SSHx could not install on a fresh host. curl and ca-certificates are now installed into the image during setup.
- proot: the host package is used when installed; the unpinned download is the fallback.
- Expired workspaces are removed by the maintenance loop.
- Tests: `tests/test_freeroot.py` (20 tests). The panel tab was rendered in Chromium at 390 and 1280 px with a stubbed API.
- Not verified here: a live proot workspace with SSHx (no internet in the build environment), and the server-side session routes (FastAPI not installed).

## Build 1.5.2

- Port and process isolation per panel account. Each account sees and can signal only the sockets and processes owned by the OS user it is mapped to.
  - Applies to `/api/system/ports`, `/api/system/processes`, `/api/system/process/{pid}`, `/api/system/process/{pid}/signal`, and `/api/toolkit/ports/{port}`. Hidden items return 404.
  - The setup account (first account) keeps `*` (everything), so an existing install is unchanged.
  - Other accounts see nothing until mapped. Map them with an administrator session:
    `PUT /api/system/port-scope/<username>` with body `{"os_user": "<os user>"}` plus the CSRF header.
    `GET /api/system/port-scope` lists mappings. `DELETE /api/system/port-scope/<username>` removes one.
  - Limit: the panel usually runs as root, so root-owned processes are shared by every account mapped to root. Give accounts separate OS users to isolate them.
- Tests: `tests/test_port_scope.py` (12 tests).
- Not verified here: the live routes (FastAPI not installed) and a two-OS-user kill test. Test both on the host.

## Build 1.5.3

- Named proot workspaces are isolated. proot runs inside bubblewrap with its own PID, IPC, UTS and network namespaces. A workspace cannot see or signal host processes, and cannot reach host services such as `127.0.0.1:5555`.
- Outbound internet through pasta or slirp4netns (slirp with `--disable-host-loopback`).
- Hosts without the namespaces refuse to start workspaces. `PRIME_FREEROOT_ALLOW_WEAK=1` opts into a shared, labelled WEAK mode.
- `scripts/isolation_check.sh` runs a live check on the host: a host service on 5555, a host process, and a probe workspace.
- Tests: `tests/test_freeroot_isolation.py` (16 tests), plus the updated `tests/test_freeroot.py`.
- Not verified here: the live namespace run. This build environment has no bubblewrap, slirp4netns or internet. Run `scripts/isolation_check.sh` on the host before relying on it.

## Build 1.5.4

- Fixed: creating a workspace returned "Request failed (504)". The first request built the Ubuntu base image before answering, which took longer than the proxy allows. Creation now returns at once with status `preparing`. The base image is built and the workspace started in the background.
- A failed base-image build is shown on the workspace with its error, and the panel keeps running.
- `POST /API/freeroot` waits up to 50 seconds by default (proxies cut longer requests). Poll `status_url` for later progress.
- Tests: 37 freeroot tests, including background build and failure reporting.

## Build 1.5.5

- Fixed the 504 on creating a workspace. Every request built a new manager, and every manager re-ran the bubblewrap and pasta host probes (each up to 10 s). Creation and the page's status call both waited on them, so slow hosts timed out at the proxy.
  - The host probe now runs once per panel process, in the background at startup (`prime/sandbox.py: cached_backends`). Requests read the cached result and never run the probe.
  - The isolation decision is made by the background worker. A refusal (no namespaces) appears on the workspace as its error, not as a failed request.
  - The sandbox API uses the same cache.
- Tests: freeroot 37 pass; the refusal test now checks the background path.
