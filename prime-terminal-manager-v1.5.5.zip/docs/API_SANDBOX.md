# Sandbox API

Bearer key: Authorization: Bearer $API_KEY

Create:
curl -X POST http://HOST:PORT/API/sandbox?wait=90 -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" -H "Accept: application/json" -d "{\"network\":\"internet\",\"ttl\":600,\"memory\":512}"

Status: GET /API/sandbox/{id}
Delete: DELETE /API/sandbox/{id}
Other key -> 404; bad key -> 401
