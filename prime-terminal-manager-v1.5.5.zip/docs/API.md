# Provisioning API

All provisioning calls use a bearer key created under **Private workspaces → API keys**.
The key value is shown once. Send it as `Authorization: Bearer <key>`.

## Private workspaces (SSHx, ttyd, full panel)

| Call | Result |
|---|---|
| `GET` or `POST /API/sshx` | Creates an SSHx session in a private container. Returns the link. |
| `GET` or `POST /API/<alias>` | Creates a full private panel. The default alias is `primeterminal`; the admin can rename it. Returns `https://<panel>/<id>#<secret>`. |
| `GET` or `POST /API/ttyd` | Creates a ttyd terminal behind a Cloudflare quick tunnel. Returns the `*.trycloudflare.com` link. |

Add `Accept: application/json` to receive the id, link and expiry as JSON.
Creating a workspace can take up to 90 seconds.

## Virtual machines

### Create

```
POST /API/vm
Authorization: Bearer <key>
Content-Type: application/json

{"name": "build-box", "memory": 2048, "cpus": 2, "ttl": 3600, "image": "debian"}
```

Optional query string: `?wait=600` waits up to 600 seconds for the links before responding.

Response (`202` while booting, `200` when ready):

```json
{
  "id": "api-1a2b3c",
  "status": "booting",
  "running": true,
  "expires_at": 1795000000,
  "status_url": "/API/vm/<id>",
  "guest_login": {"user": "root", "password": "$PrimeTerminal@user#"}
}
```

When the guest reports back, the status becomes `ready` and includes:

- `sshx`: the SSHx session link
- `ttyd`: the browser terminal link (`https://…trycloudflare.com`)
- `ttyd_credentials`: `{user, password}` for the ttyd login

Every VM uses the login `root` with the password `$PrimeTerminal@user#`, as requested. Root SSH with a password is enabled.
Security note: the SSH port is reachable only from the panel host (loopback), but anyone with shell access to the host can log in as root with this known password. Change `GUEST_PASSWORD` in `prime/vm_api.py` if the host has other users.

### Status

```
GET /API/vm/<id>            (add ?wait=N to long-poll)
```

Only the key that created a VM can read it. Other keys receive `404`.

### Delete

```
DELETE /API/vm/<id>
```

### How the links get back to the panel

The guest installs ttyd, cloudflared and sshx through cloud-init. It then posts its links to
`http://10.0.2.2:<panel port>/API/vm-callback/<token>`. QEMU's user networking routes
`10.0.2.2` to the panel host, and the random token in the URL is the only credential.

Limits and behaviour:

- Each key may have up to 5 active API VMs.
- TTL is 300 to 86400 seconds, and expired VMs are removed automatically.
- Booting under software emulation (no KVM) is slow. Allow several minutes for the first boot.
- ttyd and cloudflared do not restart automatically after a guest reboot. Create a new VM to get fresh links.
- If the panel binds to a specific address other than `0.0.0.0` or `127.0.0.1`, the guest may not reach the callback. Bind to `0.0.0.0` for VM links.

## Admin APIs

These require an administrator session and the CSRF header on writes. The only public endpoints
are the node enrollment and heartbeat calls, which use their own credentials.

| Area | Endpoints |
|---|---|
| Firewall | `GET /api/firewall`, `GET /api/firewall/live`, `POST /api/firewall/stage`, `POST /api/firewall/confirm`, `POST /api/firewall/cancel` |
| Storage | `GET/POST /api/storage/pools`, `DELETE /api/storage/pools/{id}`, `GET/POST /api/storage/pools/{id}/isos?name=…` (raw body), `GET …/isos/{name}/checksum`, `DELETE …/isos/{name}` |
| MongoDB | `POST /api/mongo/connect`, `POST /api/mongo/disconnect`, `GET /api/mongo/databases`, `GET /api/mongo/collections`, `POST /api/mongo/find`, `POST /api/mongo/insert`, `POST /api/mongo/delete`, `POST /api/mongo/drop` |
| Nodes | `GET /api/nodes`, `POST /api/nodes/enrollment`, `POST /api/nodes/{id}/command`, `DELETE /api/nodes/{id}`; public: `POST /api/nodes/enroll`, `POST /api/nodes/{id}/heartbeat`, `GET /api/nodes/agent.py` |

### Firewall safety

Changes are applied, then held for 90 seconds. If nobody confirms within that time, or the panel
restarts first, the previous rules are restored. The panel and SSH ports are always allowed, so a
change cannot lock out the admin's own session.

### MongoDB

Requires `pip install pymongo` on the host. Connections live in server memory and expire after 15
minutes of inactivity. Writes are refused unless the connection was opened with "allow writes".

### Node agents

```
curl -fsSL https://<panel>/api/nodes/agent.py -o /opt/prime-node/node_agent.py
python3 /opt/prime-node/node_agent.py enroll --panel https://<panel> --token pne_…
python3 /opt/prime-node/node_agent.py run
```

Enrollment tokens are single-use and expire after one hour. Agents send heartbeats every 20 seconds.
The panel can queue only `refresh`, `update` (verified by SHA-256) and `restart`.

## Plain-text output (curl)

Send a request without `Accept: application/json` and `POST /API/vm` waits for the guest to boot (up to 15 minutes),
then prints the links:

```
curl -X POST -H "Authorization: Bearer <key>" http://<panel>/API/vm
SSHx:  https://sshx.io/s/...
ttyd:  https://....trycloudflare.com
```

## Sandboxes (isolated, SSHx only)

`POST /API/sandbox` creates a short-lived Linux environment that installs SSHx and returns the link.
It uses the same bearer key as the VM API, and only that key can read or delete the sandbox.

```
curl -X POST -H "Authorization: Bearer <key>" -H "Content-Type: application/json" \
     -d '{"memory": 1024, "ttl": 3600, "backend": "auto", "network": "internet"}' \
     http://<panel>/API/sandbox
SSHx:  https://sshx.io/s/...
isolation: namespaces: pid, ipc, uts, mount, network (pasta, outbound only); capabilities dropped
```

- `GET /API/sandbox/<id>?wait=N` and `DELETE /API/sandbox/<id>` work like the VM calls.
- `backend`: `auto` (default), `bwrap` or `proot`. `auto` uses bubblewrap when it works here and falls back to proot.
- `network`: `internet` (outbound only, through pasta) or `none`.
- Limits: 256–8192 MB memory budget (a virtual-memory cap at three times that value), TTL 300–86400 s, up to 3 active per key and 20 on the host.

### Isolation by backend

| Backend | What is isolated |
|---|---|
| `bwrap` | Own PID, IPC, UTS and mount namespaces; all capabilities dropped; nested user namespaces disabled; the host filesystem is not visible. The root is an overlay of the shared template, so creation copies nothing. With `internet`, a pasta network namespace with no inbound ports. |
| `proot` | Filesystem view only. Processes, and the network for `internet`, are shared with the host. The response says so in `isolation`. |

Full VMs (QEMU/KVM) remain on `/API/vm`, for hosts with KVM.

### Host requirements

1. Build the template once, as root: `sudo sh scripts/build_sandbox_rootfs.sh <data dir>`. It needs `debootstrap`, or set `PRIME_SANDBOX_ROOTFS_SRC` to an existing root filesystem.
2. Install `bubblewrap` (`bwrap` 0.5 or newer for overlays) and `passt` (provides `pasta`) for isolated internet access. Install `proot` as a fallback.
3. Allow unprivileged user namespaces for bubblewrap. Containers that block them get proot.

Sandboxes stop when the panel restarts, because they die with their parent.

## Named proot workspaces

`/API/freeroot` creates a proot environment from an Ubuntu 20.04 base, installs curl and sshx inside it,
and returns the SSHx link. The same workspaces appear in the panel tab **Named proot workspace**.

```
curl -X POST -H "Authorization: Bearer <key>" -H "Content-Type: application/json" \
     -d '{"name": "build-box", "ttl": 3600}' http://<panel>/API/freeroot
SSHx:  https://sshx.io/s/...
isolation: namespaces: pid, ipc, uts, network (slirp4netns, outbound only); host processes and loopback services are not visible; proot runs inside
```

- `GET /API/freeroot/<id>?wait=N` and `DELETE /API/freeroot/<id>` are owner-only, like the other provisioning calls.
- The first request builds the shared base image (download plus `apt-get install curl ca-certificates` inside proot). This can take several minutes.
- proot comes from the host package if installed (`apt-get install proot`). Otherwise it is downloaded from a third-party repository without a checksum. Install the package to avoid that.

### Isolation, exactly

proot runs inside bubblewrap namespaces, so a workspace cannot see or reach the host's processes or services:

| Area | Status |
|---|---|
| Filesystem | Isolated. Only the workspace's own directory and the proot binary are mapped in. |
| Processes | Isolated (PID namespace). Host processes are not listed, cannot be signalled. |
| Network | Isolated (own network namespace). `127.0.0.1:5555` and the host's addresses are not reachable. Outbound internet only, through pasta or slirp4netns. slirp runs with `--disable-host-loopback`, so the gateway `10.0.2.2` does not reach the host's loopback. |
| CPU and RAM | The host's; no limits are applied. |

Hosts without bubblewrap plus pasta or slirp4netns refuse to start workspaces. To accept a shared host (filesystem only), the administrator must set `PRIME_FREEROOT_ALLOW_WEAK=1` on the panel. Those workspaces are labelled WEAK.

Check isolation on your host: `sh scripts/isolation_check.sh /var/lib/prime-terminal`. It must print PASS for loopback, gateway and pid.

### Panel tab

The tab lists your workspaces with status, SSHx link (copy button), expiry and delete. It uses the signed-in
administrator's session. Workspaces are owned by that user, and the key-based API cannot see them, and vice versa.

## Port and process visibility

Ports and processes are filtered per panel account. See `docs/FEATURES.md` (build 1.5.2) for the rules and the admin endpoints `/api/system/port-scope`.
