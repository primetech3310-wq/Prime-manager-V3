# Putting PRIME TERMINAL MANAGER behind HTTPS

The panel listens on plain HTTP (default port 8080). Before exposing it to the
internet, put it behind a TLS reverse proxy. Anyone who can reach the panel
over plain HTTP could read the sign-in and the terminal traffic.

## Option 1 — Caddy (automatic certificates)

```
panel.example.com {
    reverse_proxy 127.0.0.1:8080
}
```

Caddy obtains and renews the certificate itself. Point the DNS record for
`panel.example.com` at this server first.

Then tell the panel it is behind a proxy, so the secure-cookie flag and client
addresses are handled correctly. Set `behind_proxy` and `trusted_proxies` in
`config.json` in the data directory (`/var/lib/prime-terminal` by default),
then run `bash panel.sh restart`.

## Option 2 — nginx

```
server {
    listen 443 ssl http2;
    server_name panel.example.com;
    ssl_certificate     /etc/letsencrypt/live/panel.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/panel.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;     # terminal WebSocket
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto https;
        proxy_read_timeout 3600s;
    }
}
```

## Public links

Public links (the **Public** section) use Cloudflare quick tunnels. They give
each published port its own `https://…trycloudflare.com` address, so the
published service is HTTPS even though the panel is not. The panel's own port
can never be published.

A published service is reachable by anyone who has its link. The panel does not
add a login in front of it, so only publish services that have their own
authentication.
