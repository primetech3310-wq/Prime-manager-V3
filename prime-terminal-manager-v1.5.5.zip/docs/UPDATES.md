<!-- coderabbit-ai-generated:v1 -->

# ZIP panel updates

Open Panel updates, choose a complete trusted panel release ZIP, and click Validate upload. The updater limits input to 64 MiB, 5000 archive entries and 256 MiB expanded data. It rejects path traversal, absolute paths, duplicate entries, links, special files, encrypted entries, excessive compression and invalid Python syntax. The panel may be at the ZIP root or inside one enclosing folder.

Only `prime/`, `run.py`, `panel.sh`, `requirements.txt`, `docs/`, `tests/` and `workspace-runtime/` are accepted as application files. Configuration, databases, `.venv`, VM disks, user files and arbitrary other top-level paths are ignored. The data directory must be outside the application paths being replaced. The archive must include `prime/app.py`, `prime/__init__.py`, `prime/static/index.html` and `run.py`.

Validation launches the candidate with the current Python dependencies and a disposable data directory on a temporary loopback port. It must answer the real health check. The upload contains executable application code and is trusted administrator input. The updater does not automatically install new dependencies; incompatible releases fail validation.

Install validated update shows progress, closes panel terminals/tunnels, and replaces the service process with a restart supervisor. Administrator VMs and workspace containers continue independently. Previous application files are saved under `<data_dir>/updates/backup-ID`. The new release must pass readiness within 60 seconds. Otherwise its process is stopped, the old files are restored, and the previous panel is started. Account and settings data are preserved. Browser polling reports success or rollback and reloads after success.

`<data_dir>/updates/startup-check.log`, `restart-ID.log`, `state.json` and backup `journal.json` support diagnosis. Backups contain application code; the live data directory is not rolled back, and uploaded releases must retain database compatibility. Health readiness does not prove every feature works. There is no power-loss-atomic transaction across an entire application tree; if the host stops during file replacement, restore the recorded backup before restarting. Keep an external backup of data before major upgrades. Updates run as one service process; multi-worker external launchers require a coordinated deployment outside this in-panel updater.

Both successful update/restart and deliberate failed-start rollback were exercised in disposable installs. The existing test account and a data sentinel survived both. The shell installer also avoids deleting its source when run from its own install directory.
