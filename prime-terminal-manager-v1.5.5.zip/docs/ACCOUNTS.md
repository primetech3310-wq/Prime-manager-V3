<!-- coderabbit-ai-generated:v1 -->

# Accounts and billing

Existing accounts remain host administrators. New tenant accounts are created through **Accounts and billing → Invite tenant**. An invitation is a high-entropy, single-use link that expires after the selected number of hours. The recipient chooses their own password. Existing usernames cannot be replaced. Usernames retained by historical invoices cannot be reused.

Tenants see a separate workspace page using the existing panel styles. They can read their own invoices and VMs explicitly shared by an administrator. VM shares grant view, power and/or graphical console permissions. A console grants control inside the guest; it never grants a host terminal. Host file, process, package, service, settings, update and provisioning APIs require administrator access. Both terminal and VM WebSocket connections enforce authorization independently. Console permissions and session validity are rechecked every 15 seconds. Revocation cannot undo commands already executed in a guest.

VM networking retains the existing QEMU configuration. Sharing a VM does not add the network filtering used by private Docker workspaces. Use the private workspace backend for that workflow; its documented kernel requirements still apply.

The billing ledger supports resource plans, immutable invoice price/description snapshots, fixed or percentage coupons with expiry and usage limits, and manual pending/paid/cancelled status. Monetary values are integer cents. Coupon consumption and invoice creation share a database transaction. Invoices do not automatically provision a VM, charge a payment gateway, collect taxes, or send email. Plan deletion archives the plan; existing invoices remain. Tenant deletion revokes sessions/shares while preserving invoice history.

## Two-factor authentication

Open **Accounts and billing → Manage two-factor authentication** (tenants have their own button). Enter the current password, add the supplied secret to a TOTP authenticator (SHA-1, six digits, 30 seconds), and confirm a code. Save the ten recovery codes offline. Codes are hashed in the database and work once. Authenticator time steps also work once, with a one-step clock tolerance. If you just confirmed enrollment, wait for a new code before signing in again. Enrollment and removal revoke other account sessions.

Login requests accept an optional `code` field; the browser prompts after a correct password for accounts with two-factor authentication enabled. Disabling the factor requires the current password and a fresh authenticator code or unused recovery code. The panel stores the authenticator secret in its protected local database; protect backups of that database.
