<!-- coderabbit-ai-generated:v1 -->

# Local virtual machines

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:3dd392f7477aebd68e165f3f4536dd17ec6f4666b04d6d8bbe4524ff1b3e529d -->

The Virtual machines screen manages local QEMU guests. Install `qemu-system-x86_64` and `qemu-img`, then enter a local path to a bootable raw or QCOW2 disk. You can also download and checksum-verify the Debian 12 cloud image from the VM screen; the verified image is cached for later use. The panel makes a self-contained QCOW2 copy in its data directory. Choose memory and CPUs, create the VM, and use Start, Stop, Boot log or Delete.

<!-- /coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:7220a5d313923bd606f5a0ec8ebe75bee344fb84ef9c35cb56f3f7229192306a -->

The disk image needs a bootable operating system. For a cloud-init capable image, optionally enter a guest username and password: the panel builds a cloud-init seed with a password hash and disables root login. Otherwise use credentials already configured in the image. Cloud-init setup requires `cloud-localds` and `openssl` on the host.

A started guest uses KVM when available and QEMU TCG software emulation otherwise. Guest SSH port 22 is forwarded to a dynamically assigned port on host loopback; the VM list shows that port while running. No public access is configured automatically.

<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:9f2044409080478e9453c9bfe30b0842526250edc98fa1c6a77be8222b29de99 -->

A VM is managed by the panel administrator. Choose Automatic, Software emulation (TCG), or Require KVM in the creation form. Automatic mode retries TCG if an apparent KVM device cannot start the guest. `bash panel.sh vm-deps` checks or installs QEMU/cloud-init prerequisites. Private Docker workspace APIs are a separate feature described in WORKSPACES.md. <!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:dfcb0a6b1613f5d8c6b96e309ddf0f0fbe6396ebd6d6980aeb1ac1a0ce3f701d -->

Use Graphical console for the guest display, keyboard and mouse through the authenticated panel connection. QEMU listens on a private Unix socket, not a public VNC port. The bundled noVNC 1.6.0 client supports viewport scaling, fullscreen, Ctrl+Alt+Del and sending text from mobile keyboards. A console ticket is single-use and tied to the panel session; logout closes an attached console within 15 seconds.

Open Recovery & schedules to create independent QCOW2 disk backups or internal disk snapshots. Stop the VM first: online disk copies are rejected. Restore requires a stopped VM and replaces subsequent disk changes. Backups are SHA-256 checked before restore, copied into a temporary file, checked with qemu-img, then installed by rename. Restoring a backup removes internal snapshots; neither mechanism saves RAM, external disks or application-consistent state from a running guest. Backups live on the same host and are removed when the VM is deleted: copy the data directory elsewhere for host-loss recovery. Maximum 100 backups and 100 snapshots per VM.

Schedules can start, stop, restart or back up a VM, once or every hour/day/week. Dates use your local browser time and are stored as Unix timestamps. The panel checks schedules about every five seconds while running. Claims and next-run times are saved before execution, with missed repetitions coalesced into one run. A crash during an operation is shown as interrupted and is not automatically retried. Backup schedules fail visibly while the VM is running; they never stop a running VM implicitly. Retention prunes only that schedule's previous successful backups after the new copy passes validation. Manual backups remain. Start/stop are idempotent; restart can cause an unclean guest shutdown. The current stop operation sends QEMU SIGTERM, so shut down important guest applications first. Run a single panel worker per data directory.

<!-- /coderabbit-ai-generated:v1 --> Software emulation may be slow; success depends on the host, guest image and available resources.

<!-- /coderabbit-ai-generated:v1 -->

<!-- /coderabbit-ai-generated:v1 -->
